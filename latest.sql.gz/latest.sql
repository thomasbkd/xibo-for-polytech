-- MariaDB dump 10.17  Distrib 10.4.12-MariaDB, for Linux (x86_64)
--
-- Host: mysql    Database: cms
-- ------------------------------------------------------
-- Server version	5.6.47

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditlog`
--

DROP TABLE IF EXISTS `auditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditlog` (
  `logId` int(11) NOT NULL AUTO_INCREMENT,
  `logDate` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `entity` varchar(50) NOT NULL,
  `entityId` int(11) NOT NULL,
  `objectAfter` text,
  PRIMARY KEY (`logId`)
) ENGINE=InnoDB AUTO_INCREMENT=923 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlog`
--

LOCK TABLES `auditlog` WRITE;
/*!40000 ALTER TABLE `auditlog` DISABLE KEYS */;
INSERT INTO `auditlog` VALUES (1,1585142041,0,'Added','Widget',1,'{\"widgetId\":1,\"type\":\"text\",\"layoutId\":\"1\",\"campaignId\":\"1\"}'),(2,1585142041,0,'Saved','Widget',1,'{\"widgetId\":1,\"playlistId\":1,\"ownerId\":1,\"type\":\"text\",\"duration\":\"15\",\"displayOrder\":1,\"useDuration\":1,\"calculatedDuration\":\"15\",\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":1,\"type\":\"attrib\",\"option\":\"xmds\",\"value\":\"1\"},{\"widgetId\":1,\"type\":\"attrib\",\"option\":\"direction\",\"value\":\"none\"},{\"widgetId\":1,\"type\":\"attrib\",\"option\":\"scrollSpeed\",\"value\":\"2\"},{\"widgetId\":1,\"type\":\"attrib\",\"option\":\"fitText\",\"value\":\"0\"},{\"widgetId\":1,\"type\":\"cdata\",\"option\":\"text\",\"value\":\"<p style=\\\"text-align: center;\\\"><span style=\\\"font-size:168px;\\\"><strong><span style=\\\"font-family:arial,helvetica,sans-serif;\\\"><span style=\\\"color:#FFFFFF;\\\">Welcome to Xibo<\\/span><\\/span><\\/strong><\\/span><\\/p>\\n\\n<p style=\\\"text-align: center;\\\"><span style=\\\"font-size:80px;\\\"><span style=\\\"font-family:arial,helvetica,sans-serif;\\\"><span style=\\\"color:#FFFFFF;\\\">Open Source Digital Signage<\\/span><\\/span><\\/span><\\/p>\\n\\n<p style=\\\"text-align: center;\\\"><span style=\\\"font-size:48px;\\\"><span style=\\\"color:#D3D3D3;\\\"><span style=\\\"font-family:arial,helvetica,sans-serif;\\\">This is the default layout - please feel free to change it whenever you like.<\\/span><\\/span><\\/span><\\/p>\\n\"},{\"widgetId\":1,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"\",\"isNew\":true}'),(3,1585142041,0,'Saved','Playlist',1,'{\"campaignId\":[\"1\"],\"layoutId\":[\"1\"]}'),(4,1585142041,0,'Added','Widget',2,'{\"widgetId\":2,\"type\":\"text\",\"layoutId\":\"1\",\"campaignId\":\"1\"}'),(5,1585142041,0,'Saved','Widget',2,'{\"widgetId\":2,\"playlistId\":2,\"ownerId\":1,\"type\":\"text\",\"duration\":\"10\",\"displayOrder\":1,\"useDuration\":1,\"calculatedDuration\":\"10\",\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":2,\"type\":\"attrib\",\"option\":\"xmds\",\"value\":\"1\"},{\"widgetId\":2,\"type\":\"attrib\",\"option\":\"direction\",\"value\":\"none\"},{\"widgetId\":2,\"type\":\"attrib\",\"option\":\"scrollSpeed\",\"value\":\"2\"},{\"widgetId\":2,\"type\":\"attrib\",\"option\":\"fitText\",\"value\":\"0\"},{\"widgetId\":2,\"type\":\"cdata\",\"option\":\"text\",\"value\":\"<p style=\\\"text-align: right;\\\"><span style=\\\"font-size:96px;\\\"><span style=\\\"font-family:arial,helvetica,sans-serif;\\\"><span style=\\\"color:#D3D3D3;\\\">[Clock]<\\/span><\\/span><\\/span><\\/p>\\n\"},{\"widgetId\":2,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"\",\"isNew\":true}'),(6,1585142041,0,'Saved','Playlist',2,'{\"campaignId\":[\"1\"],\"layoutId\":[\"1\"]}'),(7,1585142042,0,'Saved','Playlist',1,'{\"duration\":\"0 > 15\",\"campaignId\":[\"1\"],\"layoutId\":[\"1\"]}'),(8,1585142042,0,'Saved','Playlist',2,'{\"duration\":\"0 > 10\",\"campaignId\":[\"1\"],\"layoutId\":[\"1\"]}'),(9,1585142043,0,'Saved','Playlist',1,'{\"campaignId\":[\"1\"],\"layoutId\":[\"1\"]}'),(10,1585142043,0,'Saved','Playlist',2,'{\"campaignId\":[\"1\"],\"layoutId\":[\"1\"]}'),(11,1585142296,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(12,1585142396,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(13,1585142457,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(14,1585143094,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(15,1585143166,1,'Added','Layout',2,'{\"layoutId\":2,\"layout\":\"AffichePaysage + Horloge\",\"campaignId\":2}'),(16,1585143166,1,'Added','Widget',3,'{\"widgetId\":3,\"type\":\"image\",\"layoutId\":\"2\",\"campaignId\":\"2\"}'),(17,1585143166,1,'Saved','Widget',3,'{\"widgetId\":3,\"playlistId\":3,\"ownerId\":1,\"type\":\"image\",\"duration\":\"30\",\"displayOrder\":1,\"useDuration\":\"1\",\"calculatedDuration\":\"30\",\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":3,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"21.jpg\"},{\"widgetId\":3,\"type\":\"attrib\",\"option\":\"align\",\"value\":\"center\"},{\"widgetId\":3,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":3,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"},{\"widgetId\":3,\"type\":\"attrib\",\"option\":\"valign\",\"value\":\"middle\"}],\"mediaIds\":[21],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"65\",\"isNew\":true}'),(18,1585143166,1,'Saved','Playlist',3,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(19,1585143166,1,'Added','Region',3,'{\"regionId\":3,\"campaignId\":\"2\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 3, LayoutId = 2. OwnerId = 1. Duration = 0\"}'),(20,1585143166,1,'Added','Widget',4,'{\"widgetId\":4,\"type\":\"clock\",\"layoutId\":\"2\",\"campaignId\":\"2\"}'),(21,1585143166,1,'Saved','Widget',4,'{\"widgetId\":4,\"playlistId\":4,\"ownerId\":1,\"type\":\"clock\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":5,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"clockFace\",\"value\":\"TwentyFourHourClock\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"clockTypeId\",\"value\":\"3\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":\"0\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"offset\",\"value\":\"0\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"showSeconds\",\"value\":\"1\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"ta_text_advanced\",\"value\":\"0\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"theme\",\"value\":\"1\"},{\"widgetId\":4,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":\"0\"},{\"widgetId\":4,\"type\":\"cdata\",\"option\":\"format\",\"value\":\"<span style=\\\"font-size: 48px; color:#ffffff;\\\">[HH:mm]<\\/span>\"}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"\",\"isNew\":true}'),(22,1585143166,1,'Saved','Playlist',4,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(23,1585143166,1,'Added','Region',4,'{\"regionId\":4,\"campaignId\":\"2\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 4, LayoutId = 2. OwnerId = 1. Duration = 0\"}'),(24,1585143166,1,'Added','Widget',5,'{\"widgetId\":5,\"type\":\"image\",\"layoutId\":\"2\",\"campaignId\":\"2\"}'),(25,1585143166,1,'Saved','Widget',5,'{\"widgetId\":5,\"playlistId\":5,\"ownerId\":1,\"type\":\"image\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":5,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"22.png\"},{\"widgetId\":5,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":5,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[22],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"68\",\"isNew\":true}'),(26,1585143166,1,'Saved','Playlist',5,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(27,1585143166,1,'Added','Region',5,'{\"regionId\":5,\"campaignId\":\"2\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 5, LayoutId = 2. OwnerId = 1. Duration = 0\"}'),(28,1585143166,1,'Added','Widget',6,'{\"widgetId\":6,\"type\":\"image\",\"layoutId\":\"2\",\"campaignId\":\"2\"}'),(29,1585143166,1,'Saved','Widget',6,'{\"widgetId\":6,\"playlistId\":6,\"ownerId\":1,\"type\":\"image\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":6,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"23.png\"},{\"widgetId\":6,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":6,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[23],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"69\",\"isNew\":true}'),(30,1585143166,1,'Saved','Playlist',6,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(31,1585143166,1,'Added','Region',6,'{\"regionId\":6,\"campaignId\":\"2\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 6, LayoutId = 2. OwnerId = 1. Duration = 0\"}'),(32,1585143177,1,'Added','Layout',3,'{\"layoutId\":3,\"layout\":\"indication salles\",\"campaignId\":3}'),(33,1585143177,1,'Added','Widget',7,'{\"widgetId\":7,\"type\":\"image\",\"layoutId\":\"3\",\"campaignId\":\"3\"}'),(34,1585143177,1,'Saved','Widget',7,'{\"widgetId\":7,\"playlistId\":7,\"ownerId\":1,\"type\":\"image\",\"duration\":\"30\",\"displayOrder\":1,\"useDuration\":\"1\",\"calculatedDuration\":\"30\",\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"25.jpg\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"align\",\"value\":\"center\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"transIn\",\"value\":\"fadeIn\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"transInDirection\",\"value\":\"N\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"transInDuration\",\"value\":\"2000\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"transOut\",\"value\":\"fly\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"transOutDirection\",\"value\":\"N\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"transOutDuration\",\"value\":\"2000\"},{\"widgetId\":7,\"type\":\"attrib\",\"option\":\"valign\",\"value\":\"middle\"}],\"mediaIds\":[25],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"27\",\"isNew\":true}'),(35,1585143177,1,'Saved','Playlist',7,'{\"campaignId\":[\"3\"],\"layoutId\":[\"3\"]}'),(36,1585143177,1,'Added','Region',7,'{\"regionId\":7,\"campaignId\":\"3\",\"details\":\"Region indication salles-1 - 1448 x 905 (7, 220). RegionId = 7, LayoutId = 3. OwnerId = 1. Duration = 0\"}'),(37,1585143178,1,'Added','Widget',8,'{\"widgetId\":8,\"type\":\"text\",\"layoutId\":\"3\",\"campaignId\":\"3\"}'),(38,1585143178,1,'Saved','Widget',8,'{\"widgetId\":8,\"playlistId\":8,\"ownerId\":1,\"type\":\"text\",\"duration\":\"28\",\"displayOrder\":1,\"useDuration\":\"1\",\"calculatedDuration\":\"28\",\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"effect\",\"value\":\"marqueeLeft\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":\"0\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"speed\",\"value\":\"6\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"ta_text_advanced\",\"value\":\"1\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"transIn\",\"value\":\"fadeIn\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"transInDirection\",\"value\":\"N\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"transInDuration\",\"value\":\"1000\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"transOut\",\"value\":\"fadeOut\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"transOutDirection\",\"value\":\"N\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"transOutDuration\",\"value\":\"2000\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":\"0\"},{\"widgetId\":8,\"type\":\"attrib\",\"option\":\"xmds\",\"value\":\"1\"},{\"widgetId\":8,\"type\":\"cdata\",\"option\":\"text\",\"value\":\"<p style=\\\"text-align: center;\\\"><span style=\\\"font-family:trebuchet ms,helvetica,sans-serif;\\\"><span style=\\\"font-size:96px;\\\"><span style=\\\"color: #ffffff;\\\">Salles <\\/span><span style=\\\"color:#33cccc;\\\"><strong>C214<\\/strong><\\/span><span style=\\\"color: #ffffff;\\\"> et <\\/span><span style=\\\"color:#33cccc;\\\"><strong>C216 <\\/strong><\\/span><span style=\\\"color: #ffffff;\\\">- Passez nous voir!<\\/span><\\/span><\\/span><\\/p>\\n\"}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"\",\"isNew\":true}'),(39,1585143178,1,'Saved','Playlist',8,'{\"campaignId\":[\"3\"],\"layoutId\":[\"3\"]}'),(40,1585143178,1,'Added','Region',8,'{\"regionId\":8,\"campaignId\":\"3\",\"details\":\"Region indication salles-2 - 1795 x 152 (923, 58). RegionId = 8, LayoutId = 3. OwnerId = 1. Duration = 0\"}'),(41,1585143179,1,'Added','Layout',4,'{\"layoutId\":4,\"layout\":\"InfoProjetRobotique\",\"campaignId\":4}'),(42,1585143179,1,'Added','Widget',9,'{\"widgetId\":9,\"type\":\"image\",\"layoutId\":\"4\",\"campaignId\":\"4\"}'),(43,1585143179,1,'Saved','Widget',9,'{\"widgetId\":9,\"playlistId\":9,\"ownerId\":1,\"type\":\"image\",\"duration\":\"30\",\"displayOrder\":1,\"useDuration\":\"1\",\"calculatedDuration\":\"30\",\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":9,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"26.jpg\"},{\"widgetId\":9,\"type\":\"attrib\",\"option\":\"align\",\"value\":\"center\"},{\"widgetId\":9,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":9,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"},{\"widgetId\":9,\"type\":\"attrib\",\"option\":\"valign\",\"value\":\"middle\"}],\"mediaIds\":[26],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"31\",\"isNew\":true}'),(44,1585143179,1,'Saved','Playlist',9,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(45,1585143179,1,'Added','Region',9,'{\"regionId\":9,\"campaignId\":\"4\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 9, LayoutId = 4. OwnerId = 1. Duration = 0\"}'),(46,1585143179,1,'Added','Widget',10,'{\"widgetId\":10,\"type\":\"clock\",\"layoutId\":\"4\",\"campaignId\":\"4\"}'),(47,1585143179,1,'Saved','Widget',10,'{\"widgetId\":10,\"playlistId\":10,\"ownerId\":1,\"type\":\"clock\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":5,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"clockFace\",\"value\":\"TwentyFourHourClock\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"clockTypeId\",\"value\":\"3\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":\"0\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"offset\",\"value\":\"0\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"showSeconds\",\"value\":\"1\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"ta_text_advanced\",\"value\":\"0\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"theme\",\"value\":\"1\"},{\"widgetId\":10,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":\"0\"},{\"widgetId\":10,\"type\":\"cdata\",\"option\":\"format\",\"value\":\"<span style=\\\"font-size: 48px; color:#ffffff;\\\">[HH:mm]<\\/span>\"}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"\",\"isNew\":true}'),(48,1585143179,1,'Saved','Playlist',10,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(49,1585143179,1,'Added','Region',10,'{\"regionId\":10,\"campaignId\":\"4\",\"details\":\"Region Heure - 785 x 188 (854, 1002). RegionId = 10, LayoutId = 4. OwnerId = 1. Duration = 0\"}'),(50,1585143179,1,'Added','Widget',11,'{\"widgetId\":11,\"type\":\"image\",\"layoutId\":\"4\",\"campaignId\":\"4\"}'),(51,1585143179,1,'Saved','Widget',11,'{\"widgetId\":11,\"playlistId\":11,\"ownerId\":1,\"type\":\"image\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":11,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"22.png\"},{\"widgetId\":11,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":11,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[22],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"68\",\"isNew\":true}'),(52,1585143179,1,'Saved','Playlist',11,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(53,1585143179,1,'Added','Region',11,'{\"regionId\":11,\"campaignId\":\"4\",\"details\":\"Region Logo Polytech - 350 x 136 (877, 599). RegionId = 11, LayoutId = 4. OwnerId = 1. Duration = 0\"}'),(54,1585143179,1,'Added','Widget',12,'{\"widgetId\":12,\"type\":\"image\",\"layoutId\":\"4\",\"campaignId\":\"4\"}'),(55,1585143179,1,'Saved','Widget',12,'{\"widgetId\":12,\"playlistId\":12,\"ownerId\":1,\"type\":\"image\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":12,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"23.png\"},{\"widgetId\":12,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":12,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[23],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"69\",\"isNew\":true}'),(56,1585143179,1,'Saved','Playlist',12,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(57,1585143179,1,'Added','Region',12,'{\"regionId\":12,\"campaignId\":\"4\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 39). RegionId = 12, LayoutId = 4. OwnerId = 1. Duration = 0\"}'),(58,1585143180,1,'Added','Layout',5,'{\"layoutId\":5,\"layout\":\"TwitterTest\",\"campaignId\":5}'),(59,1585143180,1,'Saved','Playlist',13,'{\"campaignId\":[\"5\"],\"layoutId\":[\"5\"]}'),(60,1585143180,1,'Added','Region',13,'{\"regionId\":13,\"campaignId\":\"5\",\"details\":\"Region TwitterTest-1 - 1920 x 1080 (0, 0). RegionId = 13, LayoutId = 5. OwnerId = 1. Duration = 0\"}'),(61,1585143182,1,'Added','Layout',6,'{\"layoutId\":6,\"layout\":\"Vid\\u00e9o + Horloge\",\"campaignId\":6}'),(62,1585143182,1,'Added','Widget',13,'{\"widgetId\":13,\"type\":\"video\",\"layoutId\":\"6\",\"campaignId\":\"6\"}'),(63,1585143182,1,'Saved','Widget',13,'{\"widgetId\":13,\"playlistId\":14,\"ownerId\":1,\"type\":\"video\",\"duration\":\"7\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":7,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":13,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"27.mp4\"},{\"widgetId\":13,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":13,\"type\":\"attrib\",\"option\":\"mute\",\"value\":\"0\"}],\"mediaIds\":[27],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"73\",\"isNew\":true}'),(64,1585143182,1,'Saved','Playlist',14,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(65,1585143182,1,'Added','Region',14,'{\"regionId\":14,\"campaignId\":\"6\",\"details\":\"Region Vid\\u00e9o - 1855 x 812 (17, 31). RegionId = 14, LayoutId = 6. OwnerId = 1. Duration = 0\"}'),(66,1585143182,1,'Added','Widget',14,'{\"widgetId\":14,\"type\":\"clock\",\"layoutId\":\"6\",\"campaignId\":\"6\"}'),(67,1585143182,1,'Saved','Widget',14,'{\"widgetId\":14,\"playlistId\":15,\"ownerId\":1,\"type\":\"clock\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":5,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"clockFace\",\"value\":\"TwentyFourHourClock\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"clockTypeId\",\"value\":\"3\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":\"0\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"offset\",\"value\":\"0\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"showSeconds\",\"value\":\"1\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"ta_text_advanced\",\"value\":\"0\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"theme\",\"value\":\"1\"},{\"widgetId\":14,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":\"0\"},{\"widgetId\":14,\"type\":\"cdata\",\"option\":\"format\",\"value\":\"<span style=\\\"font-size: 48px; color:#ffffff;\\\">[HH:mm]<\\/span>\"}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"\",\"isNew\":true}'),(68,1585143182,1,'Saved','Playlist',15,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(69,1585143182,1,'Added','Region',15,'{\"regionId\":15,\"campaignId\":\"6\",\"details\":\"Region Heure - 785 x 188 (854, 1002). RegionId = 15, LayoutId = 6. OwnerId = 1. Duration = 0\"}'),(70,1585143182,1,'Added','Widget',15,'{\"widgetId\":15,\"type\":\"image\",\"layoutId\":\"6\",\"campaignId\":\"6\"}'),(71,1585143182,1,'Saved','Widget',15,'{\"widgetId\":15,\"playlistId\":16,\"ownerId\":1,\"type\":\"image\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":15,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"22.png\"},{\"widgetId\":15,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":15,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[22],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"68\",\"isNew\":true}'),(72,1585143182,1,'Saved','Playlist',16,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(73,1585143182,1,'Added','Region',16,'{\"regionId\":16,\"campaignId\":\"6\",\"details\":\"Region Logo Polytech - 350 x 136 (877, 599). RegionId = 16, LayoutId = 6. OwnerId = 1. Duration = 0\"}'),(74,1585143182,1,'Added','Widget',16,'{\"widgetId\":16,\"type\":\"image\",\"layoutId\":\"6\",\"campaignId\":\"6\"}'),(75,1585143182,1,'Saved','Widget',16,'{\"widgetId\":16,\"playlistId\":17,\"ownerId\":1,\"type\":\"image\",\"duration\":\"1\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":16,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"23.png\"},{\"widgetId\":16,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":16,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[23],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"69\",\"isNew\":true}'),(76,1585143182,1,'Saved','Playlist',17,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(77,1585143182,1,'Added','Region',17,'{\"regionId\":17,\"campaignId\":\"6\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 39). RegionId = 17, LayoutId = 6. OwnerId = 1. Duration = 0\"}'),(78,1585143196,1,'Added','Layout',7,'{\"layoutId\":7,\"layout\":\"MEP par d\\u00e9faut\",\"campaignId\":7}'),(79,1585143196,1,'Added','Widget',17,'{\"widgetId\":17,\"type\":\"video\",\"layoutId\":\"7\",\"campaignId\":\"7\"}'),(80,1585143196,1,'Saved','Widget',17,'{\"widgetId\":17,\"playlistId\":18,\"ownerId\":1,\"type\":\"video\",\"duration\":\"33\",\"displayOrder\":1,\"useDuration\":\"0\",\"calculatedDuration\":33,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":0,\"toDt\":2147483647,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":17,\"type\":\"attrib\",\"option\":\"uri\",\"value\":\"28.mp4\"},{\"widgetId\":17,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":17,\"type\":\"attrib\",\"option\":\"mute\",\"value\":\"0\"}],\"mediaIds\":[28],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":\"74\",\"isNew\":true}'),(81,1585143196,1,'Saved','Playlist',18,'{\"campaignId\":[\"7\"],\"layoutId\":[\"7\"]}'),(82,1585143196,1,'Added','Region',18,'{\"regionId\":18,\"campaignId\":\"7\",\"details\":\"Region Vid\\u00e9o - 1920 x 1080 (0, 0). RegionId = 18, LayoutId = 7. OwnerId = 1. Duration = 0\"}'),(83,1585143226,1,'Saved','Playlist',18,'{\"campaignId\":[\"7\"],\"layoutId\":[\"7\"]}'),(84,1585143229,1,'Checked out','Layout',8,'{\"layoutId\":7,\"layout\":\"MEP par d\\u00e9faut\",\"campaignId\":7}'),(85,1585143229,1,'Added','Widget',18,'{\"widgetId\":18,\"type\":\"video\",\"layoutId\":\"8\",\"campaignId\":\"7\"}'),(86,1585143229,1,'Saved','Widget',18,'{\"widgetId\":\"17 > 18\",\"playlistId\":\"18 > 19\"}'),(87,1585143229,1,'Saved','Playlist',19,'{\"playlistId\":\"18 > 19\",\"regionId\":\"18 > 19\",\"campaignId\":[\"7\"],\"layoutId\":[\"8\"]}'),(88,1585143229,1,'Added','Region',19,'{\"regionId\":19,\"campaignId\":\"7\",\"details\":\"Region Vid\\u00e9o - 1920 x 1080 (0, 0). RegionId = 19, LayoutId = 8. OwnerId = 1. Duration = 33\"}'),(89,1585143229,1,'Updated','Layout',7,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[7]}'),(90,1585143230,1,'Saved','Playlist',19,'{\"campaignId\":[\"7\"],\"layoutId\":[\"8\"]}'),(91,1585143277,1,'Updated Draft','Layout',8,'{\"status\":\"1 > 3\",\"campaignId\":[7]}'),(92,1585143296,1,'Saved','Playlist',3,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(93,1585143296,1,'Saved','Playlist',4,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(94,1585143296,1,'Saved','Playlist',5,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(95,1585143296,1,'Saved','Playlist',6,'{\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(96,1585143299,1,'Checked out','Layout',9,'{\"layoutId\":2,\"layout\":\"AffichePaysage + Horloge\",\"campaignId\":2}'),(97,1585143299,1,'Added','Widget',19,'{\"widgetId\":19,\"type\":\"image\",\"layoutId\":\"9\",\"campaignId\":\"2\"}'),(98,1585143299,1,'Saved','Widget',19,'{\"widgetId\":\"3 > 19\",\"playlistId\":\"3 > 20\"}'),(99,1585143299,1,'Saved','Playlist',20,'{\"playlistId\":\"3 > 20\",\"regionId\":\"3 > 20\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(100,1585143299,1,'Added','Region',20,'{\"regionId\":20,\"campaignId\":\"2\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 20, LayoutId = 9. OwnerId = 1. Duration = 30\"}'),(101,1585143299,1,'Added','Widget',20,'{\"widgetId\":20,\"type\":\"clock\",\"layoutId\":\"9\",\"campaignId\":\"2\"}'),(102,1585143299,1,'Saved','Widget',20,'{\"widgetId\":\"4 > 20\",\"playlistId\":\"4 > 21\"}'),(103,1585143299,1,'Saved','Playlist',21,'{\"playlistId\":\"4 > 21\",\"regionId\":\"4 > 21\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(104,1585143299,1,'Added','Region',21,'{\"regionId\":21,\"campaignId\":\"2\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 21, LayoutId = 9. OwnerId = 1. Duration = 5\"}'),(105,1585143299,1,'Added','Widget',21,'{\"widgetId\":21,\"type\":\"image\",\"layoutId\":\"9\",\"campaignId\":\"2\"}'),(106,1585143299,1,'Saved','Widget',21,'{\"widgetId\":\"5 > 21\",\"playlistId\":\"5 > 22\"}'),(107,1585143299,1,'Saved','Playlist',22,'{\"playlistId\":\"5 > 22\",\"regionId\":\"5 > 22\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(108,1585143299,1,'Added','Region',22,'{\"regionId\":22,\"campaignId\":\"2\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 22, LayoutId = 9. OwnerId = 1. Duration = 10\"}'),(109,1585143299,1,'Added','Widget',22,'{\"widgetId\":22,\"type\":\"image\",\"layoutId\":\"9\",\"campaignId\":\"2\"}'),(110,1585143299,1,'Saved','Widget',22,'{\"widgetId\":\"6 > 22\",\"playlistId\":\"6 > 23\"}'),(111,1585143299,1,'Saved','Playlist',23,'{\"playlistId\":\"6 > 23\",\"regionId\":\"6 > 23\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(112,1585143299,1,'Added','Region',23,'{\"regionId\":23,\"campaignId\":\"2\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 23, LayoutId = 9. OwnerId = 1. Duration = 10\"}'),(113,1585143299,1,'Updated','Layout',2,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[2]}'),(114,1585143302,0,'Saved','Playlist',3,'{\"duration\":\"0 > 30\",\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(115,1585143302,0,'Saved','Playlist',20,'{\"duration\":\"0 > 30\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(116,1585143302,0,'Saved','Playlist',9,'{\"duration\":\"0 > 30\",\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(117,1585143302,0,'Saved','Playlist',21,'{\"duration\":\"0 > 5\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(118,1585143302,0,'Saved','Playlist',10,'{\"duration\":\"0 > 5\",\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(119,1585143302,0,'Saved','Playlist',15,'{\"duration\":\"0 > 5\",\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(120,1585143302,0,'Saved','Playlist',4,'{\"duration\":\"0 > 5\",\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(121,1585143302,0,'Saved','Playlist',7,'{\"duration\":\"0 > 30\",\"campaignId\":[\"3\"],\"layoutId\":[\"3\"]}'),(122,1585143302,0,'Saved','Playlist',8,'{\"duration\":\"0 > 28\",\"campaignId\":[\"3\"],\"layoutId\":[\"3\"]}'),(123,1585143302,0,'Saved','Playlist',11,'{\"duration\":\"0 > 10\",\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(124,1585143302,0,'Saved','Playlist',16,'{\"duration\":\"0 > 10\",\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(125,1585143302,0,'Saved','Playlist',5,'{\"duration\":\"0 > 10\",\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(126,1585143302,0,'Saved','Playlist',22,'{\"duration\":\"0 > 10\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(127,1585143302,0,'Saved','Playlist',17,'{\"duration\":\"0 > 10\",\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(128,1585143302,0,'Saved','Playlist',6,'{\"duration\":\"0 > 10\",\"campaignId\":[\"2\"],\"layoutId\":[\"2\"]}'),(129,1585143302,0,'Saved','Playlist',23,'{\"duration\":\"0 > 10\",\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(130,1585143302,0,'Saved','Playlist',12,'{\"duration\":\"0 > 10\",\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(131,1585143302,0,'Saved','Playlist',13,'{\"campaignId\":[\"5\"],\"layoutId\":[\"5\"]}'),(132,1585143302,0,'Saved','Playlist',18,'{\"duration\":\"0 > 33\",\"campaignId\":[\"7\"],\"layoutId\":[\"7\"]}'),(133,1585143302,0,'Saved','Playlist',14,'{\"duration\":\"0 > 7\",\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(134,1585143302,0,'Saved','Playlist',19,'{\"duration\":\"0 > 33\",\"campaignId\":[\"7\"],\"layoutId\":[\"8\"]}'),(135,1585143302,0,'Saved','Playlist',7,'{\"campaignId\":[\"3\"],\"layoutId\":[\"3\"]}'),(136,1585143302,0,'Saved','Playlist',8,'{\"campaignId\":[\"3\"],\"layoutId\":[\"3\"]}'),(137,1585143303,0,'Saved','Playlist',9,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(138,1585143303,0,'Saved','Playlist',10,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(139,1585143303,0,'Saved','Playlist',11,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(140,1585143303,0,'Saved','Playlist',12,'{\"campaignId\":[\"4\"],\"layoutId\":[\"4\"]}'),(141,1585143303,0,'Saved','Playlist',14,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(142,1585143303,0,'Saved','Playlist',15,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(143,1585143303,0,'Saved','Playlist',16,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(144,1585143303,0,'Saved','Playlist',17,'{\"campaignId\":[\"6\"],\"layoutId\":[\"6\"]}'),(145,1585143303,1,'Saved','Playlist',20,'{\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(146,1585143303,1,'Saved','Playlist',21,'{\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(147,1585143303,1,'Saved','Playlist',22,'{\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(148,1585143303,1,'Saved','Playlist',23,'{\"campaignId\":[\"2\"],\"layoutId\":[\"9\"]}'),(149,1585143316,1,'Updated Draft','Layout',9,'{\"status\":\"1 > 3\",\"campaignId\":[2]}'),(150,1585144020,1,'Display Saved','Display',1,'[]'),(151,1585144033,1,'Display Saved','Display',1,'{\"licensed\":\"0 > 1\"}'),(152,1585144096,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(153,1585144422,1,'Display Saved','Display',2,'{\"licensed\":\"0 > 1\"}'),(154,1585144508,1,'Deleted','Widget',1,'{\"widgetId\":1,\"playlistId\":1}'),(155,1585144508,1,'Deleted','Playlist',1,'{\"playlistId\":1,\"regionId\":1}'),(156,1585144508,1,'Region Deleted','Region',1,'{\"regionId\":1,\"layoutId\":1}'),(157,1585144508,1,'Deleted','Widget',2,'{\"widgetId\":2,\"playlistId\":2}'),(158,1585144508,1,'Deleted','Playlist',2,'{\"playlistId\":2,\"regionId\":2}'),(159,1585144508,1,'Region Deleted','Region',2,'{\"regionId\":2,\"layoutId\":1}'),(160,1585144508,1,'Layout Deleted','Layout',1,'{\"layoutId\":1}'),(161,1585144508,1,'Deleted','Layout',1,'[]'),(162,1585144523,1,'Checked out','Layout',10,'{\"layoutId\":5,\"layout\":\"TwitterTest\",\"campaignId\":5}'),(163,1585144523,1,'Saved','Playlist',24,'{\"playlistId\":\"13 > 24\",\"regionId\":\"13 > 24\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(164,1585144523,1,'Added','Region',24,'{\"regionId\":24,\"campaignId\":\"5\",\"details\":\"Region TwitterTest-1 - 1920 x 1080 (0, 0). RegionId = 24, LayoutId = 10. OwnerId = 1. Duration = 0\"}'),(165,1585144523,1,'Updated','Layout',5,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[5]}'),(166,1585144689,1,'Added','Widget',23,'{\"widgetId\":23,\"type\":\"twitter\",\"layoutId\":\"10\",\"campaignId\":\"5\"}'),(167,1585144689,1,'Saved','Widget',23,'{\"widgetId\":23,\"playlistId\":\"24\",\"ownerId\":1,\"type\":\"twitter\",\"duration\":60,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":60,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":23,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":23,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":23,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(168,1585144691,1,'Saved','Playlist',24,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(169,1585144790,1,'Saved','Widget',23,'{\"duration\":\"60 > 50\",\"useDuration\":\"0 > 1\",\"calculatedDuration\":\"60 > 50\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(170,1585144792,1,'Saved','Playlist',24,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(171,1585144796,1,'Saved','Widget',23,'{\"duration\":\"50 > 60\",\"calculatedDuration\":\"50 > 60\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(172,1585144798,1,'Saved','Playlist',24,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(173,1585144800,0,'Saved','Playlist',24,'{\"duration\":\"0 > 60\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(174,1585144875,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"dateFormat\\\": \\\"dd\\\\\\/mm\\\\\\/Y > D d M Y\\\"\\n    },\\n    {\\n        \\\"language\\\": \\\"french > \\\"\\n    },\\n    {\\n        \\\"templateId\\\": \\\"full-timeline-np > tweet-4\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(175,1585144918,1,'Saved','Playlist',24,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(176,1585144918,1,'Saved','Region',24,'{\"width\":\"1920 > 1312.89\",\"height\":\"1080 > 657.37\",\"top\":\"0 > 202.35\",\"left\":\"0 > 294.56\",\"campaignId\":[\"5\"]}'),(177,1585144939,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"itemsPerPage\\\": \\\"5 > 1\\\"\\n    },\\n    {\\n        \\\"tweetCount\\\": \\\"15 > 5\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(178,1585144970,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"updateInterval\\\": \\\"60 > 3\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(179,1585144975,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"updateInterval\\\": \\\"3 > 30\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(180,1585145008,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"tweet-4 > full-timeline-np\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(181,1585145075,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"itemsPerPage\\\": \\\"1 > 3\\\"\\n    },\\n    {\\n        \\\"tweetCount\\\": \\\"5 > 15\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(182,1585145095,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"itemsPerPage\\\": \\\"3 > 1\\\"\\n    },\\n    {\\n        \\\"tweetCount\\\": \\\"15 > 5\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(183,1585145110,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"full-timeline-np > full-timeline\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(184,1585145124,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"full-timeline > tweet-1\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(185,1585145155,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"effect\\\": \\\"fadeout > scrollHorz\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(186,1585145190,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"backgroundColor\\\": \\\"rgba(255,255,255,1) > rgba(255,255,255,0.4)\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(187,1585145225,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"tweet-1 > tweet-8\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(188,1585145255,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"itemsPerPage\\\": \\\"1 > 3\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(189,1585145327,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"overrideTemplate\\\": \\\"0 > 1\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(190,1585145356,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n} > .item {\\\\r\\\\n    float: center;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(191,1585145420,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: center;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n} > .item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(192,1585145433,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n} > .item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(193,1585145534,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]<\\\\\\/br>[ScreenName]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(194,1585145614,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]<\\\\\\/br>[ScreenName]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]<\\\\\\/br><p style=\\\\\\\"font-weight: lighter\\\\\\\">([ScreenName])<\\\\\\/p><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(195,1585145629,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]<\\\\\\/br><p style=\\\\\\\"font-weight: lighter\\\\\\\">([ScreenName])<\\\\\\/p><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<\\\\\\/br><p style=\\\\\\\"font-weight: lighter\\\\\\\">([ScreenName])<\\\\\\/p><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(196,1585145691,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<\\\\\\/br><p style=\\\\\\\"font-weight: lighter\\\\\\\">([ScreenName])<\\\\\\/p><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<\\\\\\/br><p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(197,1585145761,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n} > .item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.screenname {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    padding-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(198,1585145786,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"tweetCount\\\": \\\"5 > 3\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(199,1585145795,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"itemsPerPage\\\": \\\"3 > 6\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(200,1585145812,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"itemsPerPage\\\": \\\"6 > 3\\\"\\n    },\\n    {\\n        \\\"tweetCount\\\": \\\"3 > 6\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(201,1585145851,1,'Saved','Widget',23,'{\"duration\":\"60 > 30\",\"calculatedDuration\":\"60 > 30\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(202,1585145852,1,'Saved','Playlist',24,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(203,1585145872,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"resultContent\\\": \\\"1 > 0\\\"\\n    },\\n    {\\n        \\\"widgetOriginalPadding\\\": \\\"10 > 30\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(204,1585145897,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"400 > 500\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(205,1585145911,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"500 > 350\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(206,1585145928,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalPadding\\\": \\\"30 > 100\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(207,1585145939,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalPadding\\\": \\\"100 > 130\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(208,1585145963,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalPadding\\\": \\\"130 > 125\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(209,1585146000,0,'Saved','Playlist',24,'{\"duration\":\"60 > 30\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(210,1585146029,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<\\\\\\/br><p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"image\\\\\\\">[Photo]<\\\\\\/div>\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(211,1585146058,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"image\\\\\\\">[Photo]<\\\\\\/div>\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"image-div\\\\\\\">[Photo]<\\\\\\/div>\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(212,1585146108,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.screenname {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    padding-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n} > .item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    max-height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.screenname {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    padding-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(213,1585146133,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"searchTerm\\\": \\\"polytech nancy > dbgacpm\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(214,1585146214,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"searchTerm\\\": \\\"dbgacpm > polytechnancy\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(215,1585146244,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"searchTerm\\\": \\\"polytechnancy > robotech nancy\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(216,1585146258,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"searchTerm\\\": \\\"robotech nancy > robotechnancy\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(217,1585146332,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"image-div\\\\\\\">[Photo]<\\\\\\/div>\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<!-- <div class=\\\\\\\"image-div\\\\\\\">[Photo]<\\\\\\/div> -->\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(218,1585146362,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"overrideTemplate\\\": \\\"1 > 0\\\"\\n    },\\n    {\\n        \\\"templateId\\\": \\\"tweet-8 > full-timeline\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(219,1585146390,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"full-timeline > tweet-6PL\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(220,1585146404,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"tweet-6PL > full-timeline\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(221,1585146423,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"searchTerm\\\": \\\"robotechnancy > polytech nancy\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(222,1585146437,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"overrideTemplate\\\": \\\"0 > 1\\\"\\n    },\\n    {\\n        \\\"widgetOriginalHeight\\\": \\\"650 > 900\\\"\\n    },\\n    {\\n        \\\"widgetOriginalPadding\\\": \\\"125 > 0\\\"\\n    },\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"350 > 1000\\\"\\n    },\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 10px;\\\\r\\\\n    height: 10px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div {\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    max-height: 110px;\\\\r\\\\n    padding: 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.image-div IMG {\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    position: absolute;\\\\r\\\\n    width: 70px;\\\\r\\\\n    top: 50%;\\\\r\\\\n    left: 50%;\\\\r\\\\n    transform: translate(-50%,-50%);\\\\r\\\\n-webkit-transform: translate(-50%, -50%);\\\\r\\\\n    border: 3px solid #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twit {\\\\r\\\\n    height: 650px !important;\\\\r\\\\n    width: 350px !important;\\\\r\\\\n    float: left;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n    background: #FFF;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.screenname {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    padding-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    padding: 40px;\\\\r\\\\n    line-height: 160%;\\\\r\\\\n    color: #4d4d4d;\\\\r\\\\n    height: 480px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.header {\\\\r\\\\n    background: #1da1f2;\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: 110px;\\\\r\\\\n    border: 1px solid #ddd;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.user {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-top: 40px;\\\\r\\\\n    letter-spacing: 1px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tiempo {\\\\r\\\\n    font-weight: lighter;\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    margin-top: 15px;\\\\r\\\\n} > .emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1000px !important;\\\\r\\\\n    height: 900px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 870px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n}\\\"\\n    },\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twit\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"header\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 top-bar image-div\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-8 user\\\\\\\">[User]\\\\r\\\\n<p class=\\\\\\\"screenname\\\\\\\">([ScreenName])<\\\\\\/p>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"main-tweet \\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<!-- <div class=\\\\\\\"image-div\\\\\\\">[Photo]<\\\\\\/div> -->\\\\r\\\\n<div class=\\\\\\\"col-xs-6 tiempo\\\\\\\">[Date]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-3 col-xs-offset-3\\\\\\\"><img class=\\\\\\\"img-responsive\\\\\\\" src=\\\\\\\"[TwitterLogoBlue]\\\\\\\" \\\\\\/><\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twitter-container\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"profileimage\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"message-container\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"message\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"user\\\\\\\"><span>[User]<\\\\\\/span><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"date\\\\\\\"><span>[Date]<\\\\\\/span><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"tweet\\\\\\\"><span>[Tweet]<\\\\\\/span><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"photo\\\\\\\">[Photo]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(223,1585146458,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"itemsPerPage\\\": \\\"3 > 1\\\"\\n    },\\n    {\\n        \\\"tweetCount\\\": \\\"6 > 5\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(224,1585146513,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1000px !important;\\\\r\\\\n    height: 900px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 870px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n} > .emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1000px !important;\\\\r\\\\n    height: 900px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 870px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(225,1585146529,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1000px !important;\\\\r\\\\n    height: 900px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 870px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n} > .emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 300px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1000px !important;\\\\r\\\\n    height: 900px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 870px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(226,1585146596,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 300px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1000px !important;\\\\r\\\\n    height: 900px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 870px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n} > .emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 800px !important;\\\\r\\\\n    height: 500px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 500px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(227,1585146653,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 800px !important;\\\\r\\\\n    height: 500px !important;\\\\r\\\\n    font-size: 25px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 500px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n} > .emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1500px !important;\\\\r\\\\n    height: 800px !important;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 500px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(228,1585146674,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1500px !important;\\\\r\\\\n    height: 800px !important;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 500px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n} > .emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1500px !important;\\\\r\\\\n    height: 800px !important;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 1500px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(229,1585146710,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"overrideTemplate\\\": \\\"1 > 0\\\"\\n    },\\n    {\\n        \\\"templateId\\\": \\\"full-timeline > tweet-4\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(230,1585146737,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"overrideTemplate\\\": \\\"0 > 1\\\"\\n    },\\n    {\\n        \\\"widgetOriginalHeight\\\": \\\"900 > 200\\\"\\n    },\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"1000 > 340\\\"\\n    },\\n    {\\n        \\\"styleSheet\\\": \\\".emojione {\\\\r\\\\n    width: 26px;\\\\r\\\\n    height: 26px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.item {\\\\r\\\\n    float: none;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.tweet {\\\\r\\\\n    height: 130px;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    width: 1500px !important;\\\\r\\\\n    height: 800px !important;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    line-height: 1.3;\\\\r\\\\n    font-family: lucida sans unicode, lucida grande, sans-serif;\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage {\\\\r\\\\n    width: 90px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    position: relative;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n    margin-left: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.profileimage img {\\\\r\\\\n    width: 90px;\\\\r\\\\n    -webkit-border-radius: 50%;\\\\r\\\\n    -moz-border-radius: 50%;\\\\r\\\\n    -ms-border-radius: 50%;\\\\r\\\\n    -o-border-radius: 50%;\\\\r\\\\n    border-radius: 50%;\\\\r\\\\n    border: 5px solid #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\ndiv.message-container {\\\\r\\\\n    width: 1500px;\\\\r\\\\n    height: inherit;\\\\r\\\\n    display: block;\\\\r\\\\n    position: relative;\\\\r\\\\n    padding-left: 20px;\\\\r\\\\n    vertical-align: top;\\\\r\\\\n    display: inline-block;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .user {\\\\r\\\\n    height: 30px;\\\\r\\\\n    font-weight: 700;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    margin-bottom: .2em;\\\\r\\\\n    color: #95a5a6;\\\\r\\\\n    padding: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .date {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    float: right;\\\\r\\\\n    height: 30px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo {\\\\r\\\\n    text-align: center;\\\\r\\\\n    height: auto;\\\\r\\\\n    max-height: 690px;\\\\r\\\\n    overflow: hidden;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message-container .photo img {\\\\r\\\\n    width: 100%;\\\\r\\\\n    height: auto !important;\\\\r\\\\n    vertical-align: middle;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.message {\\\\r\\\\n    width: 100%;\\\\r\\\\n    padding: 10px;\\\\r\\\\n    background-color: #ecf0f1;\\\\r\\\\n    position: relative;\\\\r\\\\n    -webkit-border-radius: 8px;\\\\r\\\\n    -moz-border-radius: 8px;\\\\r\\\\n    -ms-border-radius: 8px;\\\\r\\\\n    -o-border-radius: 8px;\\\\r\\\\n    border-radius: 8px;\\\\r\\\\n    text-align: left;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    max-height: 880px;\\\\r\\\\n} > .item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 30px;\\\\r\\\\n    height: 30px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n    background-image: url(\'..\\\\\\/clouds.jpg\');\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: center;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.img-container img {\\\\r\\\\n    width: 50px;\\\\r\\\\n    height: 50px;\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    width: 340px !important;\\\\r\\\\n    height: 200px !important;\\\\r\\\\n    background-color: rgba(255, 255, 255, 0.6);\\\\r\\\\n    background: rgba(255, 255, 255, 0.6);\\\\r\\\\n    color: rgba(255, 255, 255, 0.6);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 14px;\\\\r\\\\n    padding: 20px 0px;\\\\r\\\\n    line-height: 120%;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.mini-widget {\\\\r\\\\n    height: 180px;\\\\r\\\\n    padding-top: 20px;\\\\r\\\\n    border: 1px solid #eee;\\\\r\\\\n    background-color: #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-date, .twitter-location {\\\\r\\\\n    margin-top: 30px;\\\\r\\\\n    font-size: 17px;\\\\r\\\\n    color: #434343;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.name {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #434343;\\\\r\\\\n    margin-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.username {\\\\r\\\\n    margin-top: -4px;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.avatar {\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\"\\n    },\\n    {\\n        \\\"template\\\": \\\"<div class=\\\\\\\"twitter-container\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"profileimage\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"message-container\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"message\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"user\\\\\\\"><span>[User]<\\\\\\/span><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"date\\\\\\\"><span>[Date]<\\\\\\/span><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"tweet\\\\\\\"><span>[Tweet]<\\\\\\/span><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"photo\\\\\\\">[Photo]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"twitter-container\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-12 mini-widget\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-2 img-container\\\\\\\">[ProfileImage|bigger]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-10\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"name\\\\\\\">[User]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"username\\\\\\\">[ScreenName]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-12\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"main-tweet\\\\\\\">[Tweet]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(231,1585146777,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 30px;\\\\r\\\\n    height: 30px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n    background-image: url(\'..\\\\\\/clouds.jpg\');\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: center;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.img-container img {\\\\r\\\\n    width: 50px;\\\\r\\\\n    height: 50px;\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    width: 340px !important;\\\\r\\\\n    height: 200px !important;\\\\r\\\\n    background-color: rgba(255, 255, 255, 0.6);\\\\r\\\\n    background: rgba(255, 255, 255, 0.6);\\\\r\\\\n    color: rgba(255, 255, 255, 0.6);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 14px;\\\\r\\\\n    padding: 20px 0px;\\\\r\\\\n    line-height: 120%;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.mini-widget {\\\\r\\\\n    height: 180px;\\\\r\\\\n    padding-top: 20px;\\\\r\\\\n    border: 1px solid #eee;\\\\r\\\\n    background-color: #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-date, .twitter-location {\\\\r\\\\n    margin-top: 30px;\\\\r\\\\n    font-size: 17px;\\\\r\\\\n    color: #434343;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.name {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #434343;\\\\r\\\\n    margin-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.username {\\\\r\\\\n    margin-top: -4px;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.avatar {\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n} > .item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 30px;\\\\r\\\\n    height: 30px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n    background-image: url(\'..\\\\\\/clouds.jpg\');\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: center;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.img-container img {\\\\r\\\\n    width: 50px;\\\\r\\\\n    height: 50px;\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    width: 340px !important;\\\\r\\\\n    height: 200px !important;\\\\r\\\\n    background-color: rgba(255, 255, 255, 0.6);\\\\r\\\\n    background: rgba(255, 255, 255, 0.6);\\\\r\\\\n    color: rgba(255, 255, 255, 0.6);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 14px;\\\\r\\\\n    padding: 20px 0px;\\\\r\\\\n    line-height: 120%;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.mini-widget {\\\\r\\\\n    height: 180px;\\\\r\\\\n    padding-top: 20px;\\\\r\\\\n    border: 1px solid #eee;\\\\r\\\\n    background-color: #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-date, .twitter-location {\\\\r\\\\n    margin-top: 30px;\\\\r\\\\n    font-size: 17px;\\\\r\\\\n    color: #434343;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.name {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #434343;\\\\r\\\\n    margin-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.username {\\\\r\\\\n    margin-top: 4px;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.avatar {\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(232,1585146829,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\".item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 30px;\\\\r\\\\n    height: 30px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n    background-image: url(\'..\\\\\\/clouds.jpg\');\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: center;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.img-container img {\\\\r\\\\n    width: 50px;\\\\r\\\\n    height: 50px;\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    width: 340px !important;\\\\r\\\\n    height: 200px !important;\\\\r\\\\n    background-color: rgba(255, 255, 255, 0.6);\\\\r\\\\n    background: rgba(255, 255, 255, 0.6);\\\\r\\\\n    color: rgba(255, 255, 255, 0.6);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 14px;\\\\r\\\\n    padding: 20px 0px;\\\\r\\\\n    line-height: 120%;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.mini-widget {\\\\r\\\\n    height: 180px;\\\\r\\\\n    padding-top: 20px;\\\\r\\\\n    border: 1px solid #eee;\\\\r\\\\n    background-color: #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-date, .twitter-location {\\\\r\\\\n    margin-top: 30px;\\\\r\\\\n    font-size: 17px;\\\\r\\\\n    color: #434343;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.name {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #434343;\\\\r\\\\n    margin-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.username {\\\\r\\\\n    margin-top: 4px;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.avatar {\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n} > .item {\\\\r\\\\n    float: left;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.emojione {\\\\r\\\\n    width: 30px;\\\\r\\\\n    height: 30px\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\nbody {\\\\r\\\\n    font-family: \\\\\\\"Helvetica\\\\\\\", \\\\\\\"Arial\\\\\\\", sans-serif;\\\\r\\\\n    line-height: 1;\\\\r\\\\n    background-image: url(\'..\\\\\\/clouds.jpg\');\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: center;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.img-container img {\\\\r\\\\n    width: 50px;\\\\r\\\\n    height: 50px;\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-container {\\\\r\\\\n    padding: 10px;\\\\r\\\\n    width: 340px !important;\\\\r\\\\n    height: 200px !important;\\\\r\\\\n    background-color: rgba(255, 255, 255, 0.6);\\\\r\\\\n    background: rgba(255, 255, 255, 0.6);\\\\r\\\\n    color: rgba(255, 255, 255, 0.6);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-tweet {\\\\r\\\\n    font-size: 14px;\\\\r\\\\n    padding: 20px 0px;\\\\r\\\\n    line-height: 120%;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.mini-widget {\\\\r\\\\n    height: 180px;\\\\r\\\\n    padding-top: 20px;\\\\r\\\\n    border: 1px solid #eee;\\\\r\\\\n    background-color: #fff;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.twitter-date, .twitter-location {\\\\r\\\\n    margin-top: 30px;\\\\r\\\\n    font-size: 17px;\\\\r\\\\n    color: #434343;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.name {\\\\r\\\\n    font-size: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    color: #434343;\\\\r\\\\n    margin-top: 5px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.username {\\\\r\\\\n    margin-top: 2px;\\\\r\\\\n    color: #434343;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.avatar {\\\\r\\\\n    border: 3px solid #fff;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(233,1585146842,1,'Saved','Widget',23,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(234,1585146867,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"340 > 370\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(235,1585146900,1,'Saved','Widget',23,'{\"widgetOptions\":\"[\\n    {\\n        \\\"backgroundColor\\\": \\\"rgba(255,255,255,0.4) > rgba(255,255,255,0)\\\"\\n    }\\n]\",\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(236,1585146911,1,'Saved','Widget',23,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(237,1585146924,1,'Saved','Playlist',24,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(238,1585146924,1,'Saved','Region',24,'{\"width\":\"1313 > 1164.41\",\"height\":\"657 > 641.56\",\"top\":\"202 > 209.68\",\"left\":\"295 > 387.17\",\"campaignId\":[\"5\"]}'),(239,1585147001,1,'Saved','Playlist',24,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(240,1585147001,1,'Saved','Region',24,'{\"width\":\"1164 > 1051.26\",\"top\":\"210 > 202.31\",\"left\":\"387 > 451.01\",\"campaignId\":[\"5\"]}'),(241,1585147083,1,'Saved','Widget',23,'{\"campaignId\":[\"5\"],\"layoutId\":[\"10\"]}'),(242,1585147096,1,'Updated Draft','Layout',10,'{\"status\":\"1 > 3\",\"campaignId\":[5]}'),(243,1585147122,1,'Deleted','Playlist',13,'{\"playlistId\":13,\"regionId\":13}'),(244,1585147122,1,'Region Deleted','Region',13,'{\"regionId\":13,\"layoutId\":5}'),(245,1585147122,1,'Layout Deleted','Layout',5,'{\"layoutId\":5}'),(246,1585147122,1,'Deleted draft for 10','Layout',5,'{\"parentId\":\" > 10\"}'),(247,1585147122,1,'Updated Draft','Layout',10,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[5]}'),(248,1585147275,1,'Added','Schedule',1,'{\"eventId\":1,\"eventTypeId\":5,\"campaignId\":8,\"commandId\":null,\"displayGroups\":[{\"displayGroupId\":3,\"displayGroup\":\"Tous\",\"description\":null,\"isDisplaySpecific\":0,\"isDynamic\":0,\"dynamicCriteria\":null,\"dynamicCriteriaTags\":null,\"userId\":1,\"tags\":null,\"tagValues\":null,\"bandwidthLimit\":\"0\"}],\"scheduleReminders\":[],\"userId\":1,\"fromDt\":0,\"toDt\":2147483647,\"isPriority\":0,\"displayOrder\":0,\"recurrenceType\":null,\"recurrenceDetail\":null,\"recurrenceRange\":null,\"recurrenceRepeatsOn\":null,\"recurrenceMonthlyRepeatsOn\":null,\"campaign\":null,\"command\":null,\"dayPartId\":2,\"isAlways\":null,\"isCustom\":null,\"syncEvent\":0,\"syncTimezone\":0,\"shareOfVoice\":null,\"isGeoAware\":0,\"geoLocation\":null}'),(249,1585147308,1,'Display Saved','Display',1,'[]'),(250,1585147325,1,'Display Saved','Display',1,'[]'),(251,1585147335,1,'Display Saved','Display',2,'[]'),(252,1585147442,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(253,1585149966,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(254,1585151092,1,'Updated Draft','Layout',9,'{\"status\":\"1 > 3\",\"campaignId\":[2]}'),(255,1585151877,1,'Deleted','Widget',3,'{\"widgetId\":3,\"playlistId\":3}'),(256,1585151877,1,'Deleted','Playlist',3,'{\"playlistId\":3,\"regionId\":3}'),(257,1585151877,1,'Region Deleted','Region',3,'{\"regionId\":3,\"layoutId\":2}'),(258,1585151877,1,'Deleted','Widget',4,'{\"widgetId\":4,\"playlistId\":4}'),(259,1585151877,1,'Deleted','Playlist',4,'{\"playlistId\":4,\"regionId\":4}'),(260,1585151877,1,'Region Deleted','Region',4,'{\"regionId\":4,\"layoutId\":2}'),(261,1585151877,1,'Deleted','Widget',5,'{\"widgetId\":5,\"playlistId\":5}'),(262,1585151877,1,'Deleted','Playlist',5,'{\"playlistId\":5,\"regionId\":5}'),(263,1585151877,1,'Region Deleted','Region',5,'{\"regionId\":5,\"layoutId\":2}'),(264,1585151877,1,'Deleted','Widget',6,'{\"widgetId\":6,\"playlistId\":6}'),(265,1585151877,1,'Deleted','Playlist',6,'{\"playlistId\":6,\"regionId\":6}'),(266,1585151877,1,'Region Deleted','Region',6,'{\"regionId\":6,\"layoutId\":2}'),(267,1585151877,1,'Layout Deleted','Layout',2,'{\"layoutId\":2}'),(268,1585151877,1,'Deleted draft for 9','Layout',2,'{\"parentId\":\" > 9\"}'),(269,1585151877,1,'Updated Draft','Layout',9,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[2]}'),(270,1585151896,1,'Added','Layout',11,'{\"layoutId\":11,\"layout\":\"AffichePaysage + Horloge Mod\\u00e8le\",\"campaignId\":9}'),(271,1585151896,1,'Added','Widget',24,'{\"widgetId\":24,\"type\":\"image\",\"layoutId\":\"11\",\"campaignId\":\"9\"}'),(272,1585151896,1,'Saved','Widget',24,'{\"widgetId\":\"19 > 24\",\"playlistId\":\"20 > 25\"}'),(273,1585151896,1,'Saved','Playlist',25,'{\"playlistId\":\"20 > 25\",\"regionId\":\"20 > 25\",\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(274,1585151896,1,'Added','Region',25,'{\"regionId\":25,\"campaignId\":\"9\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 25, LayoutId = 11. OwnerId = 1. Duration = 30\"}'),(275,1585151896,1,'Added','Widget',25,'{\"widgetId\":25,\"type\":\"clock\",\"layoutId\":\"11\",\"campaignId\":\"9\"}'),(276,1585151896,1,'Saved','Widget',25,'{\"widgetId\":\"20 > 25\",\"playlistId\":\"21 > 26\"}'),(277,1585151896,1,'Saved','Playlist',26,'{\"playlistId\":\"21 > 26\",\"regionId\":\"21 > 26\",\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(278,1585151896,1,'Added','Region',26,'{\"regionId\":26,\"campaignId\":\"9\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 26, LayoutId = 11. OwnerId = 1. Duration = 5\"}'),(279,1585151896,1,'Added','Widget',26,'{\"widgetId\":26,\"type\":\"image\",\"layoutId\":\"11\",\"campaignId\":\"9\"}'),(280,1585151896,1,'Saved','Widget',26,'{\"widgetId\":\"21 > 26\",\"playlistId\":\"22 > 27\"}'),(281,1585151896,1,'Saved','Playlist',27,'{\"playlistId\":\"22 > 27\",\"regionId\":\"22 > 27\",\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(282,1585151896,1,'Added','Region',27,'{\"regionId\":27,\"campaignId\":\"9\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 27, LayoutId = 11. OwnerId = 1. Duration = 10\"}'),(283,1585151896,1,'Added','Widget',27,'{\"widgetId\":27,\"type\":\"image\",\"layoutId\":\"11\",\"campaignId\":\"9\"}'),(284,1585151896,1,'Saved','Widget',27,'{\"widgetId\":\"22 > 27\",\"playlistId\":\"23 > 28\"}'),(285,1585151896,1,'Saved','Playlist',28,'{\"playlistId\":\"23 > 28\",\"regionId\":\"23 > 28\",\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(286,1585151896,1,'Added','Region',28,'{\"regionId\":28,\"campaignId\":\"9\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 28, LayoutId = 11. OwnerId = 1. Duration = 10\"}'),(287,1585152109,1,'Added','Layout',12,'{\"layoutId\":12,\"layout\":\"M\\u00e9t\\u00e9o\",\"campaignId\":10}'),(288,1585152109,1,'Added','Widget',28,'{\"widgetId\":28,\"type\":\"image\",\"layoutId\":\"12\",\"campaignId\":\"10\"}'),(289,1585152109,1,'Saved','Widget',28,'{\"widgetId\":\"24 > 28\",\"playlistId\":\"25 > 29\"}'),(290,1585152109,1,'Saved','Playlist',29,'{\"playlistId\":\"25 > 29\",\"regionId\":\"25 > 29\",\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(291,1585152109,1,'Added','Region',29,'{\"regionId\":29,\"campaignId\":\"10\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 29, LayoutId = 12. OwnerId = 1. Duration = 0\"}'),(292,1585152109,1,'Added','Widget',29,'{\"widgetId\":29,\"type\":\"clock\",\"layoutId\":\"12\",\"campaignId\":\"10\"}'),(293,1585152109,1,'Saved','Widget',29,'{\"widgetId\":\"25 > 29\",\"playlistId\":\"26 > 30\"}'),(294,1585152109,1,'Saved','Playlist',30,'{\"playlistId\":\"26 > 30\",\"regionId\":\"26 > 30\",\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(295,1585152109,1,'Added','Region',30,'{\"regionId\":30,\"campaignId\":\"10\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 30, LayoutId = 12. OwnerId = 1. Duration = 0\"}'),(296,1585152109,1,'Added','Widget',30,'{\"widgetId\":30,\"type\":\"image\",\"layoutId\":\"12\",\"campaignId\":\"10\"}'),(297,1585152109,1,'Saved','Widget',30,'{\"widgetId\":\"26 > 30\",\"playlistId\":\"27 > 31\"}'),(298,1585152109,1,'Saved','Playlist',31,'{\"playlistId\":\"27 > 31\",\"regionId\":\"27 > 31\",\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(299,1585152109,1,'Added','Region',31,'{\"regionId\":31,\"campaignId\":\"10\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 31, LayoutId = 12. OwnerId = 1. Duration = 0\"}'),(300,1585152109,1,'Added','Widget',31,'{\"widgetId\":31,\"type\":\"image\",\"layoutId\":\"12\",\"campaignId\":\"10\"}'),(301,1585152109,1,'Saved','Widget',31,'{\"widgetId\":\"27 > 31\",\"playlistId\":\"28 > 32\"}'),(302,1585152109,1,'Saved','Playlist',32,'{\"playlistId\":\"28 > 32\",\"regionId\":\"28 > 32\",\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(303,1585152109,1,'Added','Region',32,'{\"regionId\":32,\"campaignId\":\"10\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 32, LayoutId = 12. OwnerId = 1. Duration = 0\"}'),(304,1585152109,1,'Checked out','Layout',13,'{\"layoutId\":12,\"layout\":\"M\\u00e9t\\u00e9o\",\"campaignId\":10}'),(305,1585152109,1,'Added','Widget',32,'{\"widgetId\":32,\"type\":\"image\",\"layoutId\":\"13\",\"campaignId\":\"10\"}'),(306,1585152109,1,'Saved','Widget',32,'{\"widgetId\":\"28 > 32\",\"playlistId\":\"29 > 33\"}'),(307,1585152109,1,'Saved','Playlist',33,'{\"playlistId\":\"29 > 33\",\"regionId\":\"29 > 33\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(308,1585152109,1,'Added','Region',33,'{\"regionId\":33,\"campaignId\":\"10\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 33, LayoutId = 13. OwnerId = 1. Duration = 0\"}'),(309,1585152109,1,'Added','Widget',33,'{\"widgetId\":33,\"type\":\"clock\",\"layoutId\":\"13\",\"campaignId\":\"10\"}'),(310,1585152109,1,'Saved','Widget',33,'{\"widgetId\":\"29 > 33\",\"playlistId\":\"30 > 34\"}'),(311,1585152109,1,'Saved','Playlist',34,'{\"playlistId\":\"30 > 34\",\"regionId\":\"30 > 34\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(312,1585152109,1,'Added','Region',34,'{\"regionId\":34,\"campaignId\":\"10\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 34, LayoutId = 13. OwnerId = 1. Duration = 0\"}'),(313,1585152109,1,'Added','Widget',34,'{\"widgetId\":34,\"type\":\"image\",\"layoutId\":\"13\",\"campaignId\":\"10\"}'),(314,1585152109,1,'Saved','Widget',34,'{\"widgetId\":\"30 > 34\",\"playlistId\":\"31 > 35\"}'),(315,1585152109,1,'Saved','Playlist',35,'{\"playlistId\":\"31 > 35\",\"regionId\":\"31 > 35\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(316,1585152109,1,'Added','Region',35,'{\"regionId\":35,\"campaignId\":\"10\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 35, LayoutId = 13. OwnerId = 1. Duration = 0\"}'),(317,1585152109,1,'Added','Widget',35,'{\"widgetId\":35,\"type\":\"image\",\"layoutId\":\"13\",\"campaignId\":\"10\"}'),(318,1585152109,1,'Saved','Widget',35,'{\"widgetId\":\"31 > 35\",\"playlistId\":\"32 > 36\"}'),(319,1585152109,1,'Saved','Playlist',36,'{\"playlistId\":\"32 > 36\",\"regionId\":\"32 > 36\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(320,1585152109,1,'Added','Region',36,'{\"regionId\":36,\"campaignId\":\"10\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 36, LayoutId = 13. OwnerId = 1. Duration = 0\"}'),(321,1585152109,1,'Updated','Layout',12,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[10]}'),(322,1585152111,1,'Saved','Playlist',33,'{\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(323,1585152111,1,'Saved','Playlist',34,'{\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(324,1585152111,1,'Saved','Playlist',35,'{\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(325,1585152111,1,'Saved','Playlist',36,'{\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(326,1585152301,0,'Saved','Playlist',29,'{\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(327,1585152301,0,'Saved','Playlist',30,'{\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(328,1585152301,0,'Saved','Playlist',31,'{\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(329,1585152301,0,'Saved','Playlist',32,'{\"campaignId\":[\"10\"],\"layoutId\":[\"12\"]}'),(330,1585152332,1,'Added','Widget',36,'{\"widgetId\":36,\"type\":\"forecastio\",\"layoutId\":\"13\",\"campaignId\":\"10\"}'),(331,1585152332,1,'Saved','Widget',36,'{\"widgetId\":36,\"playlistId\":\"33\",\"ownerId\":1,\"type\":\"forecastio\",\"duration\":60,\"displayOrder\":2,\"useDuration\":0,\"calculatedDuration\":60,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":36,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":36,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":36,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(332,1585152334,1,'Saved','Playlist',33,'{\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(333,1585152543,1,'Saved','Widget',36,'{\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(334,1585152583,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"lang\\\": \\\"en > fr\\\"\\n    },\\n    {\\n        \\\"name\\\": \\\" > M\\\\u00e9t\\\\u00e9o\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(335,1585152596,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"weather-module5l > weather-module3l\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(336,1585152601,0,'Saved','Playlist',33,'{\"duration\":\"0 > 90\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(337,1585152618,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"weather-module3l > weather-module2l\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(338,1585152639,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"weather-module2l > weather-module1l\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(339,1585152677,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"overrideTemplate\\\": \\\"0 > 1\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(340,1585152779,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate_advanced\\\": \\\"0 > 1\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(341,1585152807,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate_advanced\\\": \\\"1 > 0\\\"\\n    },\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n    <div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n        <div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n            <h1 class=\\\\\\\"date shadowed\\\\\\\"> [time|M] <br>[time|d]<\\\\\\/h1>\\\\r\\\\n        <\\\\\\/div>\\\\r\\\\n        <div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n            <div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]\\\\u00ba[temperatureUnit]<\\\\\\/div>\\\\r\\\\n            <div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\"><i class=\\\\\\\"wi [wicon]\\\\\\\"><\\\\\\/i><\\\\\\/div>\\\\r\\\\n        <\\\\\\/div>\\\\r\\\\n    <\\\\\\/div>\\\\r\\\\n    <div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n        <div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n            <div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n            <div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n            <div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n        <\\\\\\/div>\\\\r\\\\n        <div class=\\\\\\\"upcoming\\\\\\\">\\\\r\\\\n            [dailyForecast|4|1]\\\\r\\\\n        <\\\\\\/div>\\\\r\\\\n    <\\\\\\/div>\\\\r\\\\n<\\\\\\/div> > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|d]<br \\\\\\/>\\\\r\\\\n[time|M]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(342,1585152823,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|d]<br \\\\\\/>\\\\r\\\\n[time|M]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|d]<br \\\\\\/>\\\\r\\\\n[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(343,1585152884,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|d]<br \\\\\\/>\\\\r\\\\n[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(344,1585152982,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(345,1585153001,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(346,1585153054,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Wind||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidity||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(347,1585153149,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 106px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.9;\\\\r\\\\n    padding: 30px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 260px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 15px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n} > #content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 106px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.9;\\\\r\\\\n    padding: 0px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 260px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 15px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(348,1585153186,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 106px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.9;\\\\r\\\\n    padding: 0px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 260px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 15px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n} > #content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 80px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.8;\\\\r\\\\n    padding: 10px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 260px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 15px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(349,1585153212,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 80px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.8;\\\\r\\\\n    padding: 10px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 260px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 15px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n} > #content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 150px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.8;\\\\r\\\\n    padding: 10px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 260px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 15px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(350,1585153289,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 150px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.8;\\\\r\\\\n    padding: 10px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 260px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 15px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n} > #content { \\\\r\\\\n  height: inherit; \\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.shadowed {\\\\r\\\\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\\\\r\\\\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-div {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    background-repeat: no-repeat;\\\\r\\\\n    background-size: cover;\\\\r\\\\n    background-position: left;\\\\r\\\\n    width: 1920px !important;\\\\r\\\\n    height: 1080px !important;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-cloudy {\\\\r\\\\n  background-image: url(\'[cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-day {\\\\r\\\\n  background-image: url(\'[day-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-day {\\\\r\\\\n  background-image: url(\'[day-sunny-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-fog {\\\\r\\\\n  background-image: url(\'[fog-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-sleet {\\\\r\\\\n  background-image: url(\'[hail-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-clear-night {\\\\r\\\\n  background-image: url(\'[night-clear-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-partly-cloudy-night {\\\\r\\\\n  background-image: url(\'[night-partly-cloudy-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-rain {\\\\r\\\\n  background-image: url(\'[rain-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-snow {\\\\r\\\\n  background-image: url(\'[snow-image]\');\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.bg-wind {\\\\r\\\\n  background-image: url(\'[windy-image]\');\\\\r\\\\n}\\\\r\\\\n.bg-footer {\\\\r\\\\n    position: relative;\\\\r\\\\n    right: 0;\\\\r\\\\n    top: 106px;\\\\r\\\\n    left: 0;\\\\r\\\\n    text-align: center;\\\\r\\\\n    background-color: #000;\\\\r\\\\n    opacity: 0.8;\\\\r\\\\n    padding: 10px 0 0 0;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.date {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 100px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n    text-transform: uppercase;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 300px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-weight: 900;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.city {\\\\r\\\\n    font-family: \'Roboto\', sans-serif;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    margin-left: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.day-details {\\\\r\\\\n    font-size: 40px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-style: italic;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.temp-details {\\\\r\\\\n    font-size: 35px;\\\\r\\\\n    color: #fff;\\\\r\\\\n    padding-bottom: 10px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-current {\\\\r\\\\n    font-weight: 900;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.forecast-second {\\\\r\\\\n    margin-top: 10px;\\\\r\\\\n    font-weight: 200;\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 40px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.main-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 180px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.second-icon {\\\\r\\\\n    color: #fff;\\\\r\\\\n    font-size: 60px;\\\\r\\\\n    padding: 25px 0px;\\\\r\\\\n}\\\\r\\\\n\\\\r\\\\n.powered {\\\\r\\\\n    padding: 0px 0;\\\\r\\\\n    color: #000;\\\\r\\\\n    font-size: 24px;\\\\r\\\\n    background-color: white;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(351,1585153341,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-5 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(352,1585153374,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-5 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-3 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(353,1585153387,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-3 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-2 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(354,1585153446,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-2 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|5|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1> class=\\\\\\\"city\\\\\\\">Vandoeuvre-l\\\\u00e8s-Nancy<\\\\\\/h1>\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(355,1585153459,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1> class=\\\\\\\"city\\\\\\\">Vandoeuvre-l\\\\u00e8s-Nancy<\\\\\\/h1>\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"city\\\\\\\">Vandoeuvre-l\\\\u00e8s-Nancy<\\\\\\/h1>\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(356,1585153515,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"city\\\\\\\">Vandoeuvre-l\\\\u00e8s-Nancy<\\\\\\/h1>\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"city\\\\\\\">Vand\\\\u0153uvre-l\\\\u00e8s-Nancy<\\\\\\/h1>\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(357,1585153555,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"city\\\\\\\">Vand\\\\u0153uvre-l\\\\u00e8s-Nancy<\\\\\\/h1>\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit] <\\\\\\/br>\\\\r\\\\n<h1 class=\\\\\\\"city\\\\\\\">Vand\\\\u0153uvre-l\\\\u00e8s-Nancy<\\\\\\/h1><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(358,1585153601,1,'Saved','Widget',36,'{\"widgetOptions\":\"[\\n    {\\n        \\\"currentTemplate\\\": \\\"<div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit] <\\\\\\/br>\\\\r\\\\n<h1 class=\\\\\\\"city\\\\\\\">Vand\\\\u0153uvre-l\\\\u00e8s-Nancy<\\\\\\/h1><\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n > <div class=\\\\\\\"bg-div bg-[icon] container-fluid\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-6\\\\\\\">\\\\r\\\\n<h1 class=\\\\\\\"city\\\\\\\">Vand\\\\u0153uvre-l\\\\u00e8s-Nancy<\\\\\\/h1>\\\\r\\\\n<h1 class=\\\\\\\"date shadowed\\\\\\\">[time|D]<br \\\\\\/>\\\\r\\\\n[time|d]\\\\\\/[time|m]<\\\\\\/h1>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"col-xs-5\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row text-right temp shadowed\\\\\\\">[temperatureRound]&ordm;[temperatureUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row pull-right animated rotateInUpRight main-icon shadowed\\\\\\\">&nbsp;<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"bg-footer row bottom-bar\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"col-xs-4 text-center\\\\\\\">\\\\r\\\\n<div class=\\\\\\\"row forecast-current\\\\\\\">[summary]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"row forecast-second\\\\\\\">||Humidit\\\\u00e9||: [humidityPercent]%<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\\r\\\\n<div class=\\\\\\\"upcoming\\\\\\\">[dailyForecast|4|1]<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n<\\\\\\/div>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(359,1585153679,1,'Deleted','Widget',32,'{\"widgetId\":32,\"playlistId\":33}'),(360,1585153682,1,'Saved','Playlist',33,'{\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(361,1585153710,1,'Deleted','Widget',28,'{\"widgetId\":28,\"playlistId\":29}'),(362,1585153710,1,'Deleted','Playlist',29,'{\"playlistId\":29,\"regionId\":29}'),(363,1585153710,1,'Region Deleted','Region',29,'{\"regionId\":29,\"layoutId\":12}'),(364,1585153710,1,'Deleted','Widget',29,'{\"widgetId\":29,\"playlistId\":30}'),(365,1585153710,1,'Deleted','Playlist',30,'{\"playlistId\":30,\"regionId\":30}'),(366,1585153710,1,'Region Deleted','Region',30,'{\"regionId\":30,\"layoutId\":12}'),(367,1585153710,1,'Deleted','Widget',30,'{\"widgetId\":30,\"playlistId\":31}'),(368,1585153710,1,'Deleted','Playlist',31,'{\"playlistId\":31,\"regionId\":31}'),(369,1585153710,1,'Region Deleted','Region',31,'{\"regionId\":31,\"layoutId\":12}'),(370,1585153710,1,'Deleted','Widget',31,'{\"widgetId\":31,\"playlistId\":32}'),(371,1585153710,1,'Deleted','Playlist',32,'{\"playlistId\":32,\"regionId\":32}'),(372,1585153710,1,'Region Deleted','Region',32,'{\"regionId\":32,\"layoutId\":12}'),(373,1585153710,1,'Layout Deleted','Layout',12,'{\"layoutId\":12}'),(374,1585153710,1,'Deleted draft for 13','Layout',12,'{\"parentId\":\" > 13\"}'),(375,1585153710,1,'Updated Draft','Layout',13,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[10]}'),(376,1585153737,1,'Updated','Layout',13,'{\"layout\":\"M\\u00e9t\\u00e9o > M\\u00e9t\\u00e9o + Logos et horloge\",\"campaignId\":[10]}'),(377,1585153752,1,'Checked out','Layout',14,'{\"layoutId\":13,\"layout\":\"M\\u00e9t\\u00e9o + Logos et horloge\",\"campaignId\":10}'),(378,1585153752,1,'Added','Widget',37,'{\"widgetId\":37,\"type\":\"forecastio\",\"layoutId\":\"14\",\"campaignId\":\"10\"}'),(379,1585153752,1,'Saved','Widget',37,'{\"widgetId\":\"36 > 37\",\"playlistId\":\"33 > 37\",\"displayOrder\":\"2 > 1\"}'),(380,1585153752,1,'Saved','Playlist',37,'{\"playlistId\":\"33 > 37\",\"regionId\":\"33 > 37\",\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(381,1585153752,1,'Added','Region',37,'{\"regionId\":37,\"campaignId\":\"10\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 37, LayoutId = 14. OwnerId = 1. Duration = 60\"}'),(382,1585153752,1,'Added','Widget',38,'{\"widgetId\":38,\"type\":\"clock\",\"layoutId\":\"14\",\"campaignId\":\"10\"}'),(383,1585153752,1,'Saved','Widget',38,'{\"widgetId\":\"33 > 38\",\"playlistId\":\"34 > 38\"}'),(384,1585153752,1,'Saved','Playlist',38,'{\"playlistId\":\"34 > 38\",\"regionId\":\"34 > 38\",\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(385,1585153752,1,'Added','Region',38,'{\"regionId\":38,\"campaignId\":\"10\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 38, LayoutId = 14. OwnerId = 1. Duration = 5\"}'),(386,1585153752,1,'Added','Widget',39,'{\"widgetId\":39,\"type\":\"image\",\"layoutId\":\"14\",\"campaignId\":\"10\"}'),(387,1585153752,1,'Saved','Widget',39,'{\"widgetId\":\"34 > 39\",\"playlistId\":\"35 > 39\"}'),(388,1585153752,1,'Saved','Playlist',39,'{\"playlistId\":\"35 > 39\",\"regionId\":\"35 > 39\",\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(389,1585153752,1,'Added','Region',39,'{\"regionId\":39,\"campaignId\":\"10\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 39, LayoutId = 14. OwnerId = 1. Duration = 10\"}'),(390,1585153752,1,'Added','Widget',40,'{\"widgetId\":40,\"type\":\"image\",\"layoutId\":\"14\",\"campaignId\":\"10\"}'),(391,1585153752,1,'Saved','Widget',40,'{\"widgetId\":\"35 > 40\",\"playlistId\":\"36 > 40\"}'),(392,1585153752,1,'Saved','Playlist',40,'{\"playlistId\":\"36 > 40\",\"regionId\":\"36 > 40\",\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(393,1585153752,1,'Added','Region',40,'{\"regionId\":40,\"campaignId\":\"10\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 40, LayoutId = 14. OwnerId = 1. Duration = 10\"}'),(394,1585153752,1,'Updated','Layout',13,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[10]}'),(395,1585153755,1,'Saved','Playlist',37,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(396,1585153755,1,'Saved','Playlist',38,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(397,1585153755,1,'Saved','Playlist',39,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(398,1585153755,1,'Saved','Playlist',40,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(399,1585153762,1,'Saved','Widget',37,'{\"duration\":\"60 > 30\",\"useDuration\":\"0 > 1\",\"calculatedDuration\":\"60 > 30\",\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(400,1585153764,1,'Saved','Playlist',37,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(401,1585153785,1,'Saved','Widget',37,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(402,1585153800,0,'Saved','Playlist',37,'{\"duration\":\"0 > 30\",\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(403,1585153800,0,'Saved','Playlist',33,'{\"duration\":\"90 > 60\",\"campaignId\":[\"10\"],\"layoutId\":[\"13\"]}'),(404,1585153840,1,'Saved','Widget',38,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(405,1585153848,1,'Saved','Widget',39,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(406,1585153858,1,'Saved','Widget',40,'{\"campaignId\":[\"10\"],\"layoutId\":[\"14\"]}'),(407,1585153872,1,'Updated Draft','Layout',14,'{\"status\":\"1 > 3\",\"campaignId\":[10]}'),(408,1585153881,1,'Deleted','Widget',36,'{\"widgetId\":36,\"playlistId\":33}'),(409,1585153881,1,'Deleted','Playlist',33,'{\"playlistId\":33,\"regionId\":33}'),(410,1585153881,1,'Region Deleted','Region',33,'{\"regionId\":33,\"layoutId\":13}'),(411,1585153881,1,'Deleted','Widget',33,'{\"widgetId\":33,\"playlistId\":34}'),(412,1585153881,1,'Deleted','Playlist',34,'{\"playlistId\":34,\"regionId\":34}'),(413,1585153881,1,'Region Deleted','Region',34,'{\"regionId\":34,\"layoutId\":13}'),(414,1585153881,1,'Deleted','Widget',34,'{\"widgetId\":34,\"playlistId\":35}'),(415,1585153881,1,'Deleted','Playlist',35,'{\"playlistId\":35,\"regionId\":35}'),(416,1585153881,1,'Region Deleted','Region',35,'{\"regionId\":35,\"layoutId\":13}'),(417,1585153881,1,'Deleted','Widget',35,'{\"widgetId\":35,\"playlistId\":36}'),(418,1585153881,1,'Deleted','Playlist',36,'{\"playlistId\":36,\"regionId\":36}'),(419,1585153881,1,'Region Deleted','Region',36,'{\"regionId\":36,\"layoutId\":13}'),(420,1585153881,1,'Layout Deleted','Layout',13,'{\"layoutId\":13}'),(421,1585153881,1,'Deleted draft for 14','Layout',13,'{\"parentId\":\" > 14\"}'),(422,1585153881,1,'Updated Draft','Layout',14,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[10]}'),(423,1585154105,1,'Added','Layout',15,'{\"layoutId\":15,\"layout\":\"M\\u00e9t\\u00e9o seule\",\"campaignId\":11}'),(424,1585154105,1,'Added','Widget',41,'{\"widgetId\":41,\"type\":\"forecastio\",\"layoutId\":\"15\",\"campaignId\":\"11\"}'),(425,1585154105,1,'Saved','Widget',41,'{\"widgetId\":\"37 > 41\",\"playlistId\":\"37 > 41\"}'),(426,1585154105,1,'Saved','Playlist',41,'{\"playlistId\":\"37 > 41\",\"regionId\":\"37 > 41\",\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(427,1585154105,1,'Added','Region',41,'{\"regionId\":41,\"campaignId\":\"11\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 41, LayoutId = 15. OwnerId = 1. Duration = 30\"}'),(428,1585154105,1,'Added','Widget',42,'{\"widgetId\":42,\"type\":\"clock\",\"layoutId\":\"15\",\"campaignId\":\"11\"}'),(429,1585154105,1,'Saved','Widget',42,'{\"widgetId\":\"38 > 42\",\"playlistId\":\"38 > 42\"}'),(430,1585154105,1,'Saved','Playlist',42,'{\"playlistId\":\"38 > 42\",\"regionId\":\"38 > 42\",\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(431,1585154105,1,'Added','Region',42,'{\"regionId\":42,\"campaignId\":\"11\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 42, LayoutId = 15. OwnerId = 1. Duration = 5\"}'),(432,1585154105,1,'Added','Widget',43,'{\"widgetId\":43,\"type\":\"image\",\"layoutId\":\"15\",\"campaignId\":\"11\"}'),(433,1585154105,1,'Saved','Widget',43,'{\"widgetId\":\"39 > 43\",\"playlistId\":\"39 > 43\"}'),(434,1585154105,1,'Saved','Playlist',43,'{\"playlistId\":\"39 > 43\",\"regionId\":\"39 > 43\",\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(435,1585154105,1,'Added','Region',43,'{\"regionId\":43,\"campaignId\":\"11\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 43, LayoutId = 15. OwnerId = 1. Duration = 10\"}'),(436,1585154105,1,'Added','Widget',44,'{\"widgetId\":44,\"type\":\"image\",\"layoutId\":\"15\",\"campaignId\":\"11\"}'),(437,1585154105,1,'Saved','Widget',44,'{\"widgetId\":\"40 > 44\",\"playlistId\":\"40 > 44\"}'),(438,1585154105,1,'Saved','Playlist',44,'{\"playlistId\":\"40 > 44\",\"regionId\":\"40 > 44\",\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(439,1585154105,1,'Added','Region',44,'{\"regionId\":44,\"campaignId\":\"11\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 44, LayoutId = 15. OwnerId = 1. Duration = 10\"}'),(440,1585154111,1,'Saved','Playlist',41,'{\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(441,1585154111,1,'Saved','Playlist',42,'{\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(442,1585154111,1,'Saved','Playlist',43,'{\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(443,1585154111,1,'Saved','Playlist',44,'{\"campaignId\":[\"11\"],\"layoutId\":[\"15\"]}'),(444,1585154114,1,'Checked out','Layout',16,'{\"layoutId\":15,\"layout\":\"M\\u00e9t\\u00e9o seule\",\"campaignId\":11}'),(445,1585154114,1,'Added','Widget',45,'{\"widgetId\":45,\"type\":\"forecastio\",\"layoutId\":\"16\",\"campaignId\":\"11\"}'),(446,1585154114,1,'Saved','Widget',45,'{\"widgetId\":\"41 > 45\",\"playlistId\":\"41 > 45\"}'),(447,1585154114,1,'Saved','Playlist',45,'{\"playlistId\":\"41 > 45\",\"regionId\":\"41 > 45\",\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(448,1585154114,1,'Added','Region',45,'{\"regionId\":45,\"campaignId\":\"11\",\"details\":\"Region Affiche_jpeg - 1855 x 812 (17, 31). RegionId = 45, LayoutId = 16. OwnerId = 1. Duration = 30\"}'),(449,1585154114,1,'Added','Widget',46,'{\"widgetId\":46,\"type\":\"clock\",\"layoutId\":\"16\",\"campaignId\":\"11\"}'),(450,1585154114,1,'Saved','Widget',46,'{\"widgetId\":\"42 > 46\",\"playlistId\":\"42 > 46\"}'),(451,1585154114,1,'Saved','Playlist',46,'{\"playlistId\":\"42 > 46\",\"regionId\":\"42 > 46\",\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(452,1585154114,1,'Added','Region',46,'{\"regionId\":46,\"campaignId\":\"11\",\"details\":\"Region Heure - 785 x 188 (852, 1069). RegionId = 46, LayoutId = 16. OwnerId = 1. Duration = 5\"}'),(453,1585154114,1,'Added','Widget',47,'{\"widgetId\":47,\"type\":\"image\",\"layoutId\":\"16\",\"campaignId\":\"11\"}'),(454,1585154114,1,'Saved','Widget',47,'{\"widgetId\":\"43 > 47\",\"playlistId\":\"43 > 47\"}'),(455,1585154114,1,'Saved','Playlist',47,'{\"playlistId\":\"43 > 47\",\"regionId\":\"43 > 47\",\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(456,1585154114,1,'Added','Region',47,'{\"regionId\":47,\"campaignId\":\"11\",\"details\":\"Region Logo Polytech - 331 x 122 (889, 634). RegionId = 47, LayoutId = 16. OwnerId = 1. Duration = 10\"}'),(457,1585154114,1,'Added','Widget',48,'{\"widgetId\":48,\"type\":\"image\",\"layoutId\":\"16\",\"campaignId\":\"11\"}'),(458,1585154114,1,'Saved','Widget',48,'{\"widgetId\":\"44 > 48\",\"playlistId\":\"44 > 48\"}'),(459,1585154114,1,'Saved','Playlist',48,'{\"playlistId\":\"44 > 48\",\"regionId\":\"44 > 48\",\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(460,1585154114,1,'Added','Region',48,'{\"regionId\":48,\"campaignId\":\"11\",\"details\":\"Region Logos UL + INP - 505 x 153 (872, 66). RegionId = 48, LayoutId = 16. OwnerId = 1. Duration = 10\"}'),(461,1585154114,1,'Updated','Layout',15,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[11]}'),(462,1585154117,1,'Saved','Playlist',45,'{\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(463,1585154117,1,'Saved','Playlist',46,'{\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(464,1585154117,1,'Saved','Playlist',47,'{\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(465,1585154117,1,'Saved','Playlist',48,'{\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(466,1585154134,1,'Deleted','Widget',48,'{\"widgetId\":48,\"playlistId\":48}'),(467,1585154134,1,'Deleted','Playlist',48,'{\"playlistId\":48,\"regionId\":48}'),(468,1585154134,1,'Region Deleted','Region',48,'{\"regionId\":48,\"layoutId\":16}'),(469,1585154141,1,'Deleted','Widget',47,'{\"widgetId\":47,\"playlistId\":47}'),(470,1585154141,1,'Deleted','Playlist',47,'{\"playlistId\":47,\"regionId\":47}'),(471,1585154141,1,'Region Deleted','Region',47,'{\"regionId\":47,\"layoutId\":16}'),(472,1585154147,1,'Deleted','Widget',46,'{\"widgetId\":46,\"playlistId\":46}'),(473,1585154147,1,'Deleted','Playlist',46,'{\"playlistId\":46,\"regionId\":46}'),(474,1585154147,1,'Region Deleted','Region',46,'{\"regionId\":46,\"layoutId\":16}'),(475,1585154187,1,'Saved','Playlist',45,'{\"name\":\"Affiche_jpeg > M\\u00e9t\\u00e9o\",\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(476,1585154187,1,'Saved','Region',45,'{\"name\":\"Affiche_jpeg > M\\u00e9t\\u00e9o\",\"width\":\"1855 > 1920\",\"height\":\"812 > 1080\",\"top\":\"17 > 0\",\"left\":\"31 > 0\",\"campaignId\":[\"11\"]}'),(477,1585154224,1,'Saved','Widget',45,'{\"widgetOptions\":\"[\\n    {\\n        \\\"transInDuration\\\": \\\"1000 > 2000\\\"\\n    }\\n]\",\"campaignId\":[\"11\"],\"layoutId\":[\"16\"]}'),(478,1585154235,1,'Updated Draft','Layout',16,'{\"status\":\"1 > 3\",\"campaignId\":[11]}'),(479,1585154243,1,'Deleted','Widget',41,'{\"widgetId\":41,\"playlistId\":41}'),(480,1585154243,1,'Deleted','Playlist',41,'{\"playlistId\":41,\"regionId\":41}'),(481,1585154243,1,'Region Deleted','Region',41,'{\"regionId\":41,\"layoutId\":15}'),(482,1585154243,1,'Deleted','Widget',42,'{\"widgetId\":42,\"playlistId\":42}'),(483,1585154243,1,'Deleted','Playlist',42,'{\"playlistId\":42,\"regionId\":42}'),(484,1585154243,1,'Region Deleted','Region',42,'{\"regionId\":42,\"layoutId\":15}'),(485,1585154243,1,'Deleted','Widget',43,'{\"widgetId\":43,\"playlistId\":43}'),(486,1585154243,1,'Deleted','Playlist',43,'{\"playlistId\":43,\"regionId\":43}'),(487,1585154243,1,'Region Deleted','Region',43,'{\"regionId\":43,\"layoutId\":15}'),(488,1585154243,1,'Deleted','Widget',44,'{\"widgetId\":44,\"playlistId\":44}'),(489,1585154243,1,'Deleted','Playlist',44,'{\"playlistId\":44,\"regionId\":44}'),(490,1585154243,1,'Region Deleted','Region',44,'{\"regionId\":44,\"layoutId\":15}'),(491,1585154243,1,'Layout Deleted','Layout',15,'{\"layoutId\":15}'),(492,1585154243,1,'Deleted draft for 16','Layout',15,'{\"parentId\":\" > 16\"}'),(493,1585154243,1,'Updated Draft','Layout',16,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[11]}'),(494,1585154445,1,'Display Saved','Display',3,'{\"licensed\":\"0 > 1\"}'),(495,1585155819,1,'Added','Layout',17,'{\"layoutId\":17,\"layout\":\"Trafic\",\"campaignId\":12}'),(496,1585155819,1,'Saved','Playlist',49,'{\"campaignId\":[\"12\"],\"layoutId\":[\"17\"]}'),(497,1585155819,1,'Added','Region',49,'{\"regionId\":49,\"campaignId\":\"12\",\"details\":\"Region Trafic-1 - 1920 x 1080 (0, 0). RegionId = 49, LayoutId = 17. OwnerId = 1. Duration = 0\"}'),(498,1585155819,1,'Checked out','Layout',18,'{\"layoutId\":17,\"layout\":\"Trafic\",\"campaignId\":12}'),(499,1585155819,1,'Saved','Playlist',50,'{\"playlistId\":\"49 > 50\",\"regionId\":\"49 > 50\",\"campaignId\":[\"12\"],\"layoutId\":[\"18\"]}'),(500,1585155819,1,'Added','Region',50,'{\"regionId\":50,\"campaignId\":\"12\",\"details\":\"Region Trafic-1 - 1920 x 1080 (0, 0). RegionId = 50, LayoutId = 18. OwnerId = 1. Duration = 0\"}'),(501,1585155819,1,'Updated','Layout',17,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[12]}'),(502,1585155832,1,'Added','Widget',49,'{\"widgetId\":49,\"type\":\"googletraffic\",\"layoutId\":\"18\",\"campaignId\":\"12\"}'),(503,1585155832,1,'Saved','Widget',49,'{\"widgetId\":49,\"playlistId\":\"50\",\"ownerId\":1,\"type\":\"googletraffic\",\"duration\":30,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":30,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":49,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":49,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":49,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(504,1585155833,1,'Saved','Playlist',50,'{\"campaignId\":[\"12\"],\"layoutId\":[\"18\"]}'),(505,1585155901,0,'Saved','Playlist',49,'{\"campaignId\":[\"12\"],\"layoutId\":[\"17\"]}'),(506,1585155901,0,'Saved','Playlist',50,'{\"duration\":\"0 > 30\",\"campaignId\":[\"12\"],\"layoutId\":[\"18\"]}'),(507,1585156113,1,'Deleted','Widget',49,'{\"widgetId\":49,\"playlistId\":50}'),(508,1585156113,1,'Deleted','Playlist',50,'{\"playlistId\":50,\"regionId\":50}'),(509,1585156113,1,'Region Deleted','Region',50,'{\"regionId\":50,\"layoutId\":18}'),(510,1585156113,1,'Layout Deleted','Layout',18,'{\"layoutId\":18}'),(511,1585156113,1,'Deleted draft for 17','Layout',18,'[]'),(512,1585156113,1,'Deleted','Playlist',49,'{\"playlistId\":49,\"regionId\":49}'),(513,1585156113,1,'Region Deleted','Region',49,'{\"regionId\":49,\"layoutId\":17}'),(514,1585156113,1,'Layout Deleted','Layout',17,'{\"layoutId\":17}'),(515,1585156113,1,'Deleted','Layout',17,'[]'),(516,1585156422,1,'Added','Layout',19,'{\"layoutId\":19,\"layout\":\"Compte \\u00e0 rebours 60 ans\",\"campaignId\":13}'),(517,1585156422,1,'Saved','Playlist',51,'{\"campaignId\":[\"13\"],\"layoutId\":[\"19\"]}'),(518,1585156422,1,'Added','Region',51,'{\"regionId\":51,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-1 - 1920 x 1080 (0, 0). RegionId = 51, LayoutId = 19. OwnerId = 1. Duration = 0\"}'),(519,1585156422,1,'Checked out','Layout',20,'{\"layoutId\":19,\"layout\":\"Compte \\u00e0 rebours 60 ans\",\"campaignId\":13}'),(520,1585156422,1,'Saved','Playlist',52,'{\"playlistId\":\"51 > 52\",\"regionId\":\"51 > 52\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(521,1585156422,1,'Added','Region',52,'{\"regionId\":52,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-1 - 1920 x 1080 (0, 0). RegionId = 52, LayoutId = 20. OwnerId = 1. Duration = 0\"}'),(522,1585156422,1,'Updated','Layout',19,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[13]}'),(523,1585156451,1,'Updated Draft','Layout',20,'{\"backgroundColor\":\"#000 > #1da4c2\",\"status\":\"4 > 3\",\"campaignId\":[13]}'),(524,1585156498,1,'Saved','Playlist',52,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(525,1585156498,1,'Saved','Region',52,'{\"width\":\"1920 > 928.05\",\"height\":\"1080 > 893.51\",\"top\":\"0 > 78.38\",\"left\":\"0 > 945.96\",\"campaignId\":[\"13\"]}'),(526,1585156501,0,'Saved','Playlist',52,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(527,1585156501,0,'Saved','Playlist',51,'{\"campaignId\":[\"13\"],\"layoutId\":[\"19\"]}'),(528,1585156501,1,'Updated Draft','Layout',20,'{\"campaignId\":[13]}'),(529,1585156501,1,'Saved','Playlist',53,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(530,1585156501,1,'Added','Region',53,'{\"regionId\":53,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-2 - 250 x 250 (50, 50). RegionId = 53, LayoutId = 20. OwnerId = 1. Duration = 0\"}'),(531,1585156514,1,'Saved','Playlist',53,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(532,1585156514,1,'Saved','Region',53,'{\"width\":\"250 > 844.56\",\"height\":\"250 > 249.96\",\"top\":\"50 > 79.69\",\"left\":\"50 > 60.77\",\"campaignId\":[\"13\"]}'),(533,1585156515,1,'Updated Draft','Layout',20,'{\"campaignId\":[13]}'),(534,1585156515,1,'Saved','Playlist',54,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(535,1585156515,1,'Added','Region',54,'{\"regionId\":54,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-3 - 250 x 250 (50, 50). RegionId = 54, LayoutId = 20. OwnerId = 1. Duration = 0\"}'),(536,1585156530,1,'Saved','Playlist',54,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(537,1585156530,1,'Saved','Region',54,'{\"width\":\"250 > 844.56\",\"height\":\"250 > 182.39\",\"top\":\"50 > 347.26\",\"left\":\"50 > 60.77\",\"campaignId\":[\"13\"]}'),(538,1585156536,1,'Updated Draft','Layout',20,'{\"campaignId\":[13]}'),(539,1585156536,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(540,1585156536,1,'Added','Region',55,'{\"regionId\":55,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-4 - 250 x 250 (50, 50). RegionId = 55, LayoutId = 20. OwnerId = 1. Duration = 0\"}'),(541,1585156542,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(542,1585156542,1,'Saved','Region',55,'{\"width\":\"250 > 249.96\",\"height\":\"250 > 282.39\",\"top\":\"50 > 558.07\",\"left\":\"50 > 63.47\",\"campaignId\":[\"13\"]}'),(543,1585156547,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(544,1585156547,1,'Saved','Region',55,'{\"width\":\"250 > 847.23\",\"height\":\"282 > 282.35\",\"top\":\"558 > 558.03\",\"left\":\"63 > 63.43\",\"campaignId\":[\"13\"]}'),(545,1585156549,1,'Updated Draft','Layout',20,'{\"campaignId\":[13]}'),(546,1585156549,1,'Saved','Playlist',56,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(547,1585156549,1,'Added','Region',56,'{\"regionId\":56,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-5 - 250 x 250 (50, 50). RegionId = 56, LayoutId = 20. OwnerId = 1. Duration = 0\"}'),(548,1585156567,1,'Saved','Playlist',56,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(549,1585156567,1,'Saved','Region',56,'{\"width\":\"250 > 855.38\",\"height\":\"250 > 163.47\",\"top\":\"50 > 812.13\",\"left\":\"50 > 58.07\",\"campaignId\":[\"13\"]}'),(550,1585156577,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(551,1585156577,1,'Saved','Region',55,'{\"width\":\"847 > 849.67\",\"height\":\"282 > 238.69\",\"top\":\"558 > 557.99\",\"left\":\"63 > 62.97\",\"campaignId\":[\"13\"]}'),(552,1585156616,1,'Added','Widget',50,'{\"widgetId\":50,\"type\":\"countdown\",\"layoutId\":\"20\",\"campaignId\":\"13\"}'),(553,1585156616,1,'Saved','Widget',50,'{\"widgetId\":50,\"playlistId\":\"55\",\"ownerId\":1,\"type\":\"countdown\",\"duration\":60,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":60,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":50,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":50,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":50,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(554,1585156618,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(555,1585156734,1,'Saved','Widget',50,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(556,1585156745,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"countdown1 > countdown2\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(557,1585156752,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"countdown2 > countdown3\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(558,1585156762,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"templateId\\\": \\\"countdown3 > countdown4\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(559,1585156788,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"overrideTemplate\\\": \\\"0 > 1\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(560,1585156801,0,'Saved','Playlist',53,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(561,1585156801,0,'Saved','Playlist',54,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(562,1585156801,0,'Saved','Playlist',55,'{\"duration\":\"0 > 60\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(563,1585156801,0,'Saved','Playlist',56,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(564,1585157006,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#clockdiv {\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #333;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #1b1e56;\\\\r\\\\n    border: 2px solid #1b1e56;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: darkgoldenrod;\\\\r\\\\n    color: darkgoldenrod;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n} > #clockdiv {\\\\r\\\\n    background-color: #FF0000\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #333;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #1b1e56;\\\\r\\\\n    border: 2px solid #1b1e56;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: darkgoldenrod;\\\\r\\\\n    color: darkgoldenrod;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(565,1585157017,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#clockdiv {\\\\r\\\\n    background-color: #FF0000\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #333;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #1b1e56;\\\\r\\\\n    border: 2px solid #1b1e56;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: darkgoldenrod;\\\\r\\\\n    color: darkgoldenrod;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n} > #clockdiv {\\\\r\\\\n    background-color: #FF0000;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #333;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #1b1e56;\\\\r\\\\n    border: 2px solid #1b1e56;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: darkgoldenrod;\\\\r\\\\n    color: darkgoldenrod;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(566,1585157076,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(567,1585157076,1,'Saved','Region',55,'{\"width\":\"850 > 717.49\",\"height\":\"239 > 238.98\",\"top\":\"558 > 557.99\",\"left\":\"63 > 62.97\",\"campaignId\":[\"13\"]}'),(568,1585157172,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#clockdiv {\\\\r\\\\n    background-color: #FF0000;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #333;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #1b1e56;\\\\r\\\\n    border: 2px solid #1b1e56;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: darkgoldenrod;\\\\r\\\\n    color: darkgoldenrod;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n} > #clockdiv {\\\\r\\\\n    background-color: #1da4c2;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    border: 2px solid #FFF;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: darkgoldenrod;\\\\r\\\\n    color: darkgoldenrod;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(569,1585157191,1,'Saved','Widget',50,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(570,1585157303,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#clockdiv {\\\\r\\\\n    background-color: #1da4c2;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    border: 2px solid #FFF;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: darkgoldenrod;\\\\r\\\\n    color: darkgoldenrod;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n} > #clockdiv {\\\\r\\\\n    background-color: #1da4c2;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    border: 2px solid #FFF;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: EBDF2A;\\\\r\\\\n    color: EBDF2A;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(571,1585157323,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#clockdiv {\\\\r\\\\n    background-color: #1da4c2;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    border: 2px solid #FFF;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: EBDF2A;\\\\r\\\\n    color: EBDF2A;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n} > #clockdiv {\\\\r\\\\n    background-color: #1da4c2;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    border: 2px solid #FFF;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: #EBDF2A;\\\\r\\\\n    color: #EBDF2A;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(572,1585157337,1,'Saved','Widget',50,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(573,1585157379,1,'Added','Widget',51,'{\"widgetId\":51,\"type\":\"image\",\"layoutId\":\"20\",\"campaignId\":\"13\"}'),(574,1585157379,1,'Saved','Widget',51,'{\"widgetId\":51,\"playlistId\":52,\"ownerId\":1,\"type\":\"image\",\"duration\":10,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":51,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":51,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[62],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(575,1585157382,1,'Saved','Playlist',52,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(576,1585157392,1,'Saved','Widget',51,'{\"widgetOptions\":\"[\\n    {\\n        \\\"scaleType\\\": \\\"center > stretch\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(577,1585157400,1,'Saved','Widget',51,'{\"widgetOptions\":\"[\\n    {\\n        \\\"scaleType\\\": \\\"stretch > center\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(578,1585157403,0,'Saved','Playlist',52,'{\"duration\":\"0 > 10\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(579,1585157453,1,'Deleted','Widget',51,'{\"widgetId\":51,\"playlistId\":52}'),(580,1585157453,1,'Deleted','Media',62,'[]'),(581,1585157456,1,'Saved','Playlist',52,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(582,1585157545,1,'Added','Widget',52,'{\"widgetId\":52,\"type\":\"image\",\"layoutId\":\"20\",\"campaignId\":\"13\"}'),(583,1585157545,1,'Saved','Widget',52,'{\"widgetId\":52,\"playlistId\":52,\"ownerId\":1,\"type\":\"image\",\"duration\":10,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":52,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":52,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[63],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(584,1585157548,1,'Saved','Playlist',52,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(585,1585157575,1,'Added','Widget',53,'{\"widgetId\":53,\"type\":\"text\",\"layoutId\":\"20\",\"campaignId\":\"13\"}'),(586,1585157575,1,'Saved','Widget',53,'{\"widgetId\":53,\"playlistId\":\"53\",\"ownerId\":1,\"type\":\"text\",\"duration\":5,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":5,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":53,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":53,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":53,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(587,1585157578,1,'Saved','Playlist',53,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(588,1585157660,1,'Saved','Widget',53,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(589,1585157666,1,'Saved','Widget',53,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(590,1585157684,1,'Added','Widget',54,'{\"widgetId\":54,\"type\":\"text\",\"layoutId\":\"20\",\"campaignId\":\"13\"}'),(591,1585157684,1,'Saved','Widget',54,'{\"widgetId\":54,\"playlistId\":\"54\",\"ownerId\":1,\"type\":\"text\",\"duration\":5,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":5,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":54,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":54,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":54,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(592,1585157685,1,'Saved','Playlist',54,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(593,1585157701,0,'Saved','Playlist',52,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(594,1585157701,0,'Saved','Playlist',53,'{\"duration\":\"0 > 5\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(595,1585157701,0,'Saved','Playlist',54,'{\"duration\":\"0 > 5\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(596,1585157742,1,'Saved','Widget',54,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(597,1585157771,1,'Saved','Playlist',53,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(598,1585157771,1,'Saved','Region',53,'{\"width\":\"845 > 844.99\",\"height\":\"250 > 219.24\",\"top\":\"80 > 100.46\",\"left\":\"61 > 60.99\",\"campaignId\":[\"13\"]}'),(599,1585157787,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(600,1585157787,1,'Saved','Region',55,'{\"height\":\"239 > 238.97\",\"top\":\"558 > 555.43\",\"left\":\"63 > 119.35\",\"campaignId\":[\"13\"]}'),(601,1585157802,1,'Saved','Playlist',54,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(602,1585157802,1,'Saved','Region',54,'{\"width\":\"845 > 844.99\",\"height\":\"182 > 181.98\",\"top\":\"347 > 797.8\",\"left\":\"61 > 63.56\",\"campaignId\":[\"13\"]}'),(603,1585157814,1,'Saved','Playlist',56,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(604,1585157814,1,'Saved','Region',56,'{\"width\":\"855 > 854.99\",\"height\":\"163 > 162.97\",\"top\":\"812 > 356.04\",\"left\":\"58 > 57.99\",\"campaignId\":[\"13\"]}'),(605,1585157823,1,'Saved','Playlist',54,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(606,1585157823,1,'Saved','Region',54,'{\"width\":\"845 > 824.5\",\"height\":\"182 > 184.5\",\"top\":\"798 > 800.32\",\"left\":\"64 > 68.68\",\"campaignId\":[\"13\"]}'),(607,1585157827,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(608,1585157827,1,'Saved','Region',55,'{\"height\":\"239 > 238.93\",\"top\":\"555 > 547.74\",\"left\":\"119 > 119.35\",\"campaignId\":[\"13\"]}'),(609,1585157855,1,'Added','Widget',55,'{\"widgetId\":55,\"type\":\"text\",\"layoutId\":\"20\",\"campaignId\":\"13\"}'),(610,1585157855,1,'Saved','Widget',55,'{\"widgetId\":55,\"playlistId\":\"56\",\"ownerId\":1,\"type\":\"text\",\"duration\":5,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":5,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":55,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":55,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":55,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(611,1585157858,1,'Saved','Playlist',56,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(612,1585157899,1,'Saved','Widget',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(613,1585157945,1,'Saved','Widget',53,'{\"widgetOptions\":\"[\\n    {\\n        \\\"ta_text_advanced\\\": \\\"0 > 1\\\"\\n    },\\n    {\\n        \\\"text\\\": \\\"<p style=\\\\\\\"text-align: center;\\\\\\\"><span style=\\\\\\\"color:#ffffff;\\\\\\\"><span style=\\\\\\\"font-size:155px;\\\\\\\"><span style=\\\\\\\"font-family:trebuchet ms,helvetica,sans-serif;\\\\\\\"><strong>GALA 2020<\\\\\\/strong><\\\\\\/span><\\\\\\/span><\\\\\\/span><\\\\\\/p>\\\\r\\\\n > <p style=\\\\\\\"text-align: center;\\\\\\\"><span style=\\\\\\\"color:#ffffff;\\\\\\\"><span style=\\\\\\\"font-size:155px;\\\\\\\"><span style=\\\\\\\"font-family:trebuchet ms,helvetica,sans-serif;\\\\\\\"><strong>GALA 2020<\\\\\\/strong><\\\\\\/span><\\\\\\/span><\\\\\\/span><\\\\\\/p>\\\\r\\\\n\\\\r\\\\n<hr \\\\\\/>\\\\r\\\\n<p>&nbsp;<\\\\\\/p>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(614,1585157969,1,'Saved','Playlist',56,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(615,1585157969,1,'Saved','Region',56,'{\"width\":\"855 > 854.99\",\"height\":\"163 > 162.97\",\"top\":\"356 > 330.38\",\"left\":\"58 > 55.43\",\"campaignId\":[\"13\"]}'),(616,1585157990,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(617,1585157990,1,'Saved','Region',55,'{\"width\":\"717 > 791.28\",\"height\":\"239 > 274.83\",\"top\":\"548 > 509.56\",\"left\":\"119 > 85.69\",\"campaignId\":[\"13\"]}'),(618,1585158001,0,'Saved','Playlist',56,'{\"duration\":\"0 > 5\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(619,1585158022,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"551 > 650\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(620,1585158034,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"650 > 610\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(621,1585158045,1,'Saved','Widget',50,'{\"widgetOptions\":\"[\\n    {\\n        \\\"widgetOriginalWidth\\\": \\\"610 > 600\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(622,1585158052,1,'Saved','Widget',50,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(623,1585158088,1,'Saved','Playlist',55,'{\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(624,1585158088,1,'Saved','Region',55,'{\"height\":\"275 > 264.71\",\"top\":\"510 > 509.96\",\"left\":\"86 > 85.97\",\"campaignId\":[\"13\"]}'),(625,1585158120,1,'Saved','Widget',54,'{\"widgetOptions\":\"[\\n    {\\n        \\\"text\\\": \\\"<p style=\\\\\\\"text-align: center;\\\\\\\"><span style=\\\\\\\"color:#FFFFFF;\\\\\\\"><span style=\\\\\\\"font-size:96px;\\\\\\\"><span style=\\\\\\\"font-family:trebuchet ms,helvetica,sans-serif;\\\\\\\">SAVE THE DATE<\\\\\\/span><\\\\\\/span><\\\\\\/span><\\\\\\/p>\\\\r\\\\n > <p style=\\\\\\\"text-align: center;\\\\\\\"><span style=\\\\\\\"color:#FFFFFF;\\\\\\\"><span style=\\\\\\\"font-size:96px;\\\\\\\"><span style=\\\\\\\"font-family:trebuchet ms,helvetica,sans-serif;\\\\\\\">SAVE THE DATE !<\\\\\\/span><\\\\\\/span><\\\\\\/span><\\\\\\/p>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"20\"]}'),(626,1585158142,1,'Deleted','Playlist',51,'{\"playlistId\":51,\"regionId\":51}'),(627,1585158142,1,'Region Deleted','Region',51,'{\"regionId\":51,\"layoutId\":19}'),(628,1585158142,1,'Layout Deleted','Layout',19,'{\"layoutId\":19}'),(629,1585158142,1,'Deleted draft for 20','Layout',19,'{\"parentId\":\" > 20\"}'),(630,1585158142,1,'Updated Draft','Layout',20,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[13]}'),(631,1585158163,1,'Checked out','Layout',21,'{\"layoutId\":20,\"layout\":\"Compte \\u00e0 rebours 60 ans\",\"campaignId\":13}'),(632,1585158163,1,'Added','Widget',56,'{\"widgetId\":56,\"type\":\"image\",\"layoutId\":\"21\",\"campaignId\":\"13\"}'),(633,1585158163,1,'Saved','Widget',56,'{\"widgetId\":\"52 > 56\",\"playlistId\":\"52 > 57\"}'),(634,1585158163,1,'Saved','Playlist',57,'{\"playlistId\":\"52 > 57\",\"regionId\":\"52 > 57\",\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(635,1585158163,1,'Added','Region',57,'{\"regionId\":57,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-1 - 928 x 894 (78, 946). RegionId = 57, LayoutId = 21. OwnerId = 1. Duration = 10\"}'),(636,1585158163,1,'Added','Widget',57,'{\"widgetId\":57,\"type\":\"text\",\"layoutId\":\"21\",\"campaignId\":\"13\"}'),(637,1585158163,1,'Saved','Widget',57,'{\"widgetId\":\"53 > 57\",\"playlistId\":\"53 > 58\"}'),(638,1585158163,1,'Saved','Playlist',58,'{\"playlistId\":\"53 > 58\",\"regionId\":\"53 > 58\",\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(639,1585158163,1,'Added','Region',58,'{\"regionId\":58,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-2 - 845 x 219 (100, 61). RegionId = 58, LayoutId = 21. OwnerId = 1. Duration = 5\"}'),(640,1585158163,1,'Added','Widget',58,'{\"widgetId\":58,\"type\":\"text\",\"layoutId\":\"21\",\"campaignId\":\"13\"}'),(641,1585158163,1,'Saved','Widget',58,'{\"widgetId\":\"54 > 58\",\"playlistId\":\"54 > 59\"}'),(642,1585158163,1,'Saved','Playlist',59,'{\"playlistId\":\"54 > 59\",\"regionId\":\"54 > 59\",\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(643,1585158163,1,'Added','Region',59,'{\"regionId\":59,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-3 - 825 x 185 (800, 69). RegionId = 59, LayoutId = 21. OwnerId = 1. Duration = 5\"}'),(644,1585158163,1,'Added','Widget',59,'{\"widgetId\":59,\"type\":\"countdown\",\"layoutId\":\"21\",\"campaignId\":\"13\"}'),(645,1585158163,1,'Saved','Widget',59,'{\"widgetId\":\"50 > 59\",\"playlistId\":\"55 > 60\"}'),(646,1585158163,1,'Saved','Playlist',60,'{\"playlistId\":\"55 > 60\",\"regionId\":\"55 > 60\",\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(647,1585158163,1,'Added','Region',60,'{\"regionId\":60,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-4 - 791 x 265 (510, 86). RegionId = 60, LayoutId = 21. OwnerId = 1. Duration = 60\"}'),(648,1585158163,1,'Added','Widget',60,'{\"widgetId\":60,\"type\":\"text\",\"layoutId\":\"21\",\"campaignId\":\"13\"}'),(649,1585158163,1,'Saved','Widget',60,'{\"widgetId\":\"55 > 60\",\"playlistId\":\"56 > 61\"}'),(650,1585158163,1,'Saved','Playlist',61,'{\"playlistId\":\"56 > 61\",\"regionId\":\"56 > 61\",\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(651,1585158163,1,'Added','Region',61,'{\"regionId\":61,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-5 - 855 x 163 (330, 55). RegionId = 61, LayoutId = 21. OwnerId = 1. Duration = 5\"}'),(652,1585158163,1,'Updated','Layout',20,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[13]}'),(653,1585158167,1,'Saved','Playlist',57,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(654,1585158167,1,'Saved','Playlist',58,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(655,1585158167,1,'Saved','Playlist',59,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(656,1585158167,1,'Saved','Playlist',60,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(657,1585158167,1,'Saved','Playlist',61,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(658,1585158177,1,'Updated Draft','Layout',21,'{\"backgroundColor\":\"#1da4c2 > #2b8fa6\",\"status\":\"1 > 3\",\"campaignId\":[13]}'),(659,1585158206,1,'Saved','Widget',59,'{\"widgetOptions\":\"[\\n    {\\n        \\\"styleSheet\\\": \\\"#clockdiv {\\\\r\\\\n    background-color: #1da4c2;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    border: 2px solid #FFF;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: #EBDF2A;\\\\r\\\\n    color: #EBDF2A;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n} > #clockdiv {\\\\r\\\\n    background-color: #2b8fa6;\\\\r\\\\n    font-family: sans-serif;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    text-align: center;\\\\r\\\\n    font-size: 0;\\\\r\\\\n}\\\\r\\\\n#clockdiv > div {\\\\r\\\\n    padding: 12px 8px;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    width: 150px;\\\\r\\\\n    font-size: 70px;\\\\r\\\\n}\\\\r\\\\n#clockdiv div > span {\\\\r\\\\n    text-align: center;\\\\r\\\\n    padding: 10px 0px;\\\\r\\\\n    width: 100%;\\\\r\\\\n    border-radius: 20px;\\\\r\\\\n    font-weight: bold;\\\\r\\\\n    display: inline-block;\\\\r\\\\n    color: #FFF;\\\\r\\\\n    border: 2px solid #FFF;\\\\r\\\\n}\\\\r\\\\n.smalltext {\\\\r\\\\n    padding-top: 10px;\\\\r\\\\n    font-size: 30px;\\\\r\\\\n}\\\\r\\\\n.warning > #clockdiv > div > span {\\\\r\\\\n    border-color: #EBDF2A;\\\\r\\\\n    color: #EBDF2A;\\\\r\\\\n}\\\\r\\\\n.finished > #clockdiv > div > span {\\\\r\\\\n    border-color: darkred;\\\\r\\\\n    color: darkred;\\\\r\\\\n}\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(660,1585158241,1,'Saved','Playlist',59,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(661,1585158241,1,'Saved','Region',59,'{\"width\":\"825 > 824.98\",\"height\":\"185 > 149.12\",\"top\":\"800 > 840.95\",\"left\":\"69 > 58.75\",\"campaignId\":[\"13\"]}'),(662,1585158304,1,'Saved','Playlist',60,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(663,1585158304,1,'Saved','Region',60,'{\"width\":\"791 > 902\",\"height\":\"265 > 300\",\"campaignId\":[\"13\"]}'),(664,1585158319,1,'Saved','Playlist',60,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(665,1585158319,1,'Saved','Region',60,'{\"width\":\"902 > 901.98\",\"height\":\"300 > 299.97\",\"top\":\"510 > 515.09\",\"left\":\"86 > 27.06\",\"campaignId\":[\"13\"]}'),(666,1585158329,1,'Saved','Playlist',57,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(667,1585158329,1,'Saved','Region',57,'{\"height\":\"894 > 893.98\",\"top\":\"78 > 93.33\",\"left\":\"946 > 958.77\",\"campaignId\":[\"13\"]}'),(668,1585158356,1,'Saved','Playlist',60,'{\"campaignId\":[\"13\"],\"layoutId\":[\"21\"]}'),(669,1585158356,1,'Saved','Region',60,'{\"width\":\"902 > 900\",\"campaignId\":[\"13\"]}'),(670,1585158386,1,'Deleted','Widget',52,'{\"widgetId\":52,\"playlistId\":52}'),(671,1585158386,1,'Deleted','Playlist',52,'{\"playlistId\":52,\"regionId\":52}'),(672,1585158386,1,'Region Deleted','Region',52,'{\"regionId\":52,\"layoutId\":20}'),(673,1585158386,1,'Deleted','Widget',53,'{\"widgetId\":53,\"playlistId\":53}'),(674,1585158386,1,'Deleted','Playlist',53,'{\"playlistId\":53,\"regionId\":53}'),(675,1585158386,1,'Region Deleted','Region',53,'{\"regionId\":53,\"layoutId\":20}'),(676,1585158386,1,'Deleted','Widget',54,'{\"widgetId\":54,\"playlistId\":54}'),(677,1585158386,1,'Deleted','Playlist',54,'{\"playlistId\":54,\"regionId\":54}'),(678,1585158386,1,'Region Deleted','Region',54,'{\"regionId\":54,\"layoutId\":20}'),(679,1585158386,1,'Deleted','Widget',50,'{\"widgetId\":50,\"playlistId\":55}'),(680,1585158386,1,'Deleted','Playlist',55,'{\"playlistId\":55,\"regionId\":55}'),(681,1585158386,1,'Region Deleted','Region',55,'{\"regionId\":55,\"layoutId\":20}'),(682,1585158386,1,'Deleted','Widget',55,'{\"widgetId\":55,\"playlistId\":56}'),(683,1585158386,1,'Deleted','Playlist',56,'{\"playlistId\":56,\"regionId\":56}'),(684,1585158386,1,'Region Deleted','Region',56,'{\"regionId\":56,\"layoutId\":20}'),(685,1585158386,1,'Layout Deleted','Layout',20,'{\"layoutId\":20}'),(686,1585158386,1,'Deleted draft for 21','Layout',20,'{\"parentId\":\" > 21\"}'),(687,1585158386,1,'Updated Draft','Layout',21,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[13]}'),(688,1585158693,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(689,1585158735,1,'Deleted','Widget',19,'{\"widgetId\":19,\"playlistId\":20}'),(690,1585158735,1,'Deleted','Playlist',20,'{\"playlistId\":20,\"regionId\":20}'),(691,1585158735,1,'Region Deleted','Region',20,'{\"regionId\":20,\"layoutId\":9}'),(692,1585158735,1,'Deleted','Widget',20,'{\"widgetId\":20,\"playlistId\":21}'),(693,1585158735,1,'Deleted','Playlist',21,'{\"playlistId\":21,\"regionId\":21}'),(694,1585158735,1,'Region Deleted','Region',21,'{\"regionId\":21,\"layoutId\":9}'),(695,1585158735,1,'Deleted','Widget',21,'{\"widgetId\":21,\"playlistId\":22}'),(696,1585158735,1,'Deleted','Playlist',22,'{\"playlistId\":22,\"regionId\":22}'),(697,1585158735,1,'Region Deleted','Region',22,'{\"regionId\":22,\"layoutId\":9}'),(698,1585158735,1,'Deleted','Widget',22,'{\"widgetId\":22,\"playlistId\":23}'),(699,1585158735,1,'Deleted','Playlist',23,'{\"playlistId\":23,\"regionId\":23}'),(700,1585158735,1,'Region Deleted','Region',23,'{\"regionId\":23,\"layoutId\":9}'),(701,1585158735,1,'Layout Deleted','Layout',9,'{\"layoutId\":9}'),(702,1585158735,1,'Deleted','Layout',9,'[]'),(703,1585158740,1,'Checked out','Layout',22,'{\"layoutId\":21,\"layout\":\"Compte \\u00e0 rebours 60 ans\",\"campaignId\":13}'),(704,1585158740,1,'Added','Widget',61,'{\"widgetId\":61,\"type\":\"image\",\"layoutId\":\"22\",\"campaignId\":\"13\"}'),(705,1585158740,1,'Saved','Widget',61,'{\"widgetId\":\"56 > 61\",\"playlistId\":\"57 > 62\"}'),(706,1585158740,1,'Saved','Playlist',62,'{\"playlistId\":\"57 > 62\",\"regionId\":\"57 > 62\",\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(707,1585158740,1,'Added','Region',62,'{\"regionId\":62,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-1 - 928 x 894 (93, 959). RegionId = 62, LayoutId = 22. OwnerId = 1. Duration = 10\"}'),(708,1585158740,1,'Added','Widget',62,'{\"widgetId\":62,\"type\":\"text\",\"layoutId\":\"22\",\"campaignId\":\"13\"}'),(709,1585158740,1,'Saved','Widget',62,'{\"widgetId\":\"57 > 62\",\"playlistId\":\"58 > 63\"}'),(710,1585158740,1,'Saved','Playlist',63,'{\"playlistId\":\"58 > 63\",\"regionId\":\"58 > 63\",\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(711,1585158740,1,'Added','Region',63,'{\"regionId\":63,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-2 - 845 x 219 (100, 61). RegionId = 63, LayoutId = 22. OwnerId = 1. Duration = 5\"}'),(712,1585158740,1,'Added','Widget',63,'{\"widgetId\":63,\"type\":\"text\",\"layoutId\":\"22\",\"campaignId\":\"13\"}'),(713,1585158740,1,'Saved','Widget',63,'{\"widgetId\":\"58 > 63\",\"playlistId\":\"59 > 64\"}'),(714,1585158740,1,'Saved','Playlist',64,'{\"playlistId\":\"59 > 64\",\"regionId\":\"59 > 64\",\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(715,1585158740,1,'Added','Region',64,'{\"regionId\":64,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-3 - 825 x 149 (841, 59). RegionId = 64, LayoutId = 22. OwnerId = 1. Duration = 5\"}'),(716,1585158740,1,'Added','Widget',64,'{\"widgetId\":64,\"type\":\"countdown\",\"layoutId\":\"22\",\"campaignId\":\"13\"}'),(717,1585158740,1,'Saved','Widget',64,'{\"widgetId\":\"59 > 64\",\"playlistId\":\"60 > 65\"}'),(718,1585158740,1,'Saved','Playlist',65,'{\"playlistId\":\"60 > 65\",\"regionId\":\"60 > 65\",\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(719,1585158740,1,'Added','Region',65,'{\"regionId\":65,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-4 - 900 x 300 (515, 27). RegionId = 65, LayoutId = 22. OwnerId = 1. Duration = 60\"}'),(720,1585158740,1,'Added','Widget',65,'{\"widgetId\":65,\"type\":\"text\",\"layoutId\":\"22\",\"campaignId\":\"13\"}'),(721,1585158740,1,'Saved','Widget',65,'{\"widgetId\":\"60 > 65\",\"playlistId\":\"61 > 66\"}'),(722,1585158740,1,'Saved','Playlist',66,'{\"playlistId\":\"61 > 66\",\"regionId\":\"61 > 66\",\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(723,1585158740,1,'Added','Region',66,'{\"regionId\":66,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-5 - 855 x 163 (330, 55). RegionId = 66, LayoutId = 22. OwnerId = 1. Duration = 5\"}'),(724,1585158740,1,'Updated','Layout',21,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[13]}'),(725,1585158750,1,'Saved','Playlist',62,'{\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(726,1585158750,1,'Saved','Playlist',63,'{\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(727,1585158750,1,'Saved','Playlist',64,'{\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(728,1585158750,1,'Saved','Playlist',65,'{\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(729,1585158750,1,'Saved','Playlist',66,'{\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(730,1585158762,1,'Saved','Widget',65,'{\"widgetOptions\":\"[\\n    {\\n        \\\"text\\\": \\\"<p style=\\\\\\\"text-align: center;\\\\\\\"><span style=\\\\\\\"color:#FFFFE0;\\\\\\\"><strong><span style=\\\\\\\"font-size:88px;\\\\\\\"><span style=\\\\\\\"font-family:trebuchet ms,helvetica,sans-serif;\\\\\\\">SAMEDI 10 OCTOBRE<\\\\\\/span><\\\\\\/span><\\\\\\/strong><\\\\\\/span><\\\\\\/p>\\\\r\\\\n > <p style=\\\\\\\"text-align: center;\\\\\\\"><span style=\\\\\\\"color:#FFFFFF;\\\\\\\"><strong><span style=\\\\\\\"font-size:88px;\\\\\\\"><span style=\\\\\\\"font-family:trebuchet ms,helvetica,sans-serif;\\\\\\\">SAMEDI 10 OCTOBRE<\\\\\\/span><\\\\\\/span><\\\\\\/strong><\\\\\\/span><\\\\\\/p>\\\\r\\\\n\\\"\\n    }\\n]\",\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(731,1585158822,1,'Saved','Widget',64,'{\"campaignId\":[\"13\"],\"layoutId\":[\"22\"]}'),(732,1585158829,1,'Deleted','Widget',56,'{\"widgetId\":56,\"playlistId\":57}'),(733,1585158829,1,'Deleted','Playlist',57,'{\"playlistId\":57,\"regionId\":57}'),(734,1585158829,1,'Region Deleted','Region',57,'{\"regionId\":57,\"layoutId\":21}'),(735,1585158829,1,'Deleted','Widget',57,'{\"widgetId\":57,\"playlistId\":58}'),(736,1585158829,1,'Deleted','Playlist',58,'{\"playlistId\":58,\"regionId\":58}'),(737,1585158829,1,'Region Deleted','Region',58,'{\"regionId\":58,\"layoutId\":21}'),(738,1585158829,1,'Deleted','Widget',58,'{\"widgetId\":58,\"playlistId\":59}'),(739,1585158829,1,'Deleted','Playlist',59,'{\"playlistId\":59,\"regionId\":59}'),(740,1585158829,1,'Region Deleted','Region',59,'{\"regionId\":59,\"layoutId\":21}'),(741,1585158829,1,'Deleted','Widget',59,'{\"widgetId\":59,\"playlistId\":60}'),(742,1585158829,1,'Deleted','Playlist',60,'{\"playlistId\":60,\"regionId\":60}'),(743,1585158829,1,'Region Deleted','Region',60,'{\"regionId\":60,\"layoutId\":21}'),(744,1585158829,1,'Deleted','Widget',60,'{\"widgetId\":60,\"playlistId\":61}'),(745,1585158829,1,'Deleted','Playlist',61,'{\"playlistId\":61,\"regionId\":61}'),(746,1585158829,1,'Region Deleted','Region',61,'{\"regionId\":61,\"layoutId\":21}'),(747,1585158829,1,'Layout Deleted','Layout',21,'{\"layoutId\":21}'),(748,1585158829,1,'Deleted draft for 22','Layout',21,'{\"parentId\":\" > 22\"}'),(749,1585158829,1,'Updated Draft','Layout',22,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[13]}'),(750,1585232700,0,'Deleted','Media',59,'[]'),(751,1585232700,0,'Deleted','Media',54,'[]'),(752,1585232700,0,'Deleted','Media',57,'[]'),(753,1585232700,0,'Deleted','Media',55,'[]'),(754,1585232700,0,'Deleted','Media',56,'[]'),(755,1585232700,0,'Deleted','Media',58,'[]'),(756,1585233000,0,'Deleted','Media',60,'[]'),(757,1585233000,0,'Deleted','Media',61,'[]'),(758,1585495516,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(759,1585503195,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(760,1585503306,1,'Added','Layout',23,'{\"layoutId\":23,\"layout\":\"CoViD-19\",\"campaignId\":14}'),(761,1585503306,1,'Saved','Playlist',67,'{\"campaignId\":[\"14\"],\"layoutId\":[\"23\"]}'),(762,1585503306,1,'Added','Region',67,'{\"regionId\":67,\"campaignId\":\"14\",\"details\":\"Region CoViD-19-1 - 1920 x 1080 (0, 0). RegionId = 67, LayoutId = 23. OwnerId = 1. Duration = 0\"}'),(763,1585503306,1,'Checked out','Layout',24,'{\"layoutId\":23,\"layout\":\"CoViD-19\",\"campaignId\":14}'),(764,1585503306,1,'Saved','Playlist',68,'{\"playlistId\":\"67 > 68\",\"regionId\":\"67 > 68\",\"campaignId\":[\"14\"],\"layoutId\":[\"24\"]}'),(765,1585503306,1,'Added','Region',68,'{\"regionId\":68,\"campaignId\":\"14\",\"details\":\"Region CoViD-19-1 - 1920 x 1080 (0, 0). RegionId = 68, LayoutId = 24. OwnerId = 1. Duration = 0\"}'),(766,1585503306,1,'Updated','Layout',23,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[14]}'),(767,1585503326,1,'Added','Widget',66,'{\"widgetId\":66,\"type\":\"webpage\",\"layoutId\":\"24\",\"campaignId\":\"14\"}'),(768,1585503326,1,'Saved','Widget',66,'{\"widgetId\":66,\"playlistId\":\"68\",\"ownerId\":1,\"type\":\"webpage\",\"duration\":60,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":60,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":66,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":66,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":66,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(769,1585503327,1,'Saved','Playlist',68,'{\"campaignId\":[\"14\"],\"layoutId\":[\"24\"]}'),(770,1585503335,1,'Saved','Widget',66,'{\"campaignId\":[\"14\"],\"layoutId\":[\"24\"]}'),(771,1585503347,1,'Saved','Widget',66,'{\"duration\":\"60 > 30\",\"useDuration\":\"0 > 1\",\"calculatedDuration\":\"60 > 30\",\"campaignId\":[\"14\"],\"layoutId\":[\"24\"]}'),(772,1585503348,1,'Saved','Playlist',68,'{\"campaignId\":[\"14\"],\"layoutId\":[\"24\"]}'),(773,1585503353,1,'Deleted','Playlist',67,'{\"playlistId\":67,\"regionId\":67}'),(774,1585503353,1,'Region Deleted','Region',67,'{\"regionId\":67,\"layoutId\":23}'),(775,1585503353,1,'Layout Deleted','Layout',23,'{\"layoutId\":23}'),(776,1585503353,1,'Deleted draft for 24','Layout',23,'{\"parentId\":\" > 24\"}'),(777,1585503353,1,'Updated Draft','Layout',24,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"2 > 3\",\"campaignId\":[14]}'),(778,1585503600,0,'Saved','Playlist',68,'{\"duration\":\"0 > 30\",\"campaignId\":[\"14\"],\"layoutId\":[\"24\"]}'),(779,1585503763,1,'Added','Schedule',2,'{\"eventId\":2,\"eventTypeId\":1,\"campaignId\":14,\"commandId\":null,\"displayGroups\":[{\"displayGroupId\":3,\"displayGroup\":\"Tous\",\"description\":null,\"isDisplaySpecific\":0,\"isDynamic\":0,\"dynamicCriteria\":null,\"dynamicCriteriaTags\":null,\"userId\":1,\"tags\":null,\"tagValues\":null,\"bandwidthLimit\":\"0\"}],\"scheduleReminders\":[],\"userId\":1,\"fromDt\":\"1585440000\",\"toDt\":\"1586646000\",\"isPriority\":5,\"displayOrder\":0,\"recurrenceType\":null,\"recurrenceDetail\":null,\"recurrenceRange\":null,\"recurrenceRepeatsOn\":null,\"recurrenceMonthlyRepeatsOn\":null,\"campaign\":null,\"command\":null,\"dayPartId\":1,\"isAlways\":null,\"isCustom\":null,\"syncEvent\":0,\"syncTimezone\":0,\"shareOfVoice\":null,\"isGeoAware\":0,\"geoLocation\":null}'),(780,1585510216,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(781,1585557606,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(782,1585561502,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(783,1585642705,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(784,1585644518,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(785,1585644541,1,'Checked out','Layout',25,'{\"layoutId\":24,\"layout\":\"CoViD-19\",\"campaignId\":14}'),(786,1585644541,1,'Added','Widget',67,'{\"widgetId\":67,\"type\":\"webpage\",\"layoutId\":\"25\",\"campaignId\":\"14\"}'),(787,1585644541,1,'Saved','Widget',67,'{\"widgetId\":\"66 > 67\",\"playlistId\":\"68 > 70\"}'),(788,1585644541,1,'Saved','Playlist',70,'{\"playlistId\":\"68 > 70\",\"regionId\":\"68 > 69\",\"campaignId\":[\"14\"],\"layoutId\":[\"25\"]}'),(789,1585644541,1,'Added','Region',69,'{\"regionId\":69,\"campaignId\":\"14\",\"details\":\"Region CoViD-19-1 - 1920 x 1080 (0, 0). RegionId = 69, LayoutId = 25. OwnerId = 1. Duration = 30\"}'),(790,1585644541,1,'Updated','Layout',24,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[14]}'),(791,1585644542,1,'Saved','Playlist',70,'{\"campaignId\":[\"14\"],\"layoutId\":[\"25\"]}'),(792,1585644555,1,'Saved','Widget',67,'{\"widgetOptions\":\"[\\n    {\\n        \\\"modeid\\\": \\\"1 > 3\\\"\\n    }\\n]\",\"campaignId\":[\"14\"],\"layoutId\":[\"25\"]}'),(793,1585644590,1,'Saved','Widget',67,'{\"widgetOptions\":\"[\\n    {\\n        \\\"uri\\\": \\\"https%3A%2F%2Fcontent.seenspire.com%2F5Cwu-M7Up-c9qN > http%3A%2F%2Fcontent.seenspire.com%2F5Cwu-M7Up-c9qN\\\"\\n    }\\n]\",\"campaignId\":[\"14\"],\"layoutId\":[\"25\"]}'),(794,1585644896,1,'Deleted','Schedule',2,'{\"eventId\":2,\"eventTypeId\":1,\"campaignId\":14,\"commandId\":0,\"displayGroups\":[],\"scheduleReminders\":[],\"userId\":1,\"fromDt\":\"1585440000\",\"toDt\":\"1586646000\",\"isPriority\":5,\"displayOrder\":\"0\",\"recurrenceType\":null,\"recurrenceDetail\":null,\"recurrenceRange\":null,\"recurrenceRepeatsOn\":null,\"recurrenceMonthlyRepeatsOn\":0,\"campaign\":\"CoViD-19\",\"command\":null,\"dayPartId\":1,\"isAlways\":0,\"isCustom\":1,\"syncEvent\":0,\"syncTimezone\":0,\"shareOfVoice\":0,\"isGeoAware\":0,\"geoLocation\":null}'),(795,1585664614,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(796,1585668347,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(797,1585675787,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(798,1585676025,1,'Added','Layout',26,'{\"layoutId\":26,\"layout\":\"Test_PDF\",\"campaignId\":15}'),(799,1585676025,1,'Saved','Playlist',71,'{\"campaignId\":[\"15\"],\"layoutId\":[\"26\"]}'),(800,1585676025,1,'Added','Region',70,'{\"regionId\":70,\"campaignId\":\"15\",\"details\":\"Region Test_PDF-1 - 1920 x 1080 (0, 0). RegionId = 70, LayoutId = 26. OwnerId = 1. Duration = 0\"}'),(801,1585676026,1,'Checked out','Layout',27,'{\"layoutId\":26,\"layout\":\"Test_PDF\",\"campaignId\":15}'),(802,1585676026,1,'Saved','Playlist',72,'{\"playlistId\":\"71 > 72\",\"regionId\":\"70 > 71\",\"campaignId\":[\"15\"],\"layoutId\":[\"27\"]}'),(803,1585676026,1,'Added','Region',71,'{\"regionId\":71,\"campaignId\":\"15\",\"details\":\"Region Test_PDF-1 - 1920 x 1080 (0, 0). RegionId = 71, LayoutId = 27. OwnerId = 1. Duration = 0\"}'),(804,1585676026,1,'Updated','Layout',26,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[15]}'),(805,1585676069,1,'Added','Widget',68,'{\"widgetId\":68,\"type\":\"pdf\",\"layoutId\":\"27\",\"campaignId\":\"15\"}'),(806,1585676069,1,'Saved','Widget',68,'{\"widgetId\":68,\"playlistId\":72,\"ownerId\":1,\"type\":\"pdf\",\"duration\":60,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":60,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":68,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"}],\"mediaIds\":[64],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(807,1585676078,1,'Saved','Playlist',72,'{\"campaignId\":[\"15\"],\"layoutId\":[\"27\"]}'),(808,1585676100,0,'Saved','Playlist',71,'{\"campaignId\":[\"15\"],\"layoutId\":[\"26\"]}'),(809,1585676100,0,'Saved','Playlist',72,'{\"duration\":\"0 > 60\",\"campaignId\":[\"15\"],\"layoutId\":[\"27\"]}'),(810,1585676112,1,'Saved','Widget',68,'{\"useDuration\":\"0 > 1\",\"campaignId\":[\"15\"],\"layoutId\":[\"27\"]}'),(811,1585676128,1,'Updated Draft','Layout',27,'{\"backgroundColor\":\"#000 > #000000\",\"status\":\"1 > 3\",\"campaignId\":[15]}'),(812,1585676365,1,'Deleted','Playlist',71,'{\"playlistId\":71,\"regionId\":70}'),(813,1585676365,1,'Region Deleted','Region',70,'{\"regionId\":70,\"layoutId\":26}'),(814,1585676365,1,'Layout Deleted','Layout',26,'{\"layoutId\":26}'),(815,1585676365,1,'Deleted draft for 27','Layout',26,'{\"parentId\":\" > 27\"}'),(816,1585676365,1,'Updated Draft','Layout',27,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[15]}'),(817,1585747634,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(818,1585747860,1,'Saved','Widget',69,'{\"widgetId\":69,\"playlistId\":69,\"ownerId\":1,\"type\":\"image\",\"duration\":10,\"displayOrder\":1,\"useDuration\":0,\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":69,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":69,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[26],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(819,1585747879,1,'Saved','Widget',70,'{\"widgetId\":70,\"playlistId\":69,\"ownerId\":1,\"type\":\"image\",\"duration\":10,\"displayOrder\":2,\"useDuration\":0,\"calculatedDuration\":10,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":70,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":70,\"type\":\"attrib\",\"option\":\"scaleType\",\"value\":\"center\"}],\"mediaIds\":[21],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(820,1585747888,1,'Saved','Widget',71,'{\"widgetId\":71,\"playlistId\":69,\"ownerId\":1,\"type\":\"video\",\"duration\":0,\"displayOrder\":3,\"useDuration\":0,\"calculatedDuration\":7,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":71,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":71,\"type\":\"attrib\",\"option\":\"mute\",\"value\":0}],\"mediaIds\":[27],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(821,1585747998,1,'Checked out','Layout',28,'{\"layoutId\":27,\"layout\":\"Test_PDF\",\"campaignId\":15}'),(822,1585747998,1,'Added','Widget',72,'{\"widgetId\":72,\"type\":\"pdf\",\"layoutId\":\"28\",\"campaignId\":\"15\"}'),(823,1585747998,1,'Saved','Widget',72,'{\"widgetId\":\"68 > 72\",\"playlistId\":\"72 > 73\"}'),(824,1585747998,1,'Saved','Playlist',73,'{\"playlistId\":\"72 > 73\",\"regionId\":\"71 > 72\",\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(825,1585747998,1,'Added','Region',72,'{\"regionId\":72,\"campaignId\":\"15\",\"details\":\"Region Test_PDF-1 - 1920 x 1080 (0, 0). RegionId = 72, LayoutId = 28. OwnerId = 1. Duration = 60\"}'),(826,1585747998,1,'Updated','Layout',27,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[15]}'),(827,1585748002,1,'Saved','Playlist',73,'{\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(828,1585748022,1,'Added','Widget',73,'{\"widgetId\":73,\"type\":\"subplaylist\",\"layoutId\":\"28\",\"campaignId\":\"15\"}'),(829,1585748022,1,'Saved','Widget',73,'{\"widgetId\":73,\"playlistId\":\"73\",\"ownerId\":1,\"type\":\"subplaylist\",\"duration\":10,\"displayOrder\":2,\"useDuration\":0,\"calculatedDuration\":0,\"createdDt\":null,\"modifiedDt\":null,\"fromDt\":null,\"toDt\":null,\"transitionIn\":null,\"transitionOut\":null,\"transitionDurationIn\":null,\"transitionDurationOut\":null,\"widgetOptions\":[{\"widgetId\":73,\"type\":\"attrib\",\"option\":\"enableStat\",\"value\":\"Inherit\"},{\"widgetId\":73,\"type\":\"attrib\",\"option\":\"upperLimit\",\"value\":0},{\"widgetId\":73,\"type\":\"attrib\",\"option\":\"lowerLimit\",\"value\":0}],\"mediaIds\":[],\"audio\":[],\"permissions\":[],\"playlist\":null,\"tempId\":null,\"isNew\":true}'),(830,1585748049,1,'Deleted','Widget',72,'{\"widgetId\":72,\"playlistId\":73}'),(831,1585748050,1,'Saved','Playlist',73,'{\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(832,1585748063,1,'Saved','Widget',73,'{\"calculatedDuration\":\"0 > 27\",\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(833,1585748064,1,'Saved','Playlist',73,'{\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(834,1585748081,1,'Saved','Widget',73,'{\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(835,1585748087,1,'Deleted','Widget',68,'{\"widgetId\":68,\"playlistId\":72}'),(836,1585748087,1,'Deleted','Playlist',72,'{\"playlistId\":72,\"regionId\":71}'),(837,1585748087,1,'Region Deleted','Region',71,'{\"regionId\":71,\"layoutId\":27}'),(838,1585748087,1,'Layout Deleted','Layout',27,'{\"layoutId\":27}'),(839,1585748088,1,'Deleted draft for 28','Layout',27,'{\"parentId\":\" > 28\"}'),(840,1585748088,1,'Updated Draft','Layout',28,'{\"publishedStatusId\":\"2 > 1\",\"status\":\"1 > 3\",\"campaignId\":[15]}'),(841,1585748100,0,'Saved','Playlist',69,'{\"duration\":\"0 > 27\"}'),(842,1585748100,0,'Saved','Playlist',73,'{\"duration\":\"0 > 27\",\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(843,1585748137,1,'Updated','Layout',28,'{\"layout\":\"Test_PDF > Diaporama\",\"campaignId\":[15]}'),(844,1585748290,1,'Deleted','Widget',73,'{\"widgetId\":73,\"playlistId\":73}'),(845,1585748290,1,'Deleted','Widget',69,'{\"widgetId\":69,\"playlistId\":69}'),(846,1585748290,1,'Deleted','Widget',70,'{\"widgetId\":70,\"playlistId\":69}'),(847,1585748290,1,'Deleted','Widget',71,'{\"widgetId\":71,\"playlistId\":69}'),(848,1585748290,1,'Deleted','Playlist',69,'{\"playlistId\":69,\"regionId\":0}'),(849,1585748400,0,'Saved','Playlist',73,'{\"duration\":\"27 > 0\",\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(850,1585748400,0,'Saved','Playlist',73,'{\"campaignId\":[\"15\"],\"layoutId\":[\"28\"]}'),(851,1585750974,1,'Saved','Schedule',1,'{\"fromDt\":\"0 > 1585692000\",\"toDt\":\"2147483647 > \",\"recurrenceType\":\" > Day\",\"recurrenceDetail\":\" > 1\",\"dayPartId\":\"2 > 3\"}'),(852,1585751156,1,'Saved','Schedule',1,'{\"recurrenceRange\":\" > 1585751156\"}'),(853,1585751156,1,'Added','Schedule',3,'{\"eventId\":\"1 > 3\",\"fromDt\":\"1585692000 > 1585837556\"}'),(854,1585816586,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(855,1585819872,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(856,1585823827,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(857,1585899891,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(858,1585904425,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/80.0.3987.149 Safari\\/537.36\"}'),(859,1591187225,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.61 Safari\\/537.36\"}'),(860,1591190610,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.61 Safari\\/537.36\"}'),(861,1591706209,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(862,1592147784,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(863,1592154408,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(864,1592167146,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(865,1592210706,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(866,1592213695,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (iPhone; CPU iPhone OS 13_5_1 like Mac OS X) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/13.1.1 Mobile\\/15E148 Safari\\/604.1\"}'),(867,1592214176,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(868,1592214472,1,'Display Saved','Display',4,'{\"licensed\":\"0 > 1\"}'),(869,1592237271,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(870,1592245774,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(871,1592246015,1,'Display Saved','Display',5,'{\"licensed\":\"0 > 1\"}'),(872,1592297443,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(873,1592308451,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(874,1592321273,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(875,1592339560,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(876,1592341365,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.97 Safari\\/537.36\"}'),(877,1592503508,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(878,1592505580,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(879,1592568737,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(880,1592570432,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(881,1592570441,1,'Saved','Playlist',25,'{\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(882,1592570441,1,'Saved','Playlist',26,'{\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(883,1592570441,1,'Saved','Playlist',27,'{\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(884,1592570441,1,'Saved','Playlist',28,'{\"campaignId\":[\"9\"],\"layoutId\":[\"11\"]}'),(885,1592570602,1,'Deleted','Media',64,'[]'),(886,1592572196,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(887,1592573526,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (iPhone; CPU iPhone OS 13_5_1 like Mac OS X) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/13.1.1 Mobile\\/15E148 Safari\\/604.1\"}'),(888,1592573549,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (iPhone; CPU iPhone OS 13_5_1 like Mac OS X) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/13.1.1 Mobile\\/15E148 Safari\\/604.1\"}'),(889,1592574686,1,'Display Deleted','Display',4,'{\"displayId\":4}'),(890,1592574807,1,'Display Deleted','Display',6,'{\"displayId\":6}'),(891,1592574881,1,'Display Saved','Display',7,'{\"licensed\":\"0 > 1\"}'),(892,1592574962,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(893,1592587827,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(894,1592665099,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(895,1592729253,1,'Login Granted','User',1,'{\"IPAddress\":\"172.18.0.1\",\"UserAgent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/83.0.4103.106 Safari\\/537.36\"}'),(896,1592729338,1,'Checked out','Layout',30,'{\"layoutId\":22,\"layout\":\"Compte \\u00e0 rebours 60 ans\",\"campaignId\":13}'),(897,1592729338,1,'Added','Widget',68,'{\"widgetId\":68,\"type\":\"image\",\"layoutId\":\"30\",\"campaignId\":\"13\"}'),(898,1592729338,1,'Saved','Widget',68,'{\"widgetId\":\"61 > 68\",\"playlistId\":\"62 > 74\"}'),(899,1592729338,1,'Saved','Playlist',74,'{\"playlistId\":\"62 > 74\",\"regionId\":\"62 > 73\",\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(900,1592729338,1,'Added','Region',73,'{\"regionId\":73,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-1 - 928 x 894 (93, 959). RegionId = 73, LayoutId = 30. OwnerId = 1. Duration = 10\"}'),(901,1592729338,1,'Added','Widget',69,'{\"widgetId\":69,\"type\":\"text\",\"layoutId\":\"30\",\"campaignId\":\"13\"}'),(902,1592729338,1,'Saved','Widget',69,'{\"widgetId\":\"62 > 69\",\"playlistId\":\"63 > 75\"}'),(903,1592729338,1,'Saved','Playlist',75,'{\"playlistId\":\"63 > 75\",\"regionId\":\"63 > 74\",\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(904,1592729338,1,'Added','Region',74,'{\"regionId\":74,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-2 - 845 x 219 (100, 61). RegionId = 74, LayoutId = 30. OwnerId = 1. Duration = 5\"}'),(905,1592729338,1,'Added','Widget',70,'{\"widgetId\":70,\"type\":\"text\",\"layoutId\":\"30\",\"campaignId\":\"13\"}'),(906,1592729338,1,'Saved','Widget',70,'{\"widgetId\":\"63 > 70\",\"playlistId\":\"64 > 76\"}'),(907,1592729338,1,'Saved','Playlist',76,'{\"playlistId\":\"64 > 76\",\"regionId\":\"64 > 75\",\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(908,1592729338,1,'Added','Region',75,'{\"regionId\":75,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-3 - 825 x 149 (841, 59). RegionId = 75, LayoutId = 30. OwnerId = 1. Duration = 5\"}'),(909,1592729338,1,'Added','Widget',71,'{\"widgetId\":71,\"type\":\"countdown\",\"layoutId\":\"30\",\"campaignId\":\"13\"}'),(910,1592729338,1,'Saved','Widget',71,'{\"widgetId\":\"64 > 71\",\"playlistId\":\"65 > 77\"}'),(911,1592729338,1,'Saved','Playlist',77,'{\"playlistId\":\"65 > 77\",\"regionId\":\"65 > 76\",\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(912,1592729338,1,'Added','Region',76,'{\"regionId\":76,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-4 - 900 x 300 (515, 27). RegionId = 76, LayoutId = 30. OwnerId = 1. Duration = 60\"}'),(913,1592729338,1,'Added','Widget',72,'{\"widgetId\":72,\"type\":\"text\",\"layoutId\":\"30\",\"campaignId\":\"13\"}'),(914,1592729338,1,'Saved','Widget',72,'{\"widgetId\":\"65 > 72\",\"playlistId\":\"66 > 78\"}'),(915,1592729338,1,'Saved','Playlist',78,'{\"playlistId\":\"66 > 78\",\"regionId\":\"66 > 77\",\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(916,1592729338,1,'Added','Region',77,'{\"regionId\":77,\"campaignId\":\"13\",\"details\":\"Region Compte \\u00e0 rebours 60 ans-5 - 855 x 163 (330, 55). RegionId = 77, LayoutId = 30. OwnerId = 1. Duration = 5\"}'),(917,1592729338,1,'Updated','Layout',22,'{\"publishedStatusId\":\"1 > 2\",\"campaignId\":[13]}'),(918,1592729342,1,'Saved','Playlist',74,'{\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(919,1592729342,1,'Saved','Playlist',75,'{\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(920,1592729342,1,'Saved','Playlist',76,'{\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(921,1592729342,1,'Saved','Playlist',77,'{\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}'),(922,1592729342,1,'Saved','Playlist',78,'{\"campaignId\":[\"13\"],\"layoutId\":[\"30\"]}');
/*!40000 ALTER TABLE `auditlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bandwidth`
--

DROP TABLE IF EXISTS `bandwidth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bandwidth` (
  `displayId` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `size` bigint(20) NOT NULL,
  PRIMARY KEY (`displayId`,`type`,`month`),
  KEY `type` (`type`),
  CONSTRAINT `bandwidth_ibfk_1` FOREIGN KEY (`type`) REFERENCES `bandwidthtype` (`bandwidthTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandwidth`
--

LOCK TABLES `bandwidth` WRITE;
/*!40000 ALTER TABLE `bandwidth` DISABLE KEYS */;
INSERT INTO `bandwidth` VALUES (1,1,1583107200,15294263),(1,1,1585778400,2434118),(1,1,1585782000,1125016),(1,1,1591048800,4136),(1,2,1583107200,105332029),(1,2,1585778400,16314455),(1,2,1585782000,7504207),(1,2,1591048800,13547),(1,3,1583107200,18891905),(1,3,1585778400,3032905),(1,3,1585782000,1161655),(1,3,1591048800,2621),(1,4,1583107200,31816298),(1,4,1585782000,2325942),(1,5,1583107200,4730518),(1,5,1585778400,1009474),(1,5,1585782000,1667092),(1,5,1591048800,20801),(1,6,1583107200,46617626),(1,6,1585778400,7064644),(1,6,1585782000,3224643),(1,6,1591048800,5814),(1,7,1583107200,768255),(1,7,1585778400,122370),(1,7,1585782000,56355),(1,7,1591048800,117),(1,9,1583107200,1924387),(1,9,1585778400,306898),(1,9,1585782000,149302),(1,11,1583107200,991),(1,11,1585778400,11970),(1,11,1585782000,2124),(2,1,1583107200,418632),(2,2,1583107200,218269),(2,3,1583107200,35335),(2,4,1583107200,18592618),(2,5,1583107200,440499),(2,6,1583107200,1302904),(2,7,1583107200,36128),(2,9,1583107200,36408),(3,1,1583107200,14689),(3,2,1583107200,94807),(3,3,1583107200,15699),(3,4,1583107200,24831268),(3,5,1583107200,24413),(3,6,1583107200,56439),(3,7,1583107200,672),(3,9,1583107200,1972),(4,1,1591048800,16697),(4,2,1591048800,68470),(4,3,1591048800,12841),(4,4,1591048800,25896857),(4,5,1591048800,62466),(4,6,1591048800,34272),(4,7,1591048800,615),(4,9,1591048800,2022),(5,1,1591048800,187445),(5,2,1591048800,1951581),(5,3,1591048800,352137),(5,4,1591048800,53982687),(5,5,1591048800,2935203),(5,6,1591048800,44388),(5,9,1591048800,7833),(6,1,1591048800,411),(7,1,1591048800,181);
/*!40000 ALTER TABLE `bandwidth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bandwidthtype`
--

DROP TABLE IF EXISTS `bandwidthtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bandwidthtype` (
  `bandwidthTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  PRIMARY KEY (`bandwidthTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandwidthtype`
--

LOCK TABLES `bandwidthtype` WRITE;
/*!40000 ALTER TABLE `bandwidthtype` DISABLE KEYS */;
INSERT INTO `bandwidthtype` VALUES (1,'Register'),(2,'Required Files'),(3,'Schedule'),(4,'Get File'),(5,'Get Resource'),(6,'Media Inventory'),(7,'Notify Status'),(8,'Submit Stats'),(9,'Submit Log'),(10,'Blacklist'),(11,'Screen Shot');
/*!40000 ALTER TABLE `bandwidthtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `blacklistId` int(11) NOT NULL AUTO_INCREMENT,
  `mediaId` int(11) NOT NULL,
  `displayId` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `reportingDisplayId` int(11) DEFAULT NULL,
  `reason` text,
  `isIgnored` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blacklistId`),
  KEY `mediaId` (`mediaId`),
  KEY `displayId` (`displayId`),
  CONSTRAINT `blacklist_ibfk_1` FOREIGN KEY (`mediaId`) REFERENCES `media` (`mediaId`),
  CONSTRAINT `blacklist_ibfk_2` FOREIGN KEY (`displayId`) REFERENCES `display` (`displayId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blacklist`
--

LOCK TABLES `blacklist` WRITE;
/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign` (
  `campaignId` int(11) NOT NULL AUTO_INCREMENT,
  `campaign` varchar(254) NOT NULL,
  `isLayoutSpecific` tinyint(4) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`campaignId`),
  KEY `userId` (`userId`),
  CONSTRAINT `campaign_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign`
--

LOCK TABLES `campaign` WRITE;
/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
INSERT INTO `campaign` VALUES (3,'indication salles',1,1),(4,'InfoProjetRobotique',1,1),(5,'TwitterTest',1,1),(6,'Vidéo + Horloge',1,1),(7,'MEP par défaut',1,1),(8,'routine',0,1),(9,'AffichePaysage + Horloge Modèle',1,1),(10,'Météo + Logos et horloge',1,1),(11,'Météo seule',1,1),(13,'Compte à rebours 60 ans',1,1),(14,'CoViD-19',1,1),(15,'Diaporama',1,1);
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command`
--

DROP TABLE IF EXISTS `command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `command` (
  `commandId` int(11) NOT NULL AUTO_INCREMENT,
  `command` varchar(254) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`commandId`),
  KEY `userId` (`userId`),
  CONSTRAINT `command_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command`
--

LOCK TABLES `command` WRITE;
/*!40000 ALTER TABLE `command` DISABLE KEYS */;
/*!40000 ALTER TABLE `command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataset`
--

DROP TABLE IF EXISTS `dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataset` (
  `dataSetId` int(11) NOT NULL AUTO_INCREMENT,
  `dataSet` varchar(50) NOT NULL,
  `description` varchar(254) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  `lastDataEdit` int(11) NOT NULL DEFAULT '0',
  `code` varchar(50) DEFAULT NULL,
  `isLookup` tinyint(4) NOT NULL,
  `isRemote` tinyint(4) NOT NULL DEFAULT '0',
  `method` enum('GET','POST') DEFAULT NULL,
  `uri` varchar(250) DEFAULT NULL,
  `postData` text,
  `authentication` varchar(10) DEFAULT NULL,
  `username` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `customHeaders` text,
  `refreshRate` int(11) NOT NULL DEFAULT '86400',
  `clearRate` int(11) NOT NULL DEFAULT '0',
  `runsAfter` int(11) DEFAULT NULL,
  `dataRoot` varchar(250) DEFAULT NULL,
  `lastSync` int(11) NOT NULL DEFAULT '0',
  `summarize` varchar(10) DEFAULT NULL,
  `summarizeField` varchar(250) DEFAULT NULL,
  `lastClear` int(11) NOT NULL DEFAULT '0',
  `ignoreFirstRow` tinyint(4) DEFAULT NULL,
  `sourceId` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`dataSetId`),
  KEY `userId` (`userId`),
  CONSTRAINT `dataset_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataset`
--

LOCK TABLES `dataset` WRITE;
/*!40000 ALTER TABLE `dataset` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasetcolumn`
--

DROP TABLE IF EXISTS `datasetcolumn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasetcolumn` (
  `dataSetColumnId` int(11) NOT NULL AUTO_INCREMENT,
  `dataSetId` int(11) NOT NULL,
  `heading` varchar(50) NOT NULL,
  `dataTypeId` int(11) NOT NULL,
  `dataSetColumnTypeId` int(11) NOT NULL,
  `listContent` varchar(1000) DEFAULT NULL,
  `columnOrder` smallint(6) NOT NULL,
  `formula` varchar(1000) DEFAULT NULL,
  `remoteField` varchar(250) DEFAULT NULL,
  `showFilter` tinyint(4) NOT NULL DEFAULT '1',
  `showSort` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`dataSetColumnId`),
  KEY `dataSetId` (`dataSetId`),
  KEY `dataTypeId` (`dataTypeId`),
  KEY `dataSetColumnTypeId` (`dataSetColumnTypeId`),
  CONSTRAINT `datasetcolumn_ibfk_1` FOREIGN KEY (`dataSetId`) REFERENCES `dataset` (`dataSetId`),
  CONSTRAINT `datasetcolumn_ibfk_2` FOREIGN KEY (`dataTypeId`) REFERENCES `datatype` (`dataTypeId`),
  CONSTRAINT `datasetcolumn_ibfk_3` FOREIGN KEY (`dataSetColumnTypeId`) REFERENCES `datasetcolumntype` (`dataSetColumnTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasetcolumn`
--

LOCK TABLES `datasetcolumn` WRITE;
/*!40000 ALTER TABLE `datasetcolumn` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasetcolumn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasetcolumntype`
--

DROP TABLE IF EXISTS `datasetcolumntype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasetcolumntype` (
  `dataSetColumnTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `dataSetColumnType` varchar(100) NOT NULL,
  PRIMARY KEY (`dataSetColumnTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasetcolumntype`
--

LOCK TABLES `datasetcolumntype` WRITE;
/*!40000 ALTER TABLE `datasetcolumntype` DISABLE KEYS */;
INSERT INTO `datasetcolumntype` VALUES (1,'Value'),(2,'Formula'),(3,'Remote');
/*!40000 ALTER TABLE `datasetcolumntype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasetrss`
--

DROP TABLE IF EXISTS `datasetrss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasetrss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dataSetId` int(11) NOT NULL,
  `psk` varchar(254) NOT NULL,
  `title` varchar(254) NOT NULL,
  `author` varchar(254) NOT NULL,
  `titleColumnId` int(11) DEFAULT NULL,
  `summaryColumnId` int(11) DEFAULT NULL,
  `contentColumnId` int(11) DEFAULT NULL,
  `publishedDateColumnId` int(11) DEFAULT NULL,
  `sort` text,
  `filter` text,
  PRIMARY KEY (`id`),
  KEY `dataSetId` (`dataSetId`),
  CONSTRAINT `datasetrss_ibfk_1` FOREIGN KEY (`dataSetId`) REFERENCES `dataset` (`dataSetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasetrss`
--

LOCK TABLES `datasetrss` WRITE;
/*!40000 ALTER TABLE `datasetrss` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasetrss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datatype`
--

DROP TABLE IF EXISTS `datatype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datatype` (
  `dataTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `dataType` varchar(100) NOT NULL,
  PRIMARY KEY (`dataTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datatype`
--

LOCK TABLES `datatype` WRITE;
/*!40000 ALTER TABLE `datatype` DISABLE KEYS */;
INSERT INTO `datatype` VALUES (1,'String'),(2,'Number'),(3,'Date'),(4,'External Image'),(5,'Library Image'),(6,'HTML');
/*!40000 ALTER TABLE `datatype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daypart`
--

DROP TABLE IF EXISTS `daypart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daypart` (
  `dayPartId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(50) DEFAULT NULL,
  `isRetired` tinyint(4) NOT NULL DEFAULT '0',
  `userId` int(11) NOT NULL,
  `startTime` varchar(8) NOT NULL DEFAULT '00:00:00',
  `endTime` varchar(8) NOT NULL DEFAULT '00:00:00',
  `exceptions` text,
  `isAlways` tinyint(4) NOT NULL DEFAULT '0',
  `isCustom` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dayPartId`),
  KEY `userId` (`userId`),
  CONSTRAINT `daypart_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daypart`
--

LOCK TABLES `daypart` WRITE;
/*!40000 ALTER TABLE `daypart` DISABLE KEYS */;
INSERT INTO `daypart` VALUES (1,'Custom','User specifies the from/to date',0,1,'','','',0,1),(2,'Always','Event runs always',0,1,'','','',1,0),(3,'Semaine',NULL,0,1,'07:30:00','16:30:00','[{\"day\":\"Sat\",\"start\":\"00:00:00\",\"end\":\"23:59:00\"},{\"day\":\"Sun\",\"start\":\"00:00:00\",\"end\":\"23:59:00\"}]',0,0);
/*!40000 ALTER TABLE `daypart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `display`
--

DROP TABLE IF EXISTS `display`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `display` (
  `displayId` int(11) NOT NULL AUTO_INCREMENT,
  `display` varchar(50) NOT NULL,
  `auditingUntil` int(11) NOT NULL DEFAULT '0',
  `defaultLayoutId` int(11) NOT NULL,
  `license` varchar(40) DEFAULT NULL,
  `licensed` tinyint(4) NOT NULL DEFAULT '0',
  `loggedIn` tinyint(4) NOT NULL DEFAULT '0',
  `lastaccessed` int(11) DEFAULT NULL,
  `inc_schedule` tinyint(4) NOT NULL DEFAULT '0',
  `email_alert` int(11) DEFAULT '0',
  `alert_timeout` int(11) DEFAULT '0',
  `clientAddress` varchar(50) DEFAULT NULL,
  `mediaInventoryStatus` tinyint(4) NOT NULL DEFAULT '0',
  `macAddress` varchar(254) DEFAULT NULL,
  `lastChanged` int(11) DEFAULT NULL,
  `numberOfMacAddressChanges` int(11) DEFAULT '0',
  `lastWakeOnLanCommandSent` int(11) DEFAULT NULL,
  `wakeOnLan` tinyint(4) NOT NULL DEFAULT '0',
  `wakeOnLanTime` varchar(5) DEFAULT NULL,
  `broadCastAddress` varchar(100) DEFAULT NULL,
  `secureOn` varchar(17) DEFAULT NULL,
  `cidr` varchar(6) DEFAULT NULL,
  `geoLocation` point DEFAULT NULL,
  `client_type` varchar(20) DEFAULT NULL,
  `client_version` varchar(15) DEFAULT NULL,
  `client_code` smallint(6) DEFAULT NULL,
  `displayProfileId` int(11) DEFAULT NULL,
  `screenShotRequested` tinyint(4) NOT NULL DEFAULT '0',
  `storageAvailableSpace` bigint(20) DEFAULT NULL,
  `storageTotalSpace` bigint(20) DEFAULT NULL,
  `xmrChannel` varchar(254) DEFAULT NULL,
  `xmrPubKey` text,
  `lastCommandSuccess` tinyint(4) NOT NULL DEFAULT '2',
  `deviceName` varchar(254) DEFAULT NULL,
  `timeZone` varchar(254) DEFAULT NULL,
  `overrideConfig` text,
  `newCmsAddress` varchar(40) DEFAULT NULL,
  `newCmsKey` varchar(40) DEFAULT NULL,
  `orientation` varchar(10) DEFAULT NULL,
  `resolution` varchar(10) DEFAULT NULL,
  `commercialLicence` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`displayId`),
  UNIQUE KEY `license` (`license`),
  KEY `defaultLayoutId` (`defaultLayoutId`),
  KEY `displayProfileId` (`displayProfileId`),
  CONSTRAINT `display_ibfk_1` FOREIGN KEY (`displayProfileId`) REFERENCES `displayprofile` (`displayProfileId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `display`
--

LOCK TABLES `display` WRITE;
/*!40000 ALTER TABLE `display` DISABLE KEYS */;
INSERT INTO `display` VALUES (1,'ROBOTECH-SERVER',0,7,'5a9f2f73d0526fc5ae0b3ad5c07bfd58',1,0,1592210652,0,0,0,'172.18.0.1',3,'A4:BA:DB:FE:DA:17',0,0,0,0,NULL,NULL,NULL,NULL,NULL,'windows','2 R201',201,NULL,0,67120517120,119455870976,'8c623dc02a40ff06c9175d7c363b3958','-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCq39j2Tj3CXcA/GaMak662kSk2\n74GqY7Tn0wu/gRr6ckB+NV8Ay68N8qYvpOESAUnvC2TaCw6e2uPHLYNZIGDRXV61\nVfStlxp65VsvywkihuzCndf3gvByJl8GcKwlRfkBBuGdK9pGY9cDARneuCQ0h8oO\naMI6X4DnoyFRt6MnLQIDAQAB\n-----END PUBLIC KEY-----',0,'WIN-MCKU55A4KFA',NULL,'[{\"name\":\"collectInterval\",\"value\":60}]',NULL,NULL,NULL,NULL,3),(2,'Androïd',0,7,'37f2d0c2-22d2-3042-81eb-5ff2efcfd48f',1,0,1585161453,0,0,0,'172.18.0.1',3,'d4:40:f0:fd:ee:23',0,0,0,0,NULL,NULL,NULL,NULL,NULL,'android','2',204,NULL,0,3836968960,4692516864,'75559caea7ef2a986d66d6bc0ec1e19c','-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4btL+olWyLWDSrJatOqbl4KnjL1ukHZO\newCU16zTdI37G7RlOMGSCpyd4ZQxKqp3K53CWn7rBozVC41fsvd9swir74Nbg5i8H2tzasYKTOrr\nZjl6xn2CSJ5PZteRQsE5mIAeHYJjFJw3OoLkD6eSjeW53U7n2VwJvZn183FayKM3HiF7txWCOeFg\ntTtK1NuYxPl6rgdsmDgNicp2de5ixrr1f8Xx2wQ3j+7ulsmNz0aMDfBK3T0p0Hm4nzRQfpIotiqc\nc9xZO5uuxzDXy3rbLnWPa6ZN39qYw0HtCXfobQXUgXxVOtkXnBhE/7SYS5cjWFd1N3ROWS5fSQEh\nAp3FYQIDAQAB\n-----END PUBLIC KEY-----\n',0,'867538020547353','Europe/Paris','[{\"name\":\"collectInterval\",\"value\":60}]',NULL,NULL,'portrait','720x1280',NULL),(3,'PC-THOMAS',0,7,'661de0719b61c63fa740475a2c4c43cb',1,0,1585158647,0,0,0,'172.18.0.1',3,'0A:00:27:00:00:11',0,0,0,0,NULL,NULL,NULL,NULL,NULL,'windows','2 R201',201,NULL,0,87872360448,399268376576,'3de5a64aac2e0c79501d578d31d05b0c','-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDG5/OihGbYUncc6EKiPbI3RKwE\nj7rG80DXLEEEqFDJZ3vN1EbLlq/pg78WTJeatfWLq4IZRkqbmW7uljCy5WW9thas\nu2VBUuj1xMJcNntaWUFiua2wfG4aKI4p4hFDNsFO/rkwq83mxWtvw94hpv74kTJF\nREmDJOPfPaaSszhQ7wIDAQAB\n-----END PUBLIC KEY-----',0,'PC-THOMAS',NULL,'[]',NULL,NULL,NULL,NULL,3),(5,'Display',0,7,'e11fa19a359ec3ff0d7549d91b0d8e6b',1,0,1592395849,0,0,0,'172.18.0.1',3,'08:00:27:64:97:5b',0,0,0,0,NULL,NULL,NULL,NULL,NULL,'linux','1.8-R5',50,NULL,0,NULL,NULL,'4c274c203d82a987921934a0339280d5','-----BEGIN PUBLIC KEY-----\nMBowDQYJKoZIhvcNAQEBBQADCQAwBgIBAAIBAA==\n-----END PUBLIC KEY-----',0,NULL,NULL,'[]',NULL,NULL,NULL,NULL,NULL),(7,'PC-BUBU',0,7,'70202dd4ce974f135fe414f2a2abaee0',1,0,1592574826,0,0,0,'172.18.0.1',3,'A2:56:F3:3A:E5:A5',0,0,0,0,NULL,NULL,NULL,NULL,NULL,'windows','2 R254.1',254,NULL,0,NULL,NULL,'a7e065ea719a50eb103c6ed9109fde05','-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCVTsvC4mpAvlrQqhAmpFfMjRbY\nsIbzkRgPesWTHiz1XV32LWaVMziqbor7Dcll6A45duSU5/5Qppgh2MIYli+xzUAa\n9BDspHTwlDPZ8Uel90yZ7K0IOgdeU/MIHzAzNfeahx9QA30mh+7ZhMwoVRrLz2CM\ns5hDSV+7RFSFSaYAIwIDAQAB\n-----END PUBLIC KEY-----',0,NULL,NULL,'[]',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `display` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `displayevent`
--

DROP TABLE IF EXISTS `displayevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `displayevent` (
  `displayEventId` int(11) NOT NULL AUTO_INCREMENT,
  `eventDate` int(11) NOT NULL,
  `displayId` int(11) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) DEFAULT NULL,
  PRIMARY KEY (`displayEventId`),
  KEY `eventDate` (`eventDate`),
  KEY `displayId` (`displayId`,`end`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `displayevent`
--

LOCK TABLES `displayevent` WRITE;
/*!40000 ALTER TABLE `displayevent` DISABLE KEYS */;
INSERT INTO `displayevent` VALUES (1,1585147308,1,1585147069,1585147372),(2,1585147336,2,1585147176,1585147464),(3,1585155000,3,1585154634,1585158463),(4,1585159201,3,1585158647,NULL),(5,1585159501,2,1585159142,1585159590),(6,1585159801,2,1585159590,1585159891),(7,1585160101,2,1585159891,1585160211),(8,1585160401,2,1585160211,1585160552),(9,1585160701,2,1585160552,1585160852),(10,1585161001,2,1585160852,1585161152),(11,1585161301,2,1585161152,1585161453),(12,1585161601,2,1585161453,NULL),(13,1585495501,1,1585410541,1585503362),(14,1585728301,1,1585727981,1585748194),(15,1585748400,1,1585748255,1585749612),(16,1585750200,1,1585750133,1585750227),(17,1585822800,1,1585822642,1585822861),(18,1585823100,1,1585822861,1587751055),(19,1587751500,1,1587751304,1587751564),(20,1587751800,1,1587751564,1592210590),(21,1592211000,1,1592210652,NULL),(22,1592215501,4,1592215104,1592297505),(23,1592251500,5,1592251160,1592297637),(24,1592298300,4,1592297830,1592501862),(25,1592331600,5,1592331003,1592338684),(26,1592342100,5,1592341697,1592395849),(27,1592396400,5,1592395849,NULL),(28,1592502300,4,1592501862,1592573149),(29,1592573560,4,1592573149,NULL);
/*!40000 ALTER TABLE `displayevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `displaygroup`
--

DROP TABLE IF EXISTS `displaygroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `displaygroup` (
  `displayGroupId` int(11) NOT NULL AUTO_INCREMENT,
  `displayGroup` varchar(50) NOT NULL,
  `description` varchar(254) DEFAULT NULL,
  `isDisplaySpecific` tinyint(4) NOT NULL DEFAULT '0',
  `isDynamic` tinyint(4) NOT NULL DEFAULT '0',
  `dynamicCriteria` varchar(254) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  `dynamicCriteriaTags` varchar(254) DEFAULT NULL,
  `bandwidthLimit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`displayGroupId`),
  KEY `userId` (`userId`),
  CONSTRAINT `displaygroup_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `displaygroup`
--

LOCK TABLES `displaygroup` WRITE;
/*!40000 ALTER TABLE `displaygroup` DISABLE KEYS */;
INSERT INTO `displaygroup` VALUES (1,'ROBOTECH-SERVER',NULL,1,0,NULL,1,NULL,0),(2,'Androïd',NULL,1,0,NULL,1,NULL,0),(3,'Tous',NULL,0,0,NULL,1,NULL,0),(4,'PC-THOMAS',NULL,1,0,NULL,1,NULL,0),(6,'Display',NULL,1,0,NULL,1,NULL,0),(8,'PC-BUBU',NULL,1,0,NULL,1,NULL,0);
/*!40000 ALTER TABLE `displaygroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `displayprofile`
--

DROP TABLE IF EXISTS `displayprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `displayprofile` (
  `displayProfileId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  `config` text,
  `isDefault` tinyint(4) NOT NULL DEFAULT '0',
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`displayProfileId`),
  KEY `userId` (`userId`),
  CONSTRAINT `displayprofile_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `displayprofile`
--

LOCK TABLES `displayprofile` WRITE;
/*!40000 ALTER TABLE `displayprofile` DISABLE KEYS */;
INSERT INTO `displayprofile` VALUES (1,'Windows','windows','[]',1,1),(2,'Android','android','[]',1,1),(3,'webOS','lg','[]',1,1),(4,'Tizen','sssp','[]',1,1),(5,'Linux','linux','[]',1,1);
/*!40000 ALTER TABLE `displayprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `groupId` int(11) NOT NULL AUTO_INCREMENT,
  `group` varchar(50) NOT NULL,
  `isUserSpecific` tinyint(4) NOT NULL DEFAULT '0',
  `isEveryone` tinyint(4) NOT NULL DEFAULT '0',
  `libraryQuota` int(11) DEFAULT NULL,
  `isSystemNotification` tinyint(4) NOT NULL DEFAULT '0',
  `isDisplayNotification` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
INSERT INTO `group` VALUES (1,'Users',0,0,NULL,0,0),(2,'Everyone',0,1,NULL,0,0),(3,'robotech',1,0,0,1,0),(4,'System Notifications',0,0,NULL,1,0),(5,'Playlist Dashboard User',0,0,NULL,0,0);
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `help`
--

DROP TABLE IF EXISTS `help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `help` (
  `helpId` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(254) NOT NULL,
  `category` varchar(254) NOT NULL DEFAULT 'General',
  `link` varchar(254) NOT NULL,
  PRIMARY KEY (`helpId`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `help`
--

LOCK TABLES `help` WRITE;
/*!40000 ALTER TABLE `help` DISABLE KEYS */;
INSERT INTO `help` VALUES (1,'Layout','General','layouts.html'),(2,'Content','General','media.html'),(4,'Schedule','General','scheduling.html'),(5,'Group','General','users_groups.html'),(6,'Admin','General','cms_settings.html'),(7,'Report','General','troubleshooting.html'),(8,'Dashboard','General','tour.html'),(9,'User','General','users.html'),(10,'Display','General','displays.html'),(11,'DisplayGroup','General','displays_groups.html'),(12,'Layout','Add','layouts.html#Add_Layout'),(13,'Layout','Background','layouts_designer.html#Background'),(14,'Content','Assign','layouts_playlists.html#Assigning_Content'),(15,'Layout','RegionOptions','layouts_regions.html'),(16,'Content','AddtoLibrary','media_library.html'),(17,'Display','Edit','displays.html#Display_Edit'),(18,'Display','Delete','displays.html#Display_Delete'),(19,'Displays','Groups','displays_groups.html#Group_Members'),(20,'UserGroup','Add','users_groups.html#Adding_Group'),(21,'User','Add','users_administration.html#Add_User'),(22,'User','Delete','users_administration.html#Delete_User'),(23,'Content','Config','cms_settings.html#Content'),(24,'LayoutMedia','Permissions','users_permissions.html'),(25,'Region','Permissions','users_permissions.html'),(26,'Library','Assign','layouts_playlists.html#Add_From_Library'),(27,'Media','Delete','media_library.html#Delete'),(28,'DisplayGroup','Add','displays_groups.html#Add_Group'),(29,'DisplayGroup','Edit','displays_groups.html#Edit_Group'),(30,'DisplayGroup','Delete','displays_groups.html#Delete_Group'),(31,'DisplayGroup','Members','displays_groups.html#Group_Members'),(32,'DisplayGroup','Permissions','users_permissions.html'),(34,'Schedule','ScheduleNow','scheduling_now.html'),(35,'Layout','Delete','layouts.html#Delete_Layout'),(36,'Layout','Copy','layouts.html#Copy_Layout'),(37,'Schedule','Edit','scheduling_events.html#Edit'),(38,'Schedule','Add','scheduling_events.html#Add'),(39,'Layout','Permissions','users_permissions.html'),(40,'Display','MediaInventory','displays.html#Media_Inventory'),(41,'User','ChangePassword','users.html#Change_Password'),(42,'Schedule','Delete','scheduling_events.html'),(43,'Layout','Edit','layouts_designer.html#Edit_Layout'),(44,'Media','Permissions','users_permissions.html'),(45,'Display','DefaultLayout','displays.html#DefaultLayout'),(46,'UserGroup','Edit','users_groups.html#Edit_Group'),(47,'UserGroup','Members','users_groups.html#Group_Member'),(48,'User','PageSecurity','users_permissions.html#Page_Security'),(49,'User','MenuSecurity','users_permissions.html#Menu_Security'),(50,'UserGroup','Delete','users_groups.html#Delete_Group'),(51,'User','Edit','users_administration.html#Edit_User'),(52,'User','Applications','users_administration.html#Users_MyApplications'),(53,'User','SetHomepage','users_administration.html#Media_Dashboard'),(54,'DataSet','General','media_datasets.html'),(55,'DataSet','Add','media_datasets.html#Create_Dataset'),(56,'DataSet','Edit','media_datasets.html#Edit_Dataset'),(57,'DataSet','Delete','media_datasets.html#Delete_Dataset'),(58,'DataSet','AddColumn','media_datasets.html#Dataset_Column'),(59,'DataSet','EditColumn','media_datasets.html#Dataset_Column'),(60,'DataSet','DeleteColumn','media_datasets.html#Dataset_Column'),(61,'DataSet','Data','media_datasets.html#Dataset_Row'),(62,'DataSet','Permissions','users_permissions.html'),(63,'Fault','General','troubleshooting.html#Report_Fault'),(65,'Stats','General','displays_metrics.html'),(66,'Resolution','General','layouts_resolutions.html'),(67,'Template','General','layouts_templates.html'),(68,'Services','Register','#Registered_Applications'),(69,'OAuth','General','api_oauth.html'),(70,'Services','Log','api_oauth.html#oAuthLog'),(71,'Module','Edit','media_modules.html'),(72,'Module','General','media_modules.html'),(73,'Campaign','General','layouts_campaigns.html'),(74,'License','General','licence_information.html'),(75,'DataSet','ViewColumns','media_datasets.html#Dataset_Column'),(76,'Campaign','Permissions','users_permissions.html'),(77,'Transition','Edit','layouts_transitions.html'),(78,'User','SetPassword','users_administration.html#Set_Password'),(79,'DataSet','ImportCSV','media_datasets.htmlmedia_datasets.html#Import_CSV'),(80,'DisplayGroup','FileAssociations','displays_fileassociations.html'),(81,'Statusdashboard','General','tour_status_dashboard.html'),(82,'Displayprofile','General','displays_settings.html'),(83,'DisplayProfile','Edit','displays_settings.html#edit'),(84,'DisplayProfile','Delete','displays_settings.html#delete');
/*!40000 ALTER TABLE `help` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layout`
--

DROP TABLE IF EXISTS `layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `layout` (
  `layoutId` int(11) NOT NULL AUTO_INCREMENT,
  `layout` varchar(254) NOT NULL,
  `userId` int(11) NOT NULL,
  `createdDt` datetime NOT NULL,
  `modifiedDt` datetime NOT NULL,
  `description` varchar(254) DEFAULT NULL,
  `retired` tinyint(4) NOT NULL DEFAULT '0',
  `duration` int(11) NOT NULL,
  `backgroundImageId` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `width` decimal(10,0) NOT NULL,
  `height` decimal(10,0) NOT NULL,
  `backgroundColor` varchar(25) DEFAULT NULL,
  `backgroundzIndex` int(11) NOT NULL DEFAULT '1',
  `schemaVersion` tinyint(4) NOT NULL DEFAULT '2',
  `statusMessage` text,
  `parentId` int(11) DEFAULT NULL,
  `publishedStatusId` int(11) NOT NULL DEFAULT '1',
  `enableStat` int(11) DEFAULT NULL,
  `publishedDate` datetime DEFAULT NULL,
  `autoApplyTransitions` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`layoutId`),
  KEY `userId` (`userId`),
  KEY `backgroundImageId` (`backgroundImageId`),
  KEY `publishedStatusId` (`publishedStatusId`),
  CONSTRAINT `layout_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`),
  CONSTRAINT `layout_ibfk_2` FOREIGN KEY (`backgroundImageId`) REFERENCES `media` (`mediaId`),
  CONSTRAINT `layout_ibfk_3` FOREIGN KEY (`publishedStatusId`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout`
--

LOCK TABLES `layout` WRITE;
/*!40000 ALTER TABLE `layout` DISABLE KEYS */;
INSERT INTO `layout` VALUES (3,'indication salles',1,'2020-03-25 13:32:57','2020-03-25 13:35:02','',0,32,NULL,1,1920,1080,'#000',0,3,NULL,NULL,1,0,NULL,0),(4,'InfoProjetRobotique',1,'2020-03-25 13:32:59','2020-03-25 13:35:03','',0,30,NULL,1,1920,1080,'#2d88cc',0,3,NULL,NULL,1,0,NULL,0),(6,'Vidéo + Horloge',1,'2020-03-25 13:33:02','2020-03-25 13:35:03','Créer un modèle contenant une horloge en bas et une vidéo en haut\r\n+ Logos UL, INP et Polytech Nancy, sur fond bleu',0,10,NULL,1,1920,1080,'#2d88cc',0,3,NULL,NULL,1,0,NULL,0),(7,'MEP par défaut',1,'2020-03-25 13:33:16','2020-03-25 13:33:49','',0,33,NULL,1,1920,1080,'#000000',0,3,NULL,NULL,2,0,NULL,0),(8,'MEP par défaut',1,'2020-03-25 13:33:49','2020-03-25 13:34:39','',0,33,NULL,1,1920,1080,'#000000',0,3,NULL,7,2,0,NULL,0),(10,'TwitterTest',1,'2020-03-25 13:55:23','2020-03-25 14:38:42','',0,30,NULL,1,1920,1080,'#2ba3d6',0,3,NULL,NULL,1,0,NULL,0),(11,'AffichePaysage + Horloge Modèle',1,'2020-03-25 15:58:16','2020-06-19 14:40:41','Créer un modèle contenant une horloge en bas et une affiche principale en haut\r\n+ Logos UL, INP et Polytech Nancy, sur fond bleu',0,30,NULL,1,1920,1080,'#2d88cc',0,3,NULL,NULL,1,0,NULL,0),(14,'Météo + Logos et horloge',1,'2020-03-25 16:29:12','2020-03-25 16:31:21',NULL,0,30,NULL,1,1920,1080,'#2d88cc',0,3,NULL,NULL,1,0,NULL,0),(16,'Météo seule',1,'2020-03-25 16:35:14','2020-03-25 16:37:24',NULL,0,30,NULL,1,1920,1080,'#2d88cc',0,3,NULL,NULL,1,0,NULL,0),(22,'Compte à rebours 60 ans',1,'2020-03-25 17:52:20','2020-06-21 10:48:58',NULL,0,60,NULL,1,1920,1080,'#2b8fa6',0,3,NULL,NULL,2,0,NULL,0),(24,'CoViD-19',1,'2020-03-29 18:35:06','2020-03-31 09:49:01',NULL,0,30,NULL,2,1920,1080,'#000',0,3,NULL,NULL,2,0,NULL,0),(25,'CoViD-19',1,'2020-03-31 09:49:01','2020-03-31 09:49:51',NULL,0,30,NULL,2,1920,1080,'#000',0,3,NULL,24,2,0,NULL,0),(28,'Diaporama',1,'2020-04-01 14:33:18','2020-04-01 14:40:00',NULL,0,0,NULL,4,1920,1080,'#000000',0,3,'[\"Empty Region\"]',NULL,1,0,NULL,0),(29,'insersion par SQL',1,'2020-04-01 08:00:00','2020-04-01 08:00:00',NULL,0,20,NULL,1,1920,1080,'#000000',0,0,NULL,NULL,1,0,NULL,0),(30,'Compte à rebours 60 ans',1,'2020-06-21 10:48:58','2020-06-21 10:49:02',NULL,0,60,NULL,1,1920,1080,'#2b8fa6',0,3,NULL,22,2,0,NULL,0);
/*!40000 ALTER TABLE `layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layouthistory`
--

DROP TABLE IF EXISTS `layouthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `layouthistory` (
  `layoutHistoryId` int(11) NOT NULL AUTO_INCREMENT,
  `campaignId` int(11) NOT NULL,
  `layoutId` int(11) NOT NULL,
  `publishedDate` datetime NOT NULL,
  PRIMARY KEY (`layoutHistoryId`),
  KEY `campaignId` (`campaignId`),
  CONSTRAINT `layouthistory_ibfk_1` FOREIGN KEY (`campaignId`) REFERENCES `campaign` (`campaignId`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layouthistory`
--

LOCK TABLES `layouthistory` WRITE;
/*!40000 ALTER TABLE `layouthistory` DISABLE KEYS */;
INSERT INTO `layouthistory` VALUES (3,3,3,'2020-03-25 13:32:57'),(4,4,4,'2020-03-25 13:32:59'),(5,5,5,'2020-03-25 13:33:00'),(6,6,6,'2020-03-25 13:33:02'),(7,7,7,'2020-03-25 13:33:16'),(8,5,10,'2020-03-25 14:38:42'),(10,9,11,'2020-03-25 15:58:16'),(11,10,12,'2020-03-25 16:01:49'),(12,10,13,'2020-03-25 16:28:30'),(13,10,14,'2020-03-25 16:31:21'),(14,11,15,'2020-03-25 16:35:05'),(15,11,16,'2020-03-25 16:37:23'),(17,13,19,'2020-03-25 17:13:42'),(18,13,20,'2020-03-25 17:42:22'),(19,13,21,'2020-03-25 17:46:26'),(20,13,22,'2020-03-25 17:53:49'),(21,14,23,'2020-03-29 18:35:06'),(22,14,24,'2020-03-29 18:35:53'),(23,15,26,'2020-03-31 18:33:45'),(24,15,27,'2020-03-31 18:39:25'),(25,15,28,'2020-04-01 14:34:48');
/*!40000 ALTER TABLE `layouthistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkcampaignlayout`
--

DROP TABLE IF EXISTS `lkcampaignlayout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkcampaignlayout` (
  `lkCampaignLayoutId` int(11) NOT NULL AUTO_INCREMENT,
  `campaignId` int(11) NOT NULL,
  `layoutId` int(11) NOT NULL,
  `displayOrder` int(11) NOT NULL,
  PRIMARY KEY (`lkCampaignLayoutId`),
  UNIQUE KEY `campaignId` (`campaignId`,`layoutId`,`displayOrder`),
  KEY `layoutId` (`layoutId`),
  CONSTRAINT `lkcampaignlayout_ibfk_1` FOREIGN KEY (`campaignId`) REFERENCES `campaign` (`campaignId`),
  CONSTRAINT `lkcampaignlayout_ibfk_2` FOREIGN KEY (`layoutId`) REFERENCES `layout` (`layoutId`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkcampaignlayout`
--

LOCK TABLES `lkcampaignlayout` WRITE;
/*!40000 ALTER TABLE `lkcampaignlayout` DISABLE KEYS */;
INSERT INTO `lkcampaignlayout` VALUES (3,3,3,1),(4,4,4,1),(13,5,10,2),(6,6,6,1),(8,7,7,1),(9,7,8,2),(55,8,14,1),(16,9,11,1),(20,10,14,1),(25,11,16,2),(57,13,22,2),(56,13,30,1),(46,14,24,2),(45,14,25,1),(52,15,28,1);
/*!40000 ALTER TABLE `lkcampaignlayout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkcommanddisplayprofile`
--

DROP TABLE IF EXISTS `lkcommanddisplayprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkcommanddisplayprofile` (
  `commandId` int(11) NOT NULL,
  `displayProfileId` int(11) NOT NULL,
  `commandString` varchar(1000) NOT NULL,
  `validationString` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`commandId`,`displayProfileId`),
  KEY `displayProfileId` (`displayProfileId`),
  CONSTRAINT `lkcommanddisplayprofile_ibfk_1` FOREIGN KEY (`commandId`) REFERENCES `command` (`commandId`),
  CONSTRAINT `lkcommanddisplayprofile_ibfk_2` FOREIGN KEY (`displayProfileId`) REFERENCES `displayprofile` (`displayProfileId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkcommanddisplayprofile`
--

LOCK TABLES `lkcommanddisplayprofile` WRITE;
/*!40000 ALTER TABLE `lkcommanddisplayprofile` DISABLE KEYS */;
/*!40000 ALTER TABLE `lkcommanddisplayprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkdgdg`
--

DROP TABLE IF EXISTS `lkdgdg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkdgdg` (
  `parentId` int(11) NOT NULL,
  `childId` int(11) NOT NULL,
  `depth` int(11) NOT NULL,
  KEY `parentId` (`parentId`,`childId`,`depth`),
  KEY `childId` (`childId`,`parentId`,`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkdgdg`
--

LOCK TABLES `lkdgdg` WRITE;
/*!40000 ALTER TABLE `lkdgdg` DISABLE KEYS */;
INSERT INTO `lkdgdg` VALUES (1,1,0),(2,2,0),(3,3,0),(4,4,0),(6,6,0),(8,8,0);
/*!40000 ALTER TABLE `lkdgdg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkdisplaydg`
--

DROP TABLE IF EXISTS `lkdisplaydg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkdisplaydg` (
  `LkDisplayDGID` int(11) NOT NULL AUTO_INCREMENT,
  `displayGroupId` int(11) NOT NULL,
  `displayId` int(11) NOT NULL,
  PRIMARY KEY (`LkDisplayDGID`),
  UNIQUE KEY `displayGroupId` (`displayGroupId`,`displayId`),
  KEY `displayId` (`displayId`),
  CONSTRAINT `lkdisplaydg_ibfk_1` FOREIGN KEY (`displayGroupId`) REFERENCES `displaygroup` (`displayGroupId`),
  CONSTRAINT `lkdisplaydg_ibfk_2` FOREIGN KEY (`displayId`) REFERENCES `display` (`displayId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkdisplaydg`
--

LOCK TABLES `lkdisplaydg` WRITE;
/*!40000 ALTER TABLE `lkdisplaydg` DISABLE KEYS */;
INSERT INTO `lkdisplaydg` VALUES (1,1,1),(2,2,2),(3,3,1),(4,3,2),(8,3,3),(15,3,5),(5,4,3),(10,6,5),(21,8,7);
/*!40000 ALTER TABLE `lkdisplaydg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lklayoutdisplaygroup`
--

DROP TABLE IF EXISTS `lklayoutdisplaygroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lklayoutdisplaygroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `displayGroupId` int(11) NOT NULL,
  `layoutId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `displayGroupId` (`displayGroupId`,`layoutId`),
  KEY `layoutId` (`layoutId`),
  CONSTRAINT `lklayoutdisplaygroup_ibfk_1` FOREIGN KEY (`displayGroupId`) REFERENCES `displaygroup` (`displayGroupId`),
  CONSTRAINT `lklayoutdisplaygroup_ibfk_2` FOREIGN KEY (`layoutId`) REFERENCES `layout` (`layoutId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lklayoutdisplaygroup`
--

LOCK TABLES `lklayoutdisplaygroup` WRITE;
/*!40000 ALTER TABLE `lklayoutdisplaygroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `lklayoutdisplaygroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkmediadisplaygroup`
--

DROP TABLE IF EXISTS `lkmediadisplaygroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkmediadisplaygroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `displayGroupId` int(11) NOT NULL,
  `mediaId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `displayGroupId` (`displayGroupId`,`mediaId`),
  KEY `mediaId` (`mediaId`),
  CONSTRAINT `lkmediadisplaygroup_ibfk_1` FOREIGN KEY (`displayGroupId`) REFERENCES `displaygroup` (`displayGroupId`),
  CONSTRAINT `lkmediadisplaygroup_ibfk_2` FOREIGN KEY (`mediaId`) REFERENCES `media` (`mediaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkmediadisplaygroup`
--

LOCK TABLES `lkmediadisplaygroup` WRITE;
/*!40000 ALTER TABLE `lkmediadisplaygroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `lkmediadisplaygroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lknotificationdg`
--

DROP TABLE IF EXISTS `lknotificationdg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lknotificationdg` (
  `lkNotificationDgId` int(11) NOT NULL AUTO_INCREMENT,
  `notificationId` int(11) NOT NULL,
  `displayGroupId` int(11) NOT NULL,
  PRIMARY KEY (`lkNotificationDgId`),
  UNIQUE KEY `notificationId` (`notificationId`,`displayGroupId`),
  CONSTRAINT `lknotificationdg_ibfk_1` FOREIGN KEY (`notificationId`) REFERENCES `notification` (`notificationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lknotificationdg`
--

LOCK TABLES `lknotificationdg` WRITE;
/*!40000 ALTER TABLE `lknotificationdg` DISABLE KEYS */;
/*!40000 ALTER TABLE `lknotificationdg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lknotificationgroup`
--

DROP TABLE IF EXISTS `lknotificationgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lknotificationgroup` (
  `lkNotificationGroupId` int(11) NOT NULL AUTO_INCREMENT,
  `notificationId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  PRIMARY KEY (`lkNotificationGroupId`),
  UNIQUE KEY `notificationId` (`notificationId`,`groupId`),
  KEY `groupId` (`groupId`),
  CONSTRAINT `lknotificationgroup_ibfk_1` FOREIGN KEY (`notificationId`) REFERENCES `notification` (`notificationId`),
  CONSTRAINT `lknotificationgroup_ibfk_2` FOREIGN KEY (`groupId`) REFERENCES `group` (`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lknotificationgroup`
--

LOCK TABLES `lknotificationgroup` WRITE;
/*!40000 ALTER TABLE `lknotificationgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `lknotificationgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lknotificationuser`
--

DROP TABLE IF EXISTS `lknotificationuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lknotificationuser` (
  `lkNotificationUserId` int(11) NOT NULL AUTO_INCREMENT,
  `notificationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `read` tinyint(4) NOT NULL,
  `readDt` int(11) NOT NULL,
  `emailDt` int(11) NOT NULL,
  PRIMARY KEY (`lkNotificationUserId`),
  UNIQUE KEY `notificationId` (`notificationId`,`userId`),
  KEY `userId` (`userId`),
  CONSTRAINT `lknotificationuser_ibfk_1` FOREIGN KEY (`notificationId`) REFERENCES `notification` (`notificationId`),
  CONSTRAINT `lknotificationuser_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lknotificationuser`
--

LOCK TABLES `lknotificationuser` WRITE;
/*!40000 ALTER TABLE `lknotificationuser` DISABLE KEYS */;
/*!40000 ALTER TABLE `lknotificationuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkplaylistplaylist`
--

DROP TABLE IF EXISTS `lkplaylistplaylist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkplaylistplaylist` (
  `parentId` int(11) NOT NULL,
  `childId` int(11) NOT NULL,
  `depth` int(11) NOT NULL,
  PRIMARY KEY (`parentId`,`childId`,`depth`),
  UNIQUE KEY `childId` (`childId`,`parentId`,`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkplaylistplaylist`
--

LOCK TABLES `lkplaylistplaylist` WRITE;
/*!40000 ALTER TABLE `lkplaylistplaylist` DISABLE KEYS */;
INSERT INTO `lkplaylistplaylist` VALUES (7,7,0),(8,8,0),(9,9,0),(10,10,0),(11,11,0),(12,12,0),(14,14,0),(15,15,0),(16,16,0),(17,17,0),(18,18,0),(19,19,0),(24,24,0),(25,25,0),(26,26,0),(27,27,0),(28,28,0),(37,37,0),(38,38,0),(39,39,0),(40,40,0),(45,45,0),(62,62,0),(63,63,0),(64,64,0),(65,65,0),(66,66,0),(68,68,0),(70,70,0),(73,73,0),(74,74,0),(75,75,0),(76,76,0),(77,77,0),(78,78,0);
/*!40000 ALTER TABLE `lkplaylistplaylist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkscheduledisplaygroup`
--

DROP TABLE IF EXISTS `lkscheduledisplaygroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkscheduledisplaygroup` (
  `eventId` int(11) NOT NULL,
  `displayGroupId` int(11) NOT NULL,
  PRIMARY KEY (`eventId`,`displayGroupId`),
  KEY `displayGroupId` (`displayGroupId`),
  CONSTRAINT `lkscheduledisplaygroup_ibfk_1` FOREIGN KEY (`eventId`) REFERENCES `schedule` (`eventId`),
  CONSTRAINT `lkscheduledisplaygroup_ibfk_2` FOREIGN KEY (`displayGroupId`) REFERENCES `displaygroup` (`displayGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkscheduledisplaygroup`
--

LOCK TABLES `lkscheduledisplaygroup` WRITE;
/*!40000 ALTER TABLE `lkscheduledisplaygroup` DISABLE KEYS */;
INSERT INTO `lkscheduledisplaygroup` VALUES (1,3),(3,3);
/*!40000 ALTER TABLE `lkscheduledisplaygroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lktagcampaign`
--

DROP TABLE IF EXISTS `lktagcampaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lktagcampaign` (
  `lkTagCampaignId` int(11) NOT NULL AUTO_INCREMENT,
  `tagId` int(11) NOT NULL,
  `campaignId` int(11) NOT NULL,
  `value` text,
  PRIMARY KEY (`lkTagCampaignId`),
  UNIQUE KEY `tagId` (`tagId`,`campaignId`),
  KEY `campaignId` (`campaignId`),
  CONSTRAINT `lktagcampaign_ibfk_1` FOREIGN KEY (`tagId`) REFERENCES `tag` (`tagId`),
  CONSTRAINT `lktagcampaign_ibfk_2` FOREIGN KEY (`campaignId`) REFERENCES `campaign` (`campaignId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lktagcampaign`
--

LOCK TABLES `lktagcampaign` WRITE;
/*!40000 ALTER TABLE `lktagcampaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `lktagcampaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lktagdisplaygroup`
--

DROP TABLE IF EXISTS `lktagdisplaygroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lktagdisplaygroup` (
  `lkTagDisplayGroupId` int(11) NOT NULL AUTO_INCREMENT,
  `tagId` int(11) NOT NULL,
  `displayGroupId` int(11) NOT NULL,
  `value` text,
  PRIMARY KEY (`lkTagDisplayGroupId`),
  UNIQUE KEY `tagId` (`tagId`,`displayGroupId`),
  KEY `displayGroupId` (`displayGroupId`),
  CONSTRAINT `lktagdisplaygroup_ibfk_1` FOREIGN KEY (`tagId`) REFERENCES `tag` (`tagId`),
  CONSTRAINT `lktagdisplaygroup_ibfk_2` FOREIGN KEY (`displayGroupId`) REFERENCES `displaygroup` (`displayGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lktagdisplaygroup`
--

LOCK TABLES `lktagdisplaygroup` WRITE;
/*!40000 ALTER TABLE `lktagdisplaygroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `lktagdisplaygroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lktaglayout`
--

DROP TABLE IF EXISTS `lktaglayout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lktaglayout` (
  `lkTagLayoutId` int(11) NOT NULL AUTO_INCREMENT,
  `tagId` int(11) NOT NULL,
  `layoutId` int(11) NOT NULL,
  `value` text,
  PRIMARY KEY (`lkTagLayoutId`),
  UNIQUE KEY `tagId` (`tagId`,`layoutId`),
  KEY `layoutId` (`layoutId`),
  CONSTRAINT `lktaglayout_ibfk_1` FOREIGN KEY (`tagId`) REFERENCES `tag` (`tagId`),
  CONSTRAINT `lktaglayout_ibfk_2` FOREIGN KEY (`layoutId`) REFERENCES `layout` (`layoutId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lktaglayout`
--

LOCK TABLES `lktaglayout` WRITE;
/*!40000 ALTER TABLE `lktaglayout` DISABLE KEYS */;
INSERT INTO `lktaglayout` VALUES (4,5,3,NULL),(5,5,4,NULL),(6,5,10,NULL),(7,5,6,NULL),(8,5,7,NULL),(9,1,11,NULL),(10,6,22,NULL),(11,7,22,NULL);
/*!40000 ALTER TABLE `lktaglayout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lktagmedia`
--

DROP TABLE IF EXISTS `lktagmedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lktagmedia` (
  `lkTagMediaId` int(11) NOT NULL AUTO_INCREMENT,
  `tagId` int(11) NOT NULL,
  `mediaId` int(11) NOT NULL,
  `value` text,
  PRIMARY KEY (`lkTagMediaId`),
  UNIQUE KEY `tagId` (`tagId`,`mediaId`),
  KEY `mediaId` (`mediaId`),
  CONSTRAINT `lktagmedia_ibfk_1` FOREIGN KEY (`tagId`) REFERENCES `tag` (`tagId`),
  CONSTRAINT `lktagmedia_ibfk_2` FOREIGN KEY (`mediaId`) REFERENCES `media` (`mediaId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lktagmedia`
--

LOCK TABLES `lktagmedia` WRITE;
/*!40000 ALTER TABLE `lktagmedia` DISABLE KEYS */;
INSERT INTO `lktagmedia` VALUES (1,5,21,NULL),(2,5,22,NULL),(3,5,23,NULL),(5,5,25,NULL),(6,5,26,NULL),(7,5,27,NULL),(8,5,28,NULL),(12,9,63,NULL),(13,6,63,NULL),(14,8,63,NULL);
/*!40000 ALTER TABLE `lktagmedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lktagplaylist`
--

DROP TABLE IF EXISTS `lktagplaylist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lktagplaylist` (
  `lkTagPlaylistId` int(11) NOT NULL AUTO_INCREMENT,
  `tagId` int(11) NOT NULL,
  `playlistId` int(11) NOT NULL,
  `value` text,
  PRIMARY KEY (`lkTagPlaylistId`),
  UNIQUE KEY `tagId` (`tagId`,`playlistId`),
  KEY `lktagplaylist_ibfk_2` (`playlistId`),
  CONSTRAINT `lktagplaylist_ibfk_1` FOREIGN KEY (`tagId`) REFERENCES `tag` (`tagId`),
  CONSTRAINT `lktagplaylist_ibfk_2` FOREIGN KEY (`playlistId`) REFERENCES `playlist` (`playlistId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lktagplaylist`
--

LOCK TABLES `lktagplaylist` WRITE;
/*!40000 ALTER TABLE `lktagplaylist` DISABLE KEYS */;
/*!40000 ALTER TABLE `lktagplaylist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkusergroup`
--

DROP TABLE IF EXISTS `lkusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkusergroup` (
  `lkUserGroupID` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`lkUserGroupID`),
  UNIQUE KEY `groupId` (`groupId`,`userId`),
  KEY `userId` (`userId`),
  CONSTRAINT `lkusergroup_ibfk_1` FOREIGN KEY (`groupId`) REFERENCES `group` (`groupId`),
  CONSTRAINT `lkusergroup_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkusergroup`
--

LOCK TABLES `lkusergroup` WRITE;
/*!40000 ALTER TABLE `lkusergroup` DISABLE KEYS */;
INSERT INTO `lkusergroup` VALUES (1,3,1);
/*!40000 ALTER TABLE `lkusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkwidgetaudio`
--

DROP TABLE IF EXISTS `lkwidgetaudio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkwidgetaudio` (
  `widgetId` int(11) NOT NULL,
  `mediaId` int(11) NOT NULL,
  `volume` tinyint(4) NOT NULL,
  `loop` tinyint(4) NOT NULL,
  PRIMARY KEY (`widgetId`,`mediaId`),
  KEY `mediaId` (`mediaId`),
  CONSTRAINT `lkwidgetaudio_ibfk_1` FOREIGN KEY (`widgetId`) REFERENCES `widget` (`widgetId`),
  CONSTRAINT `lkwidgetaudio_ibfk_2` FOREIGN KEY (`mediaId`) REFERENCES `media` (`mediaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkwidgetaudio`
--

LOCK TABLES `lkwidgetaudio` WRITE;
/*!40000 ALTER TABLE `lkwidgetaudio` DISABLE KEYS */;
/*!40000 ALTER TABLE `lkwidgetaudio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lkwidgetmedia`
--

DROP TABLE IF EXISTS `lkwidgetmedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lkwidgetmedia` (
  `widgetId` int(11) NOT NULL,
  `mediaId` int(11) NOT NULL,
  PRIMARY KEY (`widgetId`,`mediaId`),
  KEY `mediaId` (`mediaId`),
  CONSTRAINT `lkwidgetmedia_ibfk_1` FOREIGN KEY (`widgetId`) REFERENCES `widget` (`widgetId`),
  CONSTRAINT `lkwidgetmedia_ibfk_2` FOREIGN KEY (`mediaId`) REFERENCES `media` (`mediaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lkwidgetmedia`
--

LOCK TABLES `lkwidgetmedia` WRITE;
/*!40000 ALTER TABLE `lkwidgetmedia` DISABLE KEYS */;
INSERT INTO `lkwidgetmedia` VALUES (24,21),(11,22),(15,22),(26,22),(39,22),(12,23),(16,23),(27,23),(40,23),(7,25),(9,26),(13,27),(17,28),(18,28),(23,53),(61,63),(68,63);
/*!40000 ALTER TABLE `lkwidgetmedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `logId` int(11) NOT NULL AUTO_INCREMENT,
  `runNo` varchar(10) NOT NULL,
  `logDate` datetime NOT NULL,
  `channel` varchar(20) NOT NULL,
  `type` varchar(254) NOT NULL,
  `page` varchar(50) NOT NULL,
  `function` varchar(50) DEFAULT NULL,
  `message` longtext NOT NULL,
  `userId` int(11) NOT NULL DEFAULT '0',
  `displayId` int(11) DEFAULT NULL,
  PRIMARY KEY (`logId`),
  KEY `logDate` (`logDate`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
INSERT INTO `log` VALUES (1,'0aa2c7a','2020-06-15 20:33:13','PLAYER','ERROR','[5850] ','POST','[CollectionInterval] [CMS] Display is Registered and awaiting Authorisation from an Administrator in the CMS',0,5),(2,'9a2303b','2020-06-15 20:03:48','PLAYER','ERROR','[LibraryAgent] LibraryAgent - Run','POST','Exception in Run: Le fichier \'C:\\Users\\thoma\\OneDrive\\Documents\\Xibo Library\\requiredFiles.xml\' est introuvable.',0,4),(3,'9a2303b','2020-06-15 20:03:52','PLAYER','ERROR','[RegisterAgentThread] RegisterAgent - Run','POST','Error swapping to HTTPS. E = Impossible de se connecter au serveur distant',0,4),(4,'2aa51d9','2020-06-16 10:55:15','PLAYER','ERROR','[RegisterAgentThread] RegisterAgent - Run','POST','Error swapping to HTTPS. E = Impossible de se connecter au serveur distant',0,4),(5,'8569ca0','2020-06-16 10:56:03','PLAYER','ERROR','[Watcher] Watchdog','POST','Too many active processes',0,4),(6,'b0c26ef','2020-06-16 10:55:41','PLAYER','ERROR','[RegisterAgentThread] RegisterAgent - Run','POST','Error swapping to HTTPS. E = Impossible de se connecter au serveur distant',0,4),(7,'81f720e','2020-06-16 10:57:05','PLAYER','ERROR','[Watcher] Watchdog','POST','Too many active processes',0,4),(8,'6e599ed','2020-06-16 10:56:45','PLAYER','ERROR','[40644] ','POST','[WebServer] Read Error: Connection reset by peer',0,5),(9,'6e599ed','2020-06-16 10:58:16','PLAYER','ERROR','[40645] ','POST','[WebServer] Read Error: Connection reset by peer',0,5),(10,'29b0c8e','2020-06-16 11:24:52','PLAYER','ERROR','[40645] ','POST','[WebServer] Read Error: Connection reset by peer',0,5),(11,'2a06829','2020-06-16 12:05:03','PLAYER','ERROR','[40645] ','POST','[WebServer] Write Error: Connection reset by peer',0,5),(12,'307b1be','2020-06-15 20:03:48','PLAYER','ERROR','[LibraryAgent] LibraryAgent - Run','POST','Exception in Run: Le fichier \'C:\\Users\\thoma\\OneDrive\\Documents\\Xibo Library\\requiredFiles.xml\' est introuvable.',0,4),(13,'307b1be','2020-06-15 20:03:52','PLAYER','ERROR','[RegisterAgentThread] RegisterAgent - Run','POST','Error swapping to HTTPS. E = Impossible de se connecter au serveur distant',0,4);
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `mediaId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(15) NOT NULL,
  `duration` int(11) NOT NULL,
  `originalFileName` varchar(254) DEFAULT NULL,
  `storedAs` varchar(254) DEFAULT NULL,
  `md5` varchar(32) DEFAULT NULL,
  `fileSize` bigint(20) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  `retired` tinyint(4) NOT NULL DEFAULT '0',
  `isEdited` tinyint(4) NOT NULL DEFAULT '0',
  `editedMediaId` int(11) DEFAULT NULL,
  `moduleSystemFile` tinyint(4) NOT NULL DEFAULT '0',
  `valid` tinyint(4) NOT NULL DEFAULT '1',
  `expires` int(11) DEFAULT NULL,
  `released` tinyint(4) NOT NULL DEFAULT '1',
  `apiRef` varchar(254) DEFAULT NULL,
  `createdDt` datetime NOT NULL,
  `modifiedDt` datetime NOT NULL,
  `enableStat` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`mediaId`),
  KEY `userId` (`userId`),
  KEY `editedMediaId` (`editedMediaId`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'jquery-1.11.1.min.js','module',0,'jquery-1.11.1.min.js','jquery-1.11.1.min.js','3c9137d88a00b1ae0b41ff6a70571615',95785,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(2,'moment.js','module',0,'moment.js','moment.js','67bb26c11dba6c366834e65f5933aff2',160251,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(3,'xibo-layout-scaler.js','module',0,'xibo-layout-scaler.js','xibo-layout-scaler.js','5752497a5715d4aceeba4896fea99c62',3694,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(4,'xibo-text-render.js','module',0,'xibo-text-render.js','xibo-text-render.js','8d72e0c1775cba38c44bf02aee0c8d83',12150,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(5,'Chart.min.js','module',0,'Chart.min.js','Chart.min.js','f6c8efa65711e0cbbc99ba72997ecd0e',159638,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(6,'jquery-cycle-2.1.6.min.js','module',0,'jquery-cycle-2.1.6.min.js','jquery-cycle-2.1.6.min.js','212480cf1292db459557814e2d7a571d',28876,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(7,'flipclock.min.js','module',0,'flipclock.min.js','flipclock.min.js','b9d7742384bdf912c51b6a1b5d674f7a',21107,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(8,'xibo-countdown-render.js','module',0,'xibo-countdown-render.js','xibo-countdown-render.js','db15414501ff0a084b61fc1273e73e2f',6744,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(9,'jquery.marquee.min.js','module',0,'jquery.marquee.min.js','jquery.marquee.min.js','2286bb4f44d9ea301131a25c5204ca0a',2248,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(10,'xibo-image-render.js','module',0,'xibo-image-render.js','xibo-image-render.js','6152d3e99b2c61bb3db365d108337483',2988,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(11,'xibo-dataset-render.js','module',0,'xibo-dataset-render.js','xibo-dataset-render.js','e04ad2bff2a293cc7c7e162a9ef1a4c8',1687,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:01','2020-06-23 02:00:01',NULL),(12,'Aileron Heavy Regular','font',0,'Aileron-Heavy.otf','12.otf','621ba5aaf66e52f3def0cf69807104b9',30060,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:14:01','2020-03-25 13:14:01',NULL),(13,'Aileron Regular','font',0,'Aileron-Regular.otf','13.otf','d321fa78bb7190a8ca7e14213ef63203',27644,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:14:01','2020-03-25 13:14:01',NULL),(14,'Dancing Script Regular','font',0,'DancingScript-Regular.ttf','14.ttf','86aadd0451f9e7dafa957e1e61dd2ed7',116580,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:14:02','2020-03-25 13:14:02',NULL),(15,'Railway Regular','font',0,'Railway.ttf','15.ttf','58963d3a57da7a70ac36d331416746c5',45884,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:14:02','2020-03-25 13:14:02',NULL),(16,'Linear Regular','font',0,'linear-by-braydon-fuller.otf','16.otf','afb33470c582079834acd8b9f979ce1a',19684,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:14:02','2020-03-25 13:14:02',NULL),(17,'pdf.js','module',0,'pdf.js','pdf.js','dec9b89b936438760291e401c09f52aa',333388,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:02','2020-06-23 02:00:01',NULL),(18,'pdf.worker.js','module',0,'pdf.worker.js','pdf.worker.js','926affd0ae3d3b69e6071b26875638c8',1337459,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:02','2020-06-23 02:00:01',NULL),(19,'compatibility.js','module',0,'compatibility.js','compatibility.js','758c582a7fd2f30ec9dd8f91803a9882',18126,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:02','2020-06-23 02:00:01',NULL),(20,'xibo-webpage-render.js','module',0,'xibo-webpage-render.js','xibo-webpage-render.js','d59f5fc84ef7747f27baddc07fe81487',4832,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:14:02','2020-06-23 02:00:01',NULL),(21,'inser_image','image',10,'Insérer image.jpg','21.jpg','e5dba15343f04da5355016808f89dbad',58773,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:32:46','2020-03-25 13:32:46','Inherit'),(22,'logo_polytech_nancy_blanc','image',10,'Polytech_Nancy_blanc_HD.png','22.png','4570539299fdf985a3eaf67fc9608a46',12691,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:32:46','2020-03-25 13:32:46','Inherit'),(23,'logo_UL_INP_blanc','image',10,'Logotype-LorraineINP_UL-Baseline-Blanc.png','23.png','bf133b2f33f24b6f702eef437894f111',9699,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:32:46','2020-03-25 13:32:46','Inherit'),(25,'porte','image',10,'Affiche porte.jpg','25.jpg','77440668c2017f2613c546a30edb2838',292197,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:32:57','2020-03-25 13:32:57','Inherit'),(26,'bannière','image',10,'Bannière rentrée facebook actualisée.jpg','26.jpg','a0778ba5a80cf00bc9c27c001537d2a7',309645,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:32:59','2020-03-25 13:32:59','Inherit'),(27,'inser_video','video',7,'Insérer vidéo.mp4','27.mp4','c11923362d6a0f1e9facfbb3a481037d',1956455,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:33:02','2020-03-25 13:33:02','Inherit'),(28,'bienvenue_à_polytech','video',33,'Bienvenue.mp4','28.mp4','647336d2fff748c37b93cb5ab7302334',13907207,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 13:33:16','2020-03-25 13:33:16','Inherit'),(29,'bootstrap.min.css','module',0,'bootstrap.min.css','bootstrap.min.css','ec3bb52a00e176a7181d454dffaea219',121200,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(30,'WeatherIcons-Regular.otf','module',0,'WeatherIcons-Regular.otf','WeatherIcons-Regular.otf','145ba08b1886ec06ed80385eb768a050',40668,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(31,'animate.css','module',0,'animate.css','animate.css','07f146141537e04ee282a965d8053198',72259,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(32,'font-awesome.min.css','module',0,'font-awesome.min.css','font-awesome.min.css','04425bbdc6243fc6e54bf8984fe50330',23739,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(33,'weather-icons.min.css','module',0,'weather-icons.min.css','weather-icons.min.css','96dff559d6119c163e149280ef1db88c',26633,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(34,'weathericons-regular-webfont.eot','module',0,'weathericons-regular-webfont.eot','weathericons-regular-webfont.eot','8c0f6fd19bfa5763a0860b5930a66e14',35151,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(35,'weathericons-regular-webfont.svg','module',0,'weathericons-regular-webfont.svg','weathericons-regular-webfont.svg','fe45297f78b1ab6d8ed9b623d2634530',127706,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(36,'weathericons-regular-webfont.ttf','module',0,'weathericons-regular-webfont.ttf','weathericons-regular-webfont.ttf','cd287dcbb4564b57692cfed0e2e58345',67016,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(37,'weathericons-regular-webfont.woff','module',0,'weathericons-regular-webfont.woff','weathericons-regular-webfont.woff','c90a4c420dd010a5e95dedb8927a29e7',40408,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(38,'weathericons-regular-webfont.woff2','module',0,'weathericons-regular-webfont.woff2','weathericons-regular-webfont.woff2','1cd48d78f06d33973d9d761d426e69bf',44720,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(39,'wi-cloudy.jpg','module',0,'wi-cloudy.jpg','wi-cloudy.jpg','1766972e4d03a6c1056b503c41e94430',379804,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(40,'wi-day-cloudy.jpg','module',0,'wi-day-cloudy.jpg','wi-day-cloudy.jpg','49b09eb3738e0a16b488297f2b6ede24',2628732,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:35','2020-06-23 02:00:01',NULL),(41,'wi-day-sunny.jpg','module',0,'wi-day-sunny.jpg','wi-day-sunny.jpg','503ca21fd5014ddefc2cd5159766af32',1445897,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(42,'wi-fog.jpg','module',0,'wi-fog.jpg','wi-fog.jpg','4168dc58a5eb3aa3826d8eae85088804',597609,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(43,'wi-hail.jpg','module',0,'wi-hail.jpg','wi-hail.jpg','8c4e4024b6242eecdb754344fcfa8b6c',827270,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(44,'wi-night-clear.jpg','module',0,'wi-night-clear.jpg','wi-night-clear.jpg','ebdb8828051637c91109a329b2138f10',738913,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(45,'wi-night-partly-cloudy.jpg','module',0,'wi-night-partly-cloudy.jpg','wi-night-partly-cloudy.jpg','d50d13f4bedad3dedd108d4baad60494',220168,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(46,'wi-rain.jpg','module',0,'wi-rain.jpg','wi-rain.jpg','637dfc650fff4976910ea46917734925',655983,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(47,'wi-snow.jpg','module',0,'wi-snow.jpg','wi-snow.jpg','6e3def73254a72ff0b4ff45c7bba7501',782263,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(48,'wi-windy.jpg','module',0,'wi-windy.jpg','wi-windy.jpg','a4951eb27a8aa834469621674d193f30',339716,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:51:36','2020-06-23 02:00:01',NULL),(49,'emojione.sprites.png','module',0,'emojione.sprites.png','emojione.sprites.png','9e6c0ddc2660e6f57cc8a8bcc8acfa7f',2391178,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:55:43','2020-06-23 02:00:01',NULL),(50,'emojione.sprites.css','module',0,'emojione.sprites.css','emojione.sprites.css','a9276fcb2bb556fded32004461f6cd5e',81309,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:55:43','2020-06-23 02:00:01',NULL),(51,'twitter_blue.png','module',0,'twitter_blue.png','twitter_blue.png','9deb206a69301ce2f0188a876a703877',16463,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:55:43','2020-06-23 02:00:01',NULL),(52,'twitter_white.png','module',0,'twitter_white.png','twitter_white.png','fb60908160eb0453bc443da6b6acb78d',15975,1,0,0,0,1,1,0,1,NULL,'2020-03-25 13:55:43','2020-06-23 02:00:01',NULL),(53,'twitter_442096741','module',0,'fvdo3bhb_bigger.jpg','twitter_442096741','b3c9791ec841a6fa410fa2847c184631',2973,1,0,0,0,0,1,1585239271,1,NULL,'2020-03-25 14:01:17','2020-03-25 16:14:31',NULL),(63,'logo 60 ans','image',10,'Logo 60 ans HD.png','63.png','18f90955cf87551dcbc1e2b62e562fb3',1572679,1,0,0,NULL,0,1,0,1,NULL,'2020-03-25 17:32:25','2020-03-25 17:35:03','Inherit');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module` (
  `moduleId` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '0',
  `regionSpecific` tinyint(4) NOT NULL DEFAULT '1',
  `description` varchar(254) DEFAULT NULL,
  `schemaVersion` int(11) NOT NULL DEFAULT '1',
  `validExtensions` varchar(254) DEFAULT NULL,
  `previewEnabled` tinyint(4) NOT NULL DEFAULT '1',
  `assignable` tinyint(4) NOT NULL DEFAULT '1',
  `render_as` varchar(10) DEFAULT NULL,
  `settings` text,
  `viewPath` varchar(254) NOT NULL DEFAULT '../modules',
  `class` varchar(254) NOT NULL,
  `defaultDuration` int(11) NOT NULL,
  `installName` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`moduleId`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module`
--

LOCK TABLES `module` WRITE;
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
INSERT INTO `module` VALUES (1,'Image','Image',1,0,'Upload Image files to assign to Layouts',1,'jpg,jpeg,png,bmp,gif',1,1,NULL,NULL,'../modules','Xibo\\Widget\\Image',10,NULL),(2,'Video','Video',1,0,'Upload Video files to assign to Layouts',1,'wmv,avi,mpg,mpeg,webm,mp4,m4v',0,1,NULL,NULL,'../modules','Xibo\\Widget\\Video',0,NULL),(3,'Flash','Flash',1,0,'Upload SWF files to assign to Layouts',1,'swf',1,1,NULL,NULL,'../modules','Xibo\\Widget\\Flash',10,NULL),(4,'PowerPoint','PowerPoint',1,0,'Upload a PowerPoint file to assign to Layouts',1,'ppt,pps,pptx',1,1,NULL,NULL,'../modules','Xibo\\Widget\\PowerPoint',10,NULL),(5,'Webpage','Webpage',1,1,'Embed a Webpage',1,NULL,1,1,NULL,'[]','../modules','Xibo\\Widget\\WebPage',30,NULL),(6,'Ticker','Ticker',1,1,'Display dynamic feed content',1,NULL,1,1,NULL,'[]','../modules','Xibo\\Widget\\Ticker',5,NULL),(7,'Text','Text',1,1,'Add Text directly to a Layout',1,NULL,1,1,NULL,NULL,'../modules','Xibo\\Widget\\Text',5,NULL),(8,'Embedded','Embedded',1,1,'Embed HTML and JavaScript',1,NULL,1,1,NULL,NULL,'../modules','Xibo\\Widget\\Embedded',60,NULL),(11,'datasetview','DataSet View',1,1,'Organise and display DataSet data in a tabular format',1,NULL,1,1,NULL,NULL,'../modules','Xibo\\Widget\\DataSetView',60,NULL),(12,'shellcommand','Shell Command',1,1,'Instruct a Display to execute a command using the operating system shell',1,NULL,1,1,NULL,NULL,'../modules','Xibo\\Widget\\ShellCommand',3,NULL),(13,'localvideo','Local Video',1,1,'Display Video that only exists on the Display by providing a local file path or URL',1,NULL,0,1,NULL,NULL,'../modules','Xibo\\Widget\\LocalVideo',60,NULL),(14,'genericfile','Generic File',1,0,'A generic file to be stored in the library',1,',js,html,htm',0,0,NULL,NULL,'../modules','Xibo\\Widget\\GenericFile',10,NULL),(15,'clock','Clock',1,1,'Assign a type of Clock or a Countdown',1,NULL,1,1,'html','[]','../modules','Xibo\\Widget\\Clock',5,NULL),(16,'font','Font',1,0,'A font to use in other Modules',1,'ttf,otf,eot,svg,woff',0,0,NULL,NULL,'../modules','Xibo\\Widget\\Font',10,NULL),(17,'audio','Audio',1,0,'Upload Audio files to assign to Layouts',1,'mp3,wav',0,1,NULL,NULL,'../modules','Xibo\\Widget\\Audio',0,NULL),(18,'pdf','PDF',1,0,'Upload PDF files to assign to Layouts',1,'pdf',1,1,'html',NULL,'../modules','Xibo\\Widget\\Pdf',60,NULL),(19,'notificationview','Notification',1,1,'Display messages created in the Notification Drawer of the CMS',1,NULL,1,1,'html',NULL,'../modules','Xibo\\Widget\\NotificationView',10,NULL),(20,'subplaylist','Sub-Playlist',1,1,'Embed a Sub-Playlist',1,NULL,1,1,'native',NULL,'../modules','Xibo\\Widget\\SubPlaylist',10,NULL),(21,'datasetticker','DataSet Ticker',1,1,'Ticker with a DataSet providing the items',1,NULL,1,1,'html',NULL,'../modules','Xibo\\Widget\\DataSetTicker',10,NULL),(22,'playersoftware','Player Software',1,0,'A module for managing Player Versions',1,'apk,ipk,wgt',0,0,NULL,NULL,'../modules','Xibo\\Widget\\PlayerSoftware',10,NULL),(23,'htmlpackage','HTML Package',1,0,'Upload a complete package to distribute to Players',1,'htz',0,1,'native',NULL,'../modules','Xibo\\Widget\\HtmlPackage',60,NULL),(24,'videoin','Video In',1,1,'Display input from an external source',1,NULL,0,1,'native',NULL,'../modules','Xibo\\Widget\\VideoIn',60,NULL),(25,'hls','HLS',1,1,'Display live streamed content',1,NULL,1,1,'html',NULL,'../modules','Xibo\\Widget\\Hls',60,NULL),(26,'calendar','Calendar',1,1,'Display events from an iCAL feed',1,NULL,1,1,'html',NULL,'../modules','Xibo\\Widget\\Calendar',60,NULL),(27,'chart','Chart',1,1,'Display information held in a DataSet as a type of Chart',1,NULL,1,1,'html',NULL,'../modules','Xibo\\Widget\\Chart',240,NULL),(28,'savedreport','Saved Reports',1,0,'A saved report to be stored in the library',1,'json',0,0,NULL,NULL,'../modules','Xibo\\Widget\\SavedReport',10,'savedreport'),(29,'spacer','Spacer',1,1,'Make a Region empty for a specified duration',1,NULL,0,1,'html',NULL,'../modules','Xibo\\Widget\\Spacer',60,'spacer'),(30,'countdown','Countdown',1,1,'Countdown Module',1,NULL,1,1,'html',NULL,'../modules','Xibo\\Widget\\Countdown',60,'countdown'),(31,'googletraffic','Google Traffic',1,1,'Google Traffic Map',1,NULL,1,1,'html','{\"apiKey\":\"AIzaSyAtbKMU7tDFAp8-v7v9TD3FPyy64ibN5Ks\",\"minDuration\":null}','../modules','Xibo\\Widget\\GoogleTraffic',30,'googletraffic'),(32,'forecastio','Weather',1,1,'Weather Powered by DarkSky',1,NULL,1,1,'html','{\"apiKey\":\"668a50fcc40685bc0ee5fef392db7ba4\",\"cachePeriod\":300}','../modules','Xibo\\Widget\\ForecastIo',60,'forecastio'),(33,'twitter','Twitter',1,1,'Twitter Search Module',1,NULL,1,1,'html','{\"apiKey\":\"7hLvyGzocgvm0dLbfPyopbYV3\",\"apiSecret\":\"jGdPCSEzC7hwCOIs3U7k00CYI4oywtq80S99uqiTD184KQn889\",\"cachePeriod\":300,\"cachePeriodImages\":24}','../modules','Xibo\\Widget\\Twitter',60,'twitter');
/*!40000 ALTER TABLE `module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `notificationId` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `createDt` int(11) NOT NULL,
  `releaseDt` int(11) NOT NULL,
  `isEmail` tinyint(4) NOT NULL,
  `isInterrupt` tinyint(4) NOT NULL,
  `isSystem` tinyint(4) NOT NULL,
  `userId` int(11) NOT NULL,
  `filename` varchar(1000) DEFAULT NULL,
  `nonusers` varchar(1000) DEFAULT NULL,
  `originalFileName` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`notificationId`),
  KEY `userId` (`userId`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_token_scopes`
--

DROP TABLE IF EXISTS `oauth_access_token_scopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_token_scopes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access_token` varchar(254) NOT NULL,
  `scope` varchar(254) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `access_token` (`access_token`),
  KEY `scope` (`scope`),
  CONSTRAINT `oauth_access_token_scopes_ibfk_1` FOREIGN KEY (`access_token`) REFERENCES `oauth_access_tokens` (`access_token`) ON DELETE CASCADE,
  CONSTRAINT `oauth_access_token_scopes_ibfk_2` FOREIGN KEY (`scope`) REFERENCES `oauth_scopes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_token_scopes`
--

LOCK TABLES `oauth_access_token_scopes` WRITE;
/*!40000 ALTER TABLE `oauth_access_token_scopes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_token_scopes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `access_token` varchar(254) NOT NULL,
  `session_id` int(11) NOT NULL,
  `expire_time` int(11) NOT NULL,
  PRIMARY KEY (`access_token`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `oauth_access_tokens_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `oauth_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_code_scopes`
--

DROP TABLE IF EXISTS `oauth_auth_code_scopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_code_scopes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_code` varchar(254) NOT NULL,
  `scope` varchar(254) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_code` (`auth_code`),
  KEY `scope` (`scope`),
  CONSTRAINT `oauth_auth_code_scopes_ibfk_1` FOREIGN KEY (`auth_code`) REFERENCES `oauth_auth_codes` (`auth_code`) ON DELETE CASCADE,
  CONSTRAINT `oauth_auth_code_scopes_ibfk_2` FOREIGN KEY (`scope`) REFERENCES `oauth_scopes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_code_scopes`
--

LOCK TABLES `oauth_auth_code_scopes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_code_scopes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_code_scopes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `auth_code` varchar(254) NOT NULL,
  `session_id` int(11) NOT NULL,
  `expire_time` int(11) NOT NULL,
  `client_redirect_uri` varchar(500) NOT NULL,
  PRIMARY KEY (`auth_code`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `oauth_auth_codes_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `oauth_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_client_redirect_uris`
--

DROP TABLE IF EXISTS `oauth_client_redirect_uris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_client_redirect_uris` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(254) NOT NULL,
  `redirect_uri` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_client_redirect_uris`
--

LOCK TABLES `oauth_client_redirect_uris` WRITE;
/*!40000 ALTER TABLE `oauth_client_redirect_uris` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_client_redirect_uris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_client_scopes`
--

DROP TABLE IF EXISTS `oauth_client_scopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_client_scopes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientId` varchar(254) NOT NULL,
  `scopeId` varchar(254) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clientId` (`clientId`,`scopeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_client_scopes`
--

LOCK TABLES `oauth_client_scopes` WRITE;
/*!40000 ALTER TABLE `oauth_client_scopes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_client_scopes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` varchar(254) NOT NULL,
  `secret` varchar(254) NOT NULL,
  `name` varchar(254) NOT NULL,
  `userId` int(11) NOT NULL,
  `authCode` tinyint(4) NOT NULL,
  `clientCredentials` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `oauth_clients_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `refresh_token` varchar(254) NOT NULL,
  `expire_time` int(11) NOT NULL,
  `access_token` varchar(254) NOT NULL,
  PRIMARY KEY (`refresh_token`),
  KEY `access_token` (`access_token`),
  CONSTRAINT `oauth_refresh_tokens_ibfk_1` FOREIGN KEY (`access_token`) REFERENCES `oauth_access_tokens` (`access_token`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_scope_routes`
--

DROP TABLE IF EXISTS `oauth_scope_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_scope_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scopeId` varchar(254) NOT NULL,
  `route` varchar(1000) NOT NULL,
  `method` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_scope_routes`
--

LOCK TABLES `oauth_scope_routes` WRITE;
/*!40000 ALTER TABLE `oauth_scope_routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_scope_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_scopes`
--

DROP TABLE IF EXISTS `oauth_scopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_scopes` (
  `id` varchar(254) NOT NULL,
  `description` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_scopes`
--

LOCK TABLES `oauth_scopes` WRITE;
/*!40000 ALTER TABLE `oauth_scopes` DISABLE KEYS */;
INSERT INTO `oauth_scopes` VALUES ('all','All');
/*!40000 ALTER TABLE `oauth_scopes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_session_scopes`
--

DROP TABLE IF EXISTS `oauth_session_scopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_session_scopes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `scope` varchar(254) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  KEY `scope` (`scope`),
  CONSTRAINT `oauth_session_scopes_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `oauth_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `oauth_session_scopes_ibfk_2` FOREIGN KEY (`scope`) REFERENCES `oauth_scopes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_session_scopes`
--

LOCK TABLES `oauth_session_scopes` WRITE;
/*!40000 ALTER TABLE `oauth_session_scopes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_session_scopes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_sessions`
--

DROP TABLE IF EXISTS `oauth_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_type` varchar(254) NOT NULL,
  `owner_id` varchar(254) NOT NULL,
  `client_id` varchar(254) NOT NULL,
  `client_redirect_uri` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `oauth_sessions_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_sessions`
--

LOCK TABLES `oauth_sessions` WRITE;
/*!40000 ALTER TABLE `oauth_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `pageId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `asHome` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pageId`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'icondashboard','Icon Dashboard',1),(2,'schedule','Schedule',1),(3,'mediamanager','Media Dashboard',1),(4,'layout','Layout',1),(5,'library','Library',1),(6,'display','Displays',1),(7,'update','Update',0),(8,'admin','Administration',0),(9,'group','User Groups',1),(10,'log','Log',1),(11,'user','Users',1),(12,'license','Licence',1),(13,'index','Home',0),(14,'module','Modules',1),(15,'template','Templates',1),(16,'fault','Report Fault',1),(17,'stats','Statistics',1),(18,'manual','Manual',0),(19,'resolution','Resolutions',1),(20,'help','Help Links',1),(21,'clock','Clock',0),(22,'displaygroup','Display Groups',1),(23,'application','Applications',1),(24,'dataset','DataSets',1),(25,'campaign','Campaigns',1),(26,'transition','Transitions',1),(27,'sessions','Sessions',1),(28,'preview','Preview',0),(29,'statusdashboard','Status Dashboard',1),(30,'displayprofile','Display Profiles',1),(31,'audit','Audit Trail',0),(32,'region','Regions',0),(33,'playlist','Playlist',1),(34,'maintenance','Maintenance',0),(35,'command','Commands',1),(36,'notification','Notifications',0),(37,'drawer','Notification Drawer',0),(38,'daypart','Dayparting',0),(39,'task','Tasks',1),(40,'playersoftware','Player Software',0),(41,'schedulenow','Schedule Now',0),(42,'report','Report',0),(43,'playlistdashboard','Playlist Dashboard',1);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `permissionId` int(11) NOT NULL AUTO_INCREMENT,
  `entityId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `objectId` int(11) NOT NULL,
  `view` tinyint(4) NOT NULL,
  `edit` tinyint(4) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`permissionId`),
  KEY `permission_ibfk_1` (`groupId`),
  KEY `permission_ibfk_2` (`entityId`),
  KEY `permission_objectId_index` (`objectId`),
  CONSTRAINT `permission_ibfk_1` FOREIGN KEY (`groupId`) REFERENCES `group` (`groupId`),
  CONSTRAINT `permission_ibfk_2` FOREIGN KEY (`entityId`) REFERENCES `permissionentity` (`entityId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,1,1,1,1,0,0),(2,1,1,13,1,0,0),(3,1,1,4,1,0,0),(4,1,1,5,1,0,0),(5,1,1,3,1,0,0),(6,1,1,33,1,0,0),(7,1,1,28,1,0,0),(8,1,1,32,1,0,0),(9,1,1,2,1,0,0),(10,1,1,29,1,0,0),(11,1,1,11,1,0,0),(12,11,2,1,1,0,0),(13,11,2,2,1,0,0),(15,1,1,41,1,0,0),(16,1,3,41,1,0,0),(17,1,4,41,1,0,0),(18,1,5,43,1,0,0),(19,1,5,5,1,0,0),(20,1,5,11,1,0,0);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissionentity`
--

DROP TABLE IF EXISTS `permissionentity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissionentity` (
  `entityId` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(50) NOT NULL,
  PRIMARY KEY (`entityId`),
  UNIQUE KEY `entity` (`entity`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissionentity`
--

LOCK TABLES `permissionentity` WRITE;
/*!40000 ALTER TABLE `permissionentity` DISABLE KEYS */;
INSERT INTO `permissionentity` VALUES (4,'Xibo\\Entity\\Campaign'),(12,'Xibo\\Entity\\Command'),(9,'Xibo\\Entity\\DataSet'),(11,'Xibo\\Entity\\DayPart'),(2,'Xibo\\Entity\\DisplayGroup'),(3,'Xibo\\Entity\\Media'),(10,'Xibo\\Entity\\Notification'),(1,'Xibo\\Entity\\Page'),(8,'Xibo\\Entity\\Playlist'),(7,'Xibo\\Entity\\Region'),(5,'Xibo\\Entity\\Widget');
/*!40000 ALTER TABLE `permissionentity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phinxlog`
--

DROP TABLE IF EXISTS `phinxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phinxlog`
--

LOCK TABLES `phinxlog` WRITE;
/*!40000 ALTER TABLE `phinxlog` DISABLE KEYS */;
INSERT INTO `phinxlog` VALUES (20180130073838,'InstallMigration','2020-03-25 13:12:51','2020-03-25 13:12:57',0),(20180131113100,'OldUpgradeStep85Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131113853,'OldUpgradeStep86Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131113941,'OldUpgradeStep87Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131113948,'OldUpgradeStep88Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131113952,'OldUpgradeStep92Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131113957,'OldUpgradeStep120Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114002,'OldUpgradeStep121Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114007,'OldUpgradeStep122Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114013,'OldUpgradeStep123Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114017,'OldUpgradeStep124Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114021,'OldUpgradeStep125Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114025,'OldUpgradeStep126Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114030,'OldUpgradeStep127Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114050,'OldUpgradeStep128Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114058,'OldUpgradeStep129Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114103,'OldUpgradeStep130Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114107,'OldUpgradeStep131Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114110,'OldUpgradeStep132Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114114,'OldUpgradeStep133Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114118,'OldUpgradeStep134Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131114123,'OldUpgradeStep135Migration','2020-03-25 13:12:57','2020-03-25 13:12:57',0),(20180131122645,'OneRegionPerPlaylistMigration','2020-03-25 13:12:57','2020-03-25 13:12:58',0),(20180131123038,'PlaylistTagsMigration','2020-03-25 13:12:58','2020-03-25 13:12:58',0),(20180131123248,'WidgetFromToDtMigration','2020-03-25 13:12:58','2020-03-25 13:12:58',0),(20180212143336,'DaypartSystemEntriesAsRecords','2020-03-25 13:12:58','2020-03-25 13:12:58',0),(20180213173846,'MailFromNameSettingMigration','2020-03-25 13:12:58','2020-03-25 13:12:58',0),(20180219141257,'DisplayGroupClosureIndexToNonUnique','2020-03-25 13:12:58','2020-03-25 13:12:59',0),(20180223180534,'DataSetColumnFilterAndSortOptionsMigration','2020-03-25 13:12:59','2020-03-25 13:12:59',0),(20180302182421,'WidgetCreatedAndModifiedDtMigration','2020-03-25 13:12:59','2020-03-25 13:12:59',0),(20180313085749,'MediaTableEditedIdIndexMigration','2020-03-25 13:12:59','2020-03-25 13:12:59',0),(20180320154652,'PlaylistAddDynamicFilterMigration','2020-03-25 13:12:59','2020-03-25 13:13:00',0),(20180327153325,'RemoveUserLoggedInMigration','2020-03-25 13:13:00','2020-03-25 13:13:00',0),(20180514114415,'FixCaseOnHelpTextFieldMigration','2020-03-25 13:13:00','2020-03-25 13:13:00',0),(20180515123835,'LayoutPublishDraftMigration','2020-03-25 13:13:00','2020-03-25 13:13:00',0),(20180529065816,'DataSetTruncateFixMigration','2020-03-25 13:13:00','2020-03-25 13:13:01',0),(20180529073531,'DisplayAsVncLinkMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20180621134013,'AddWidgetSyncTaskMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20180621134250,'EventLayoutPermissionSettingMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20180906115552,'AddForeignKeysToTagsMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20180906115606,'AddForeignKeysToPermissionsMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20180906115712,'AddForeignKeysToWidgetMediaMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20180906131643,'ForgottenPasswordReminderMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20180906131716,'DataSetRssMigration','2020-03-25 13:13:01','2020-03-25 13:13:01',0),(20181011160130,'SimpleSettingsMigration','2020-03-25 13:13:01','2020-03-25 13:13:03',0),(20181113173310,'RemoveFinanceModuleMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20181113180337,'SplitTickerModuleMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20181126113231,'Release1812Migration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20181210092443,'RemoveImageUriModuleMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20181212114400,'CreatePlayerVersionsTableMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20181217135044,'EventSyncMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190121092556,'PlayerUpgradeAndOverrideConfigMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190125170130,'PlayerSoftwareVersionFieldMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190129103831,'AddLinuxDisplayProfileMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190212112534,'AddProofOfPlayStatsDurationAndCountMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190212115432,'AddDefaultTransitionDurationSettingMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190213160914,'AddGlobalStatSettingMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190213162212,'AddHorizontalMenuSettingMigration','2020-03-25 13:13:03','2020-03-25 13:13:03',0),(20190214102508,'AddLayoutEnableStat','2020-03-25 13:13:03','2020-03-25 13:13:04',0),(20190214102516,'AddMediaEnableStat','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190220165703,'AddScheduleRecurrenceMonthlyRepeatsOnMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190227101705,'MakeDisplayLicenseColumnUniqueMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190228120603,'AddDynamicCriteriaTagsMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190301115046,'AdjustGenericfileValidExtensionsMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190315134628,'AddBandwidthLimitColumnToDisplaygroupMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190322162052,'AddPublishedDateColumnMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190326163016,'CreateLayoutHistoryTableMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190328111718,'AddCampaignStatMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190401150256,'AddScheduleNowPageMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190509101525,'CreateReportScheduleTableMigration','2020-03-25 13:13:04','2020-03-25 13:13:04',0),(20190509102648,'CreateSavedReportTableMigration','2020-03-25 13:13:04','2020-03-25 13:13:05',0),(20190509113001,'AddReportPageMigration','2020-03-25 13:13:05','2020-03-25 13:13:05',0),(20190510140126,'TwoFactorAuthMigration','2020-03-25 13:13:05','2020-03-25 13:13:05',0),(20190514134430,'NullableTextFieldsMigration','2020-03-25 13:13:05','2020-03-25 13:13:06',0),(20190515094133,'AddHtmlDatatypeMigration','2020-03-25 13:13:06','2020-03-25 13:13:06',0),(20190515105624,'InstallAdditionalStandardModulesMigration','2020-03-25 13:13:06','2020-03-25 13:13:06',0),(20190517080033,'AddForeignKeysToLktagTablesMigration','2020-03-25 13:13:06','2020-03-25 13:13:07',0),(20190521092700,'AddReportScheduleTaskMigration','2020-03-25 13:13:07','2020-03-25 13:13:07',0),(20190521092930,'AddPreviousRunDateReportScheduleMigration','2020-03-25 13:13:07','2020-03-25 13:13:07',0),(20190521102635,'PlaylistDurationUpdateAtTimestamp','2020-03-25 13:13:07','2020-03-25 13:13:07',0),(20190603083836,'ChangeStatTableStartEndColumnMigration','2020-03-25 13:13:07','2020-03-25 13:13:07',0),(20190610150331,'TagsWithValuesMigration','2020-03-25 13:13:07','2020-03-25 13:13:08',0),(20190611145607,'RemoveOldVersionTableMigration','2020-03-25 13:13:08','2020-03-25 13:13:08',0),(20190612140955,'DisplayTableDatabaseSchemaAdjustmentsMigration','2020-03-25 13:13:08','2020-03-25 13:13:09',0),(20190620112611,'MoveTidyStatsToStatsArchiveTaskMigration','2020-03-25 13:13:09','2020-03-25 13:13:09',0),(20190620142655,'AddPlaylistEnableStatMigration','2020-03-25 13:13:09','2020-03-25 13:13:09',0),(20190626091331,'WidgetHistoryMigration','2020-03-25 13:13:09','2020-03-25 13:13:09',0),(20190626110359,'CreateStatTableMigration','2020-03-25 13:13:09','2020-03-25 13:13:09',0),(20190628083649,'AddStatsMigrationTaskMigration','2020-03-25 13:13:09','2020-03-25 13:13:09',0),(20190710213414,'AddIsActiveReportScheduleMigration','2020-03-25 13:13:09','2020-03-25 13:13:10',0),(20190717101342,'NullableCommandValidationStringMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190719074601,'MissingDefaultValueMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190725115532,'AddScheduleReminderTaskMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190801102042,'DisplayProfileCommandLinkFixMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190801141737,'DatasetAddCustomHeadersColumnMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190801142302,'AddDoohUserTypeMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190802145636,'CreateScheduleReminderTableMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190806144729,'AddShowContentFromMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190823081448,'AddImageProcessingTaskMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190828123735,'AddDefaultSettingResizeLimitResizeThresholdMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190903083314,'AddGlobalSettingForCascadePermissionsMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190905084201,'AddSettingForDefaultTransitionTypeMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190905084642,'AddSettingForAutoLayoutPublishMigration','2020-03-25 13:13:10','2020-03-25 13:13:10',0),(20190910132520,'DisplayMoveCmsMigration','2020-03-25 13:13:10','2020-03-25 13:13:11',0),(20190917093141,'InterruptLayoutMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20190918090608,'AddDefaultSettingQuickChartMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20190919154513,'AddNotificationAttachmentFilenameNonUsersMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20190926135518,'AddSettingForTransitionAutoApplyToLayoutMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20190926140809,'InstallSavedReportsAndSpacerModulesMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20191001092651,'AddNotificationOriginalFilenameMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20191022101141,'AddCommandEntityToPermissionEntityMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20191024152519,'AddScheduleExclusionsTableMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20191122114104,'FixDuplicateModuleFilesMigration','2020-03-25 13:13:11','2020-03-25 13:13:11',0),(20191126103120,'GeoScheduleMigration','2020-03-25 13:13:11','2020-03-25 13:13:12',0),(20191126141140,'RemoteDataSetCsvSourceMigration','2020-03-25 13:13:12','2020-03-25 13:13:12',0),(20191205180116,'AddPlaylistDashboardPageUserMigration','2020-03-25 13:13:12','2020-03-25 13:13:12',0),(20200107082625,'DisplayAddResolutionMigration','2020-03-25 13:13:12','2020-03-25 13:13:12',0),(20200115115935,'AddReportScheduleMessageMigration','2020-03-25 13:13:12','2020-03-25 13:13:12',0),(20200122143630,'AddReleasedRequiredFileMigration','2020-03-25 13:13:12','2020-03-25 13:13:13',0),(20200122191232,'AddCommercialLicenceColumnMigration','2020-03-25 13:13:13','2020-03-25 13:13:13',0),(20200129104944,'AddEngagementsStatsMigration','2020-03-25 13:13:13','2020-03-25 13:13:13',0),(20200130165443,'CountdownModuleAddMigration','2020-03-25 13:13:13','2020-03-25 13:13:13',0);
/*!40000 ALTER TABLE `phinxlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_software`
--

DROP TABLE IF EXISTS `player_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_software` (
  `versionId` int(11) NOT NULL AUTO_INCREMENT,
  `player_type` varchar(20) DEFAULT NULL,
  `player_version` varchar(15) DEFAULT NULL,
  `player_code` smallint(6) DEFAULT NULL,
  `mediaId` int(11) NOT NULL,
  `playerShowVersion` varchar(50) NOT NULL,
  PRIMARY KEY (`versionId`),
  KEY `mediaId` (`mediaId`),
  CONSTRAINT `player_software_ibfk_1` FOREIGN KEY (`mediaId`) REFERENCES `media` (`mediaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_software`
--

LOCK TABLES `player_software` WRITE;
/*!40000 ALTER TABLE `player_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist`
--

DROP TABLE IF EXISTS `playlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `playlist` (
  `playlistId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(254) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `regionId` int(11) DEFAULT NULL,
  `createdDt` datetime NOT NULL,
  `modifiedDt` datetime NOT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `requiresDurationUpdate` int(11) NOT NULL DEFAULT '0',
  `isDynamic` tinyint(4) NOT NULL DEFAULT '0',
  `filterMediaName` varchar(255) DEFAULT NULL,
  `filterMediaTags` varchar(255) DEFAULT NULL,
  `enableStat` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`playlistId`),
  KEY `ownerId` (`ownerId`),
  CONSTRAINT `playlist_ibfk_1` FOREIGN KEY (`ownerId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist`
--

LOCK TABLES `playlist` WRITE;
/*!40000 ALTER TABLE `playlist` DISABLE KEYS */;
INSERT INTO `playlist` VALUES (7,'indication salles-1',1,7,'2020-03-25 13:32:57','2020-03-25 13:35:02',30,0,0,NULL,NULL,NULL),(8,'indication salles-2',1,8,'2020-03-25 13:32:57','2020-03-25 13:35:02',28,0,0,NULL,NULL,NULL),(9,'Affiche_jpeg',1,9,'2020-03-25 13:32:59','2020-03-25 13:35:03',30,0,0,NULL,NULL,NULL),(10,'Heure',1,10,'2020-03-25 13:32:59','2020-03-25 13:35:03',5,0,0,NULL,NULL,NULL),(11,'Logo Polytech',1,11,'2020-03-25 13:32:59','2020-03-25 13:35:03',10,0,0,NULL,NULL,NULL),(12,'Logos UL + INP',1,12,'2020-03-25 13:32:59','2020-03-25 13:35:03',10,0,0,NULL,NULL,NULL),(14,'Vidéo',1,14,'2020-03-25 13:33:02','2020-03-25 13:35:03',7,0,0,NULL,NULL,NULL),(15,'Heure',1,15,'2020-03-25 13:33:02','2020-03-25 13:35:03',5,0,0,NULL,NULL,NULL),(16,'Logo Polytech',1,16,'2020-03-25 13:33:02','2020-03-25 13:35:03',10,0,0,NULL,NULL,NULL),(17,'Logos UL + INP',1,17,'2020-03-25 13:33:02','2020-03-25 13:35:03',10,0,0,NULL,NULL,NULL),(18,'Vidéo',1,18,'2020-03-25 13:33:16','2020-03-25 13:35:02',33,0,0,NULL,NULL,NULL),(19,'Vidéo',1,19,'2020-03-25 13:33:49','2020-03-25 13:35:02',33,0,0,NULL,NULL,NULL),(24,'TwitterTest-1',1,24,'2020-03-25 13:55:23','2020-03-25 14:36:41',30,0,0,NULL,NULL,NULL),(25,'Affiche_jpeg',1,25,'2020-03-25 15:58:16','2020-06-19 14:40:41',0,0,0,NULL,NULL,NULL),(26,'Heure',1,26,'2020-03-25 15:58:16','2020-06-19 14:40:41',0,0,0,NULL,NULL,NULL),(27,'Logo Polytech',1,27,'2020-03-25 15:58:16','2020-06-19 14:40:41',0,0,0,NULL,NULL,NULL),(28,'Logos UL + INP',1,28,'2020-03-25 15:58:16','2020-06-19 14:40:41',0,0,0,NULL,NULL,NULL),(37,'Affiche_jpeg',1,37,'2020-03-25 16:29:12','2020-03-25 16:30:00',30,0,0,NULL,NULL,NULL),(38,'Heure',1,38,'2020-03-25 16:29:12','2020-03-25 16:29:15',0,0,0,NULL,NULL,NULL),(39,'Logo Polytech',1,39,'2020-03-25 16:29:12','2020-03-25 16:29:15',0,0,0,NULL,NULL,NULL),(40,'Logos UL + INP',1,40,'2020-03-25 16:29:12','2020-03-25 16:29:15',0,0,0,NULL,NULL,NULL),(45,'Météo',1,45,'2020-03-25 16:35:14','2020-03-25 16:36:27',0,0,0,NULL,NULL,NULL),(62,'Compte à rebours 60 ans-1',1,62,'2020-03-25 17:52:20','2020-03-25 17:52:30',0,0,0,NULL,NULL,NULL),(63,'Compte à rebours 60 ans-2',1,63,'2020-03-25 17:52:20','2020-03-25 17:52:30',0,0,0,NULL,NULL,NULL),(64,'Compte à rebours 60 ans-3',1,64,'2020-03-25 17:52:20','2020-03-25 17:52:30',0,0,0,NULL,NULL,NULL),(65,'Compte à rebours 60 ans-4',1,65,'2020-03-25 17:52:20','2020-03-25 17:52:30',0,0,0,NULL,NULL,NULL),(66,'Compte à rebours 60 ans-5',1,66,'2020-03-25 17:52:20','2020-03-25 17:52:30',0,0,0,NULL,NULL,NULL),(68,'CoViD-19-1',1,68,'2020-03-29 18:35:06','2020-03-29 18:40:00',30,0,0,NULL,NULL,NULL),(70,'CoViD-19-1',1,69,'2020-03-31 09:49:01','2020-03-31 09:49:02',0,0,0,NULL,NULL,NULL),(73,'Test_PDF-1',1,72,'2020-04-01 14:33:18','2020-04-01 14:40:00',0,0,0,NULL,NULL,NULL),(74,'Compte à rebours 60 ans-1',1,73,'2020-06-21 10:48:58','2020-06-21 10:49:02',0,0,0,NULL,NULL,NULL),(75,'Compte à rebours 60 ans-2',1,74,'2020-06-21 10:48:58','2020-06-21 10:49:02',0,0,0,NULL,NULL,NULL),(76,'Compte à rebours 60 ans-3',1,75,'2020-06-21 10:48:58','2020-06-21 10:49:02',0,0,0,NULL,NULL,NULL),(77,'Compte à rebours 60 ans-4',1,76,'2020-06-21 10:48:58','2020-06-21 10:49:02',0,0,0,NULL,NULL,NULL),(78,'Compte à rebours 60 ans-5',1,77,'2020-06-21 10:48:58','2020-06-21 10:49:02',0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `playlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `regionId` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `name` varchar(254) DEFAULT NULL,
  `width` decimal(10,0) NOT NULL,
  `height` decimal(10,0) NOT NULL,
  `top` decimal(10,0) NOT NULL,
  `left` decimal(10,0) NOT NULL,
  `zIndex` smallint(6) NOT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`regionId`),
  KEY `ownerId` (`ownerId`),
  CONSTRAINT `region_ibfk_1` FOREIGN KEY (`ownerId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (7,3,1,'indication salles-1',1448,905,7,220,0,32),(8,3,1,'indication salles-2',1795,152,923,58,0,30),(9,4,1,'Affiche_jpeg',1855,812,17,31,0,30),(10,4,1,'Heure',785,188,854,1002,0,5),(11,4,1,'Logo Polytech',350,136,877,599,0,10),(12,4,1,'Logos UL + INP',505,153,872,39,0,10),(14,6,1,'Vidéo',1855,812,17,31,0,7),(15,6,1,'Heure',785,188,854,1002,0,5),(16,6,1,'Logo Polytech',350,136,877,599,0,10),(17,6,1,'Logos UL + INP',505,153,872,39,0,10),(18,7,1,'Vidéo',1920,1080,0,0,0,33),(19,8,1,'Vidéo',1920,1080,0,0,0,33),(24,10,1,'TwitterTest-1',1051,642,202,451,0,30),(25,11,1,'Affiche_jpeg',1855,812,17,31,0,30),(26,11,1,'Heure',785,188,852,1069,0,5),(27,11,1,'Logo Polytech',331,122,889,634,0,10),(28,11,1,'Logos UL + INP',505,153,872,66,0,10),(37,14,1,'Affiche_jpeg',1855,812,17,31,0,30),(38,14,1,'Heure',785,188,852,1069,0,5),(39,14,1,'Logo Polytech',331,122,889,634,0,10),(40,14,1,'Logos UL + INP',505,153,872,66,0,10),(45,16,1,'Météo',1920,1080,0,0,0,30),(62,22,1,'Compte à rebours 60 ans-1',928,894,93,959,0,10),(63,22,1,'Compte à rebours 60 ans-2',845,219,100,61,0,5),(64,22,1,'Compte à rebours 60 ans-3',825,149,841,59,0,5),(65,22,1,'Compte à rebours 60 ans-4',900,300,515,27,0,60),(66,22,1,'Compte à rebours 60 ans-5',855,163,330,55,0,5),(68,24,1,'CoViD-19-1',1920,1080,0,0,0,30),(69,25,1,'CoViD-19-1',1920,1080,0,0,0,30),(72,28,1,'Test_PDF-1',1920,1080,0,0,0,0),(73,30,1,'Compte à rebours 60 ans-1',928,894,93,959,0,10),(74,30,1,'Compte à rebours 60 ans-2',845,219,100,61,0,5),(75,30,1,'Compte à rebours 60 ans-3',825,149,841,59,0,5),(76,30,1,'Compte à rebours 60 ans-4',900,300,515,27,0,60),(77,30,1,'Compte à rebours 60 ans-5',855,163,330,55,0,5);
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regionoption`
--

DROP TABLE IF EXISTS `regionoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regionoption` (
  `regionId` int(11) NOT NULL,
  `option` varchar(50) NOT NULL,
  `value` text,
  PRIMARY KEY (`regionId`,`option`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regionoption`
--

LOCK TABLES `regionoption` WRITE;
/*!40000 ALTER TABLE `regionoption` DISABLE KEYS */;
INSERT INTO `regionoption` VALUES (24,'loop','0'),(24,'transitionDirection','N'),(24,'transitionDuration','1000'),(24,'transitionType','fadeOut'),(45,'loop','1'),(45,'transitionDirection','N'),(45,'transitionDuration','2000'),(45,'transitionType','fadeOut'),(62,'loop','0'),(62,'transitionDirection','N'),(62,'transitionDuration',NULL),(62,'transitionType',NULL),(63,'loop','0'),(63,'transitionDirection','N'),(63,'transitionDuration',NULL),(63,'transitionType',NULL),(64,'loop','0'),(64,'transitionDirection','N'),(64,'transitionDuration',NULL),(64,'transitionType',NULL),(65,'loop','0'),(65,'transitionDirection','N'),(65,'transitionDuration',NULL),(65,'transitionType',NULL),(66,'loop','0'),(66,'transitionDirection','N'),(66,'transitionDuration',NULL),(66,'transitionType',NULL),(73,'loop','0'),(73,'transitionDirection','N'),(73,'transitionDuration',NULL),(73,'transitionType',NULL),(74,'loop','0'),(74,'transitionDirection','N'),(74,'transitionDuration',NULL),(74,'transitionType',NULL),(75,'loop','0'),(75,'transitionDirection','N'),(75,'transitionDuration',NULL),(75,'transitionType',NULL),(76,'loop','0'),(76,'transitionDirection','N'),(76,'transitionDuration',NULL),(76,'transitionType',NULL),(77,'loop','0'),(77,'transitionDirection','N'),(77,'transitionDuration',NULL),(77,'transitionType',NULL);
/*!40000 ALTER TABLE `regionoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportschedule`
--

DROP TABLE IF EXISTS `reportschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportschedule` (
  `reportScheduleId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `reportName` varchar(255) NOT NULL,
  `filterCriteria` text,
  `schedule` varchar(255) NOT NULL,
  `lastSavedReportId` int(11) NOT NULL DEFAULT '0',
  `lastRunDt` int(11) NOT NULL DEFAULT '0',
  `previousRunDt` int(11) NOT NULL DEFAULT '0',
  `userId` int(11) NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT '1',
  `createdDt` int(11) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reportScheduleId`),
  KEY `userId` (`userId`),
  CONSTRAINT `reportschedule_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportschedule`
--

LOCK TABLES `reportschedule` WRITE;
/*!40000 ALTER TABLE `reportschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requiredfile`
--

DROP TABLE IF EXISTS `requiredfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requiredfile` (
  `rfId` int(11) NOT NULL AUTO_INCREMENT,
  `displayId` int(11) NOT NULL,
  `type` varchar(1) NOT NULL,
  `itemId` int(11) DEFAULT NULL,
  `bytesRequested` bigint(20) NOT NULL,
  `complete` tinyint(4) NOT NULL DEFAULT '0',
  `path` varchar(255) DEFAULT NULL,
  `size` bigint(20) NOT NULL DEFAULT '0',
  `released` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`rfId`),
  KEY `displayId` (`displayId`,`type`),
  CONSTRAINT `requiredfile_ibfk_1` FOREIGN KEY (`displayId`) REFERENCES `display` (`displayId`)
) ENGINE=InnoDB AUTO_INCREMENT=316 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requiredfile`
--

LOCK TABLES `requiredfile` WRITE;
/*!40000 ALTER TABLE `requiredfile` DISABLE KEYS */;
INSERT INTO `requiredfile` VALUES (1,1,'M',10,0,1,'xibo-image-render.js',2988,1),(2,1,'M',8,0,1,'xibo-countdown-render.js',6744,1),(3,1,'M',6,0,1,'jquery-cycle-2.1.6.min.js',28876,1),(4,1,'M',4,0,1,'xibo-text-render.js',12150,1),(5,1,'M',19,0,1,'compatibility.js',18126,1),(6,1,'M',2,0,1,'moment.js',160251,1),(7,1,'M',17,0,1,'pdf.js',333388,1),(8,1,'M',15,0,1,'15.ttf',45884,1),(9,1,'M',13,0,1,'13.otf',27644,1),(10,1,'M',11,0,1,'xibo-dataset-render.js',1687,1),(11,1,'M',9,0,1,'jquery.marquee.min.js',2248,1),(12,1,'M',7,0,1,'flipclock.min.js',21107,1),(13,1,'M',5,0,1,'Chart.min.js',159638,1),(14,1,'M',20,0,1,'xibo-webpage-render.js',4832,1),(15,1,'M',3,0,1,'xibo-layout-scaler.js',3694,1),(16,1,'M',18,0,1,'pdf.worker.js',1337459,1),(17,1,'M',1,0,1,'jquery-1.11.1.min.js',95785,1),(18,1,'M',16,0,1,'16.otf',19684,1),(19,1,'M',14,0,1,'14.ttf',116580,1),(20,1,'M',12,0,1,'12.otf',30060,1),(21,1,'M',28,0,1,'28.mp4',13907207,1),(22,1,'L',7,0,1,'7.xlf',482,1),(23,2,'M',31,0,1,'animate.css',72259,1),(24,2,'M',6,0,1,'jquery-cycle-2.1.6.min.js',28876,1),(25,2,'M',46,0,1,'wi-rain.jpg',655983,1),(26,2,'M',29,0,1,'bootstrap.min.css',121200,1),(27,2,'M',4,0,1,'xibo-text-render.js',12150,1),(28,2,'M',44,0,1,'wi-night-clear.jpg',738913,1),(29,2,'M',19,0,1,'compatibility.js',18126,1),(30,2,'M',2,0,1,'moment.js',160251,1),(31,2,'M',42,0,1,'wi-fog.jpg',597609,1),(32,2,'M',17,0,1,'pdf.js',333388,1),(33,2,'M',40,0,1,'wi-day-cloudy.jpg',2628732,1),(34,2,'M',15,0,1,'15.ttf',45884,1),(35,2,'M',38,0,1,'weathericons-regular-webfont.woff2',44720,1),(36,2,'M',13,0,1,'13.otf',27644,1),(37,2,'M',36,0,1,'weathericons-regular-webfont.ttf',67016,1),(38,2,'M',11,0,1,'xibo-dataset-render.js',1687,1),(39,2,'M',34,0,1,'weathericons-regular-webfont.eot',35151,1),(40,2,'M',9,0,1,'jquery.marquee.min.js',2248,1),(41,2,'M',32,0,1,'font-awesome.min.css',23739,1),(42,2,'M',7,0,1,'flipclock.min.js',21107,1),(43,2,'M',47,0,1,'wi-snow.jpg',782263,1),(44,2,'M',30,0,1,'WeatherIcons-Regular.otf',40668,1),(45,2,'M',5,0,1,'Chart.min.js',159638,1),(46,2,'M',45,0,1,'wi-night-partly-cloudy.jpg',220168,1),(47,2,'M',20,0,1,'xibo-webpage-render.js',4832,1),(48,2,'M',3,0,1,'xibo-layout-scaler.js',3694,1),(49,2,'M',43,0,1,'wi-hail.jpg',827270,1),(50,2,'M',18,0,1,'pdf.worker.js',1337459,1),(51,2,'M',1,0,1,'jquery-1.11.1.min.js',95785,1),(52,2,'M',41,0,1,'wi-day-sunny.jpg',1445897,1),(53,2,'M',16,0,1,'16.otf',19684,1),(54,2,'M',39,0,1,'wi-cloudy.jpg',379804,1),(55,2,'M',14,0,1,'14.ttf',116580,1),(56,2,'M',37,0,1,'weathericons-regular-webfont.woff',40408,1),(57,2,'M',12,0,1,'12.otf',30060,1),(58,2,'M',35,0,1,'weathericons-regular-webfont.svg',127706,1),(59,2,'M',10,0,1,'xibo-image-render.js',2988,1),(60,2,'M',33,0,1,'weather-icons.min.css',26633,1),(61,2,'M',8,0,1,'xibo-countdown-render.js',6744,1),(62,2,'M',48,0,1,'wi-windy.jpg',339716,1),(63,2,'M',28,0,1,'28.mp4',13907207,1),(64,2,'L',7,0,1,'7.xlf',482,1),(65,1,'M',49,0,1,'emojione.sprites.png',2391178,1),(66,1,'M',32,0,1,'font-awesome.min.css',23739,1),(67,1,'M',47,0,1,'wi-snow.jpg',782263,1),(68,1,'M',30,0,1,'WeatherIcons-Regular.otf',40668,1),(69,1,'M',45,0,1,'wi-night-partly-cloudy.jpg',220168,1),(70,1,'M',43,0,1,'wi-hail.jpg',827270,1),(71,1,'M',41,0,1,'wi-day-sunny.jpg',1445897,1),(72,1,'M',39,0,1,'wi-cloudy.jpg',379804,1),(73,1,'M',37,0,1,'weathericons-regular-webfont.woff',40408,1),(74,1,'M',52,0,1,'twitter_white.png',15975,1),(75,1,'M',35,0,1,'weathericons-regular-webfont.svg',127706,1),(76,1,'M',50,0,1,'emojione.sprites.css',81309,1),(77,1,'M',33,0,1,'weather-icons.min.css',26633,1),(78,1,'M',48,0,1,'wi-windy.jpg',339716,1),(79,1,'M',31,0,1,'animate.css',72259,1),(80,1,'M',46,0,1,'wi-rain.jpg',655983,1),(81,1,'M',29,0,1,'bootstrap.min.css',121200,1),(82,1,'M',44,0,1,'wi-night-clear.jpg',738913,1),(83,1,'M',42,0,1,'wi-fog.jpg',597609,1),(84,1,'M',40,0,1,'wi-day-cloudy.jpg',2628732,1),(85,1,'M',38,0,1,'weathericons-regular-webfont.woff2',44720,1),(86,1,'M',36,0,1,'weathericons-regular-webfont.ttf',67016,1),(87,1,'M',51,0,1,'twitter_blue.png',16463,1),(88,1,'M',34,0,1,'weathericons-regular-webfont.eot',35151,1),(97,2,'M',51,0,1,'twitter_blue.png',16463,1),(98,2,'M',49,0,1,'emojione.sprites.png',2391178,1),(99,2,'M',52,0,1,'twitter_white.png',15975,1),(100,2,'M',50,0,1,'emojione.sprites.css',81309,1),(115,2,'L',16,0,1,'16.xlf',4691,1),(116,2,'W',45,0,1,NULL,0,1),(119,3,'M',33,0,1,'weather-icons.min.css',26633,1),(120,3,'M',8,0,1,'xibo-countdown-render.js',6744,1),(121,3,'M',48,0,1,'wi-windy.jpg',339716,1),(122,3,'M',31,0,1,'animate.css',72259,1),(123,3,'M',6,0,1,'jquery-cycle-2.1.6.min.js',28876,1),(124,3,'M',46,0,1,'wi-rain.jpg',655983,1),(125,3,'M',29,0,1,'bootstrap.min.css',121200,1),(126,3,'M',4,0,1,'xibo-text-render.js',12150,1),(127,3,'M',44,0,1,'wi-night-clear.jpg',738913,1),(128,3,'M',19,0,1,'compatibility.js',18126,1),(129,3,'M',2,0,1,'moment.js',160251,1),(130,3,'M',42,0,1,'wi-fog.jpg',597609,1),(131,3,'M',17,0,1,'pdf.js',333388,1),(132,3,'M',40,0,1,'wi-day-cloudy.jpg',2628732,1),(133,3,'M',15,0,1,'15.ttf',45884,1),(134,3,'M',38,0,1,'weathericons-regular-webfont.woff2',44720,1),(135,3,'M',13,0,1,'13.otf',27644,1),(136,3,'M',36,0,1,'weathericons-regular-webfont.ttf',67016,1),(137,3,'M',11,0,1,'xibo-dataset-render.js',1687,1),(138,3,'M',51,0,1,'twitter_blue.png',16463,1),(139,3,'M',34,0,1,'weathericons-regular-webfont.eot',35151,1),(140,3,'M',9,0,1,'jquery.marquee.min.js',2248,1),(141,3,'M',49,0,1,'emojione.sprites.png',2391178,1),(142,3,'M',32,0,1,'font-awesome.min.css',23739,1),(143,3,'M',7,0,1,'flipclock.min.js',21107,1),(144,3,'M',47,0,1,'wi-snow.jpg',782263,1),(145,3,'M',30,0,1,'WeatherIcons-Regular.otf',40668,1),(146,3,'M',5,0,1,'Chart.min.js',159638,1),(147,3,'M',45,0,1,'wi-night-partly-cloudy.jpg',220168,1),(148,3,'M',20,0,1,'xibo-webpage-render.js',4832,1),(149,3,'M',3,0,1,'xibo-layout-scaler.js',3694,1),(150,3,'M',43,0,1,'wi-hail.jpg',827270,1),(151,3,'M',18,0,1,'pdf.worker.js',1337459,1),(152,3,'M',1,0,1,'jquery-1.11.1.min.js',95785,1),(153,3,'M',41,0,1,'wi-day-sunny.jpg',1445897,1),(154,3,'M',16,0,1,'16.otf',19684,1),(155,3,'M',39,0,1,'wi-cloudy.jpg',379804,1),(156,3,'M',14,0,1,'14.ttf',116580,1),(157,3,'M',37,0,1,'weathericons-regular-webfont.woff',40408,1),(158,3,'M',12,0,1,'12.otf',30060,1),(159,3,'M',52,0,1,'twitter_white.png',15975,1),(160,3,'M',35,0,1,'weathericons-regular-webfont.svg',127706,1),(161,3,'M',10,0,1,'xibo-image-render.js',2988,1),(162,3,'M',50,0,1,'emojione.sprites.css',81309,1),(163,3,'M',28,0,1,'28.mp4',13907207,1),(164,3,'L',7,0,1,'7.xlf',482,1),(165,3,'L',16,0,1,'16.xlf',4691,1),(166,3,'W',45,0,1,NULL,0,1),(173,2,'M',63,0,1,'63.png',1572679,1),(179,3,'M',63,0,1,'63.png',1572679,1),(180,3,'L',21,0,1,'21.xlf',4958,1),(181,3,'W',57,0,1,NULL,0,1),(182,3,'W',58,0,1,NULL,0,1),(183,3,'W',59,0,1,NULL,0,1),(184,3,'W',60,2182,1,NULL,0,1),(185,2,'L',22,0,1,'22.xlf',4958,1),(186,2,'W',62,0,1,NULL,0,1),(187,2,'W',63,0,1,NULL,0,1),(188,2,'W',64,3399,1,NULL,0,1),(189,2,'W',65,2182,1,NULL,0,1),(209,1,'M',22,0,1,'22.png',12691,1),(210,1,'M',23,0,1,'23.png',9699,1),(211,1,'L',14,0,1,'14.xlf',6146,1),(212,1,'W',37,6127,1,NULL,0,1),(213,1,'W',38,14674,1,NULL,0,1),(214,5,'M',39,0,1,'wi-cloudy.jpg',379804,1),(215,5,'M',14,0,1,'14.ttf',116580,1),(216,5,'M',37,0,1,'weathericons-regular-webfont.woff',40408,1),(217,5,'M',12,0,1,'12.otf',30060,1),(218,5,'M',52,0,1,'twitter_white.png',15975,1),(219,5,'M',35,0,1,'weathericons-regular-webfont.svg',127706,1),(220,5,'M',10,0,1,'xibo-image-render.js',2988,1),(221,5,'M',50,0,1,'emojione.sprites.css',81309,1),(222,5,'M',33,0,1,'weather-icons.min.css',26633,1),(223,5,'M',8,0,1,'xibo-countdown-render.js',6744,1),(224,5,'M',48,0,1,'wi-windy.jpg',339716,1),(225,5,'M',31,0,1,'animate.css',72259,1),(226,5,'M',6,0,1,'jquery-cycle-2.1.6.min.js',28876,1),(227,5,'M',46,0,1,'wi-rain.jpg',655983,1),(228,5,'M',29,0,1,'bootstrap.min.css',121200,1),(229,5,'M',44,0,1,'wi-night-clear.jpg',738913,1),(230,5,'M',4,0,1,'xibo-text-render.js',12150,1),(231,5,'M',19,0,1,'compatibility.js',18126,1),(232,5,'M',42,0,1,'wi-fog.jpg',597609,1),(233,5,'M',2,0,1,'moment.js',160251,1),(234,5,'M',17,0,1,'pdf.js',333388,1),(235,5,'M',40,0,1,'wi-day-cloudy.jpg',2628732,1),(236,5,'M',15,0,1,'15.ttf',45884,1),(237,5,'M',38,0,1,'weathericons-regular-webfont.woff2',44720,1),(238,5,'M',13,0,1,'13.otf',27644,1),(239,5,'M',36,0,1,'weathericons-regular-webfont.ttf',67016,1),(240,5,'M',11,0,1,'xibo-dataset-render.js',1687,1),(241,5,'M',51,0,1,'twitter_blue.png',16463,1),(242,5,'M',34,0,1,'weathericons-regular-webfont.eot',35151,1),(243,5,'M',9,0,1,'jquery.marquee.min.js',2248,1),(244,5,'M',49,0,1,'emojione.sprites.png',2391178,1),(245,5,'M',32,0,1,'font-awesome.min.css',23739,1),(246,5,'M',7,0,1,'flipclock.min.js',21107,1),(247,5,'M',47,0,1,'wi-snow.jpg',782263,1),(248,5,'M',30,0,1,'WeatherIcons-Regular.otf',40668,1),(249,5,'M',45,0,1,'wi-night-partly-cloudy.jpg',220168,1),(250,5,'M',5,0,1,'Chart.min.js',159638,1),(251,5,'M',20,0,1,'xibo-webpage-render.js',4832,1),(252,5,'M',43,0,1,'wi-hail.jpg',827270,1),(253,5,'M',3,0,1,'xibo-layout-scaler.js',3694,1),(254,5,'M',18,0,1,'pdf.worker.js',1337459,1),(255,5,'M',41,0,1,'wi-day-sunny.jpg',1445897,1),(256,5,'M',1,0,1,'jquery-1.11.1.min.js',95785,1),(257,5,'M',16,0,1,'16.otf',19684,1),(258,5,'M',23,0,1,'23.png',9699,1),(259,5,'M',28,0,1,'28.mp4',13907207,1),(260,5,'M',22,0,1,'22.png',12691,1),(261,5,'L',7,0,1,'7.xlf',482,1),(262,5,'L',14,0,1,'14.xlf',6146,1),(263,5,'W',37,6136,1,NULL,0,1),(264,5,'W',38,14674,1,NULL,0,1);
/*!40000 ALTER TABLE `requiredfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resolution`
--

DROP TABLE IF EXISTS `resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resolution` (
  `resolutionId` int(11) NOT NULL AUTO_INCREMENT,
  `resolution` varchar(254) NOT NULL,
  `width` smallint(6) NOT NULL,
  `height` smallint(6) NOT NULL,
  `intended_width` smallint(6) NOT NULL,
  `intended_height` smallint(6) NOT NULL,
  `version` tinyint(4) NOT NULL DEFAULT '1',
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`resolutionId`),
  KEY `userId` (`userId`),
  CONSTRAINT `resolution_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resolution`
--

LOCK TABLES `resolution` WRITE;
/*!40000 ALTER TABLE `resolution` DISABLE KEYS */;
INSERT INTO `resolution` VALUES (1,'1080p HD Landscape',800,450,1920,1080,2,1,1),(2,'720p HD Landscape',800,450,1280,720,2,1,1),(3,'1080p HD Portrait',450,800,1080,1920,2,1,1),(4,'720p HD Portrait',450,800,720,1280,2,1,1),(5,'4k cinema',800,450,4096,2304,2,1,1),(6,'Common PC Monitor 4:3',800,600,1024,768,2,1,1),(7,'4k UHD Landscape',450,800,3840,2160,2,1,1),(8,'4k UHD Portrait',800,450,2160,3840,2,1,1);
/*!40000 ALTER TABLE `resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_report`
--

DROP TABLE IF EXISTS `saved_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_report` (
  `savedReportId` int(11) NOT NULL AUTO_INCREMENT,
  `saveAs` varchar(255) NOT NULL,
  `reportName` varchar(255) NOT NULL,
  `mediaId` int(11) NOT NULL,
  `reportScheduleId` int(11) NOT NULL,
  `generatedOn` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`savedReportId`),
  KEY `userId` (`userId`),
  KEY `mediaId` (`mediaId`),
  KEY `reportScheduleId` (`reportScheduleId`),
  CONSTRAINT `saved_report_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`),
  CONSTRAINT `saved_report_ibfk_2` FOREIGN KEY (`mediaId`) REFERENCES `media` (`mediaId`),
  CONSTRAINT `saved_report_ibfk_3` FOREIGN KEY (`reportScheduleId`) REFERENCES `reportschedule` (`reportScheduleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_report`
--

LOCK TABLES `saved_report` WRITE;
/*!40000 ALTER TABLE `saved_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `eventId` int(11) NOT NULL AUTO_INCREMENT,
  `eventTypeId` int(11) NOT NULL,
  `campaignId` int(11) DEFAULT NULL,
  `commandId` int(11) DEFAULT NULL,
  `dayPartId` int(11) NOT NULL DEFAULT '0',
  `userId` int(11) NOT NULL,
  `fromDt` bigint(20) DEFAULT NULL,
  `toDt` bigint(20) DEFAULT NULL,
  `is_priority` tinyint(4) NOT NULL,
  `displayOrder` int(11) NOT NULL DEFAULT '0',
  `lastRecurrenceWatermark` bigint(20) DEFAULT NULL,
  `syncTimezone` tinyint(4) NOT NULL DEFAULT '0',
  `recurrence_type` enum('Minute','Hour','Day','Week','Month','Year') DEFAULT NULL,
  `recurrence_detail` int(11) DEFAULT NULL,
  `recurrence_range` bigint(20) DEFAULT NULL,
  `recurrenceRepeatsOn` varchar(14) DEFAULT NULL,
  `syncEvent` int(11) NOT NULL DEFAULT '0',
  `recurrenceMonthlyRepeatsOn` tinyint(4) NOT NULL DEFAULT '0',
  `shareOfVoice` tinyint(4) DEFAULT NULL,
  `isGeoAware` tinyint(4) NOT NULL DEFAULT '0',
  `geoLocation` text,
  PRIMARY KEY (`eventId`),
  KEY `campaignId` (`campaignId`),
  KEY `userId` (`userId`),
  CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,5,8,NULL,3,1,1585692000,NULL,0,0,1588224600,0,'Day',1,1585751156,NULL,0,0,0,0,NULL),(3,5,8,NULL,3,1,1585837556,NULL,0,0,1593495000,0,'Day',1,NULL,NULL,0,0,0,0,NULL);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduleexclusions`
--

DROP TABLE IF EXISTS `scheduleexclusions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheduleexclusions` (
  `scheduleExclusionId` int(11) NOT NULL AUTO_INCREMENT,
  `eventId` int(11) NOT NULL,
  `fromDt` int(11) NOT NULL,
  `toDt` int(11) NOT NULL,
  PRIMARY KEY (`scheduleExclusionId`),
  KEY `eventId` (`eventId`),
  CONSTRAINT `scheduleexclusions_ibfk_1` FOREIGN KEY (`eventId`) REFERENCES `schedule` (`eventId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduleexclusions`
--

LOCK TABLES `scheduleexclusions` WRITE;
/*!40000 ALTER TABLE `scheduleexclusions` DISABLE KEYS */;
/*!40000 ALTER TABLE `scheduleexclusions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedulereminder`
--

DROP TABLE IF EXISTS `schedulereminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedulereminder` (
  `scheduleReminderId` int(11) NOT NULL AUTO_INCREMENT,
  `eventId` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `option` int(11) NOT NULL,
  `reminderDt` int(11) NOT NULL,
  `lastReminderDt` int(11) NOT NULL,
  `isEmail` tinyint(4) NOT NULL,
  PRIMARY KEY (`scheduleReminderId`),
  KEY `eventId` (`eventId`),
  CONSTRAINT `schedulereminder_ibfk_1` FOREIGN KEY (`eventId`) REFERENCES `schedule` (`eventId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedulereminder`
--

LOCK TABLES `schedulereminder` WRITE;
/*!40000 ALTER TABLE `schedulereminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedulereminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `session_id` varchar(160) NOT NULL,
  `session_data` longtext NOT NULL,
  `session_expiration` int(10) unsigned NOT NULL DEFAULT '0',
  `lastAccessed` datetime DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `isExpired` tinyint(4) NOT NULL DEFAULT '1',
  `userAgent` varchar(255) DEFAULT NULL,
  `remoteAddr` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  KEY `userId` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('0bbg4pa8onvtoeateqntqppbbl','init|s:1:\"1\";csrfToken|s:40:\"0f8dff4b2a9c43e81cce4fda4408a824951a768f\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592912175,'2020-06-23 13:12:15',0,0,'Mozilla/5.0 zgrab/0.x','172.18.0.1'),('0d7o3rriimd14ddkqohgiet1sq','init|s:1:\"1\";slim.flash|a:0:{}',1592905601,'2020-06-23 11:22:41',0,1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('10pm231atb7r0s2r491pgqc2a5','init|s:1:\"1\";slim.flash|a:0:{}',1592860881,'2020-06-22 22:57:21',0,1,'Go-http-client/1.1','172.18.0.1'),('1bd790q2i87rvtgno3sg2gok0e','init|s:1:\"1\";csrfToken|s:40:\"99eefa615132fbb3315e54e879cb3c2fcf250959\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592906299,'2020-06-23 11:34:19',0,0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('1ue3umdiqr95pfbf6sediih8k2','init|s:1:\"1\";csrfToken|s:40:\"ce519dce385aecf5fad47d5042c3073abc5cb076\";slim.flash|a:0:{}',1592906300,'2020-06-23 11:34:20',0,0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('2108ensr3lh72hs33tsf1a5a8u','init|s:1:\"1\";csrfToken|s:40:\"adc4882235244fdb8b4606145ec6a62e139c3396\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592860881,'2020-06-22 22:57:21',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('2psvduail4mshqa37p1hnnkd7h','init|s:1:\"1\";csrfToken|s:40:\"43e97549132cc05ff5884728ac7ead4a2d255b17\";slim.flash|a:0:{}',1592892216,'2020-06-23 07:39:36',0,1,'libwww-perl/6.43','172.18.0.1'),('4vb5n38h707b2no8ecm2buslgb','init|s:1:\"1\";csrfToken|s:40:\"3ed57ebf9c347eb7960d7288e21ddae78b024e60\";slim.flash|a:0:{}',1592909791,'2020-06-23 12:32:31',0,0,'Mozilla/5.0 (Windows NT 5.1; rv:9.0.1) Gecko/20100101 Firefox/9.0.1','172.18.0.1'),('57jcp1j6sov8qpg26frcuphdqg','init|s:1:\"1\";csrfToken|s:40:\"2b1076b3b3d7c541c9fc6cc17c18ccad5f830176\";slim.flash|a:0:{}',1592907636,'2020-06-23 11:56:36',0,0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('6dke1rt1vuqhpnugd17ais5pn9','init|s:1:\"1\";slim.flash|a:0:{}',1592876499,'2020-06-23 03:17:39',0,1,'Hello, world','172.18.0.1'),('70n4502tfuuo6tlsqujavie8o0','init|s:1:\"1\";csrfToken|s:40:\"2724c63521f2cd4627efd4c31e19c13a087448e6\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592909428,'2020-06-23 12:26:28',0,0,'libwww-perl/6.44','172.18.0.1'),('73sg2o4nf5vat0ha83prua4acu','init|s:1:\"1\";slim.flash|a:0:{}',1592860874,'2020-06-22 22:57:14',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('84s4j5rf40je5hghule1cde7rg','init|s:1:\"1\";csrfToken|s:40:\"5618408f6fdbf4119bdd7020f3088db47b615693\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592931319,'2020-06-23 18:31:19',0,0,'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7','172.18.0.1'),('8cknk8lqcumfitiglfg5kvo1od','init|s:1:\"1\";csrfToken|s:40:\"65068bb2cc42c4710e7e251d93764c7550333c97\";slim.flash|a:0:{}',1592860882,'2020-06-22 22:57:22',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('9garistp418pj0h3qrnm5v3ofk','init|s:1:\"1\";slim.flash|a:0:{}',1592899921,'2020-06-23 09:48:01',0,1,'Mozilla/5.0 zgrab/0.x','172.18.0.1'),('9krbm9uo75cl693a8602ehkmnc','init|s:1:\"1\";csrfToken|s:40:\"2817388edddf996a493f5a2955781ac8c23b2137\";slim.flash|a:1:{s:10:\"priorRoute\";s:11:\"/index.php/\";}',1592860878,'2020-06-22 22:57:18',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('a0d2nlenou23521508ss4tch4k','init|s:1:\"1\";csrfToken|s:40:\"0ea95f746d2db91c767941775d9133e3600cd8ce\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592906300,'2020-06-23 11:34:20',0,0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('a1o5aafu8megj17mkosdf66mg9','init|s:1:\"1\";csrfToken|s:40:\"c96479cdd81ab82acb4690699d6a814a1d7cebe7\";slim.flash|a:0:{}',1592923496,'2020-06-23 16:20:56',0,0,'libwww-perl/6.43','172.18.0.1'),('a3m9pcgp666so2uj3jea3pfkaf','init|s:1:\"1\";csrfToken|s:40:\"27e07905389601cf6735c2f8ddf4ecf273ec4ec3\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592861371,'2020-06-22 23:05:31',0,1,'','172.18.0.1'),('banl2kmch62ar97vvvatdiketl','init|s:1:\"1\";csrfToken|s:40:\"c092bd73dd9d1fa4784a5e85c14b3df2f67633b3\";slim.flash|a:0:{}',1592863098,'2020-06-22 23:34:18',0,1,'Mozilla/5.0 zgrab/0.x','172.18.0.1'),('bbn8p1bf267epuma15h1ft168o','init|s:1:\"1\";csrfToken|s:40:\"a84f88807c129c192e604c0f4700fa9d5b811673\";slim.flash|a:0:{}',1592860880,'2020-06-22 22:57:20',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('bdtjd55c1cjk94gc73ar78bdll','init|s:1:\"1\";csrfToken|s:40:\"30457571b2b0cfe8d89007b5811666d40602f10b\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592928973,'2020-06-23 17:52:13',0,0,'','172.18.0.1'),('ch5jlgsg7s3p2g41rshplnjmvj','init|s:1:\"1\";csrfToken|s:40:\"a9375d018f90876e549e91d55dd48b1723dc33d6\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592900113,'2020-06-23 09:51:13',0,1,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36','172.18.0.1'),('d8u0i83ortae8n1ul4tjmrd182','init|s:1:\"1\";csrfToken|s:40:\"9b767a7813298b77715742c09eae1bf9c80f1962\";slim.flash|a:0:{}',1592860223,'2020-06-22 22:46:23',0,1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('da3dgt58ba1ltr08m1kd5p5kc0','init|s:1:\"1\";slim.flash|a:0:{}',1592861030,'2020-06-22 22:59:50',0,1,'Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)','172.18.0.1'),('dn3dcad19qcsgvr2o0gbkv0qi8','init|s:1:\"1\";slim.flash|a:0:{}',1592860877,'2020-06-22 22:57:17',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('ee54f4akvte3eojge2vn9takqo','init|s:1:\"1\";csrfToken|s:40:\"6ab81446adbf422d0b7ebaaf7b8f5a07fd718377\";slim.flash|a:1:{s:10:\"priorRoute\";s:11:\"/index.php/\";}',1592860222,'2020-06-22 22:46:22',0,1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('egavuo50nhlmjj6eertfrf1hcl','init|s:1:\"1\";csrfToken|s:40:\"ba05ac6de3223fb783934f60e5fc1f3cebe78b71\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592908628,'2020-06-23 12:13:08',0,0,'','172.18.0.1'),('figkp8vmv64bofoh8s6ntttt9d','init|s:1:\"1\";slim.flash|a:0:{}',1592916387,'2020-06-23 14:22:27',0,0,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('gg6n5n4g6233kjmmvcmackuvmc','init|s:1:\"1\";csrfToken|s:40:\"af394bb67b0fa69aae99279f58ec20edd1a8b4ad\";slim.flash|a:1:{s:10:\"priorRoute\";s:11:\"/index.php/\";}',1592907636,'2020-06-23 11:56:36',0,0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('h2tmlcjjoab4cck7svcq9sb0js','init|s:1:\"1\";csrfToken|s:40:\"952e3b774a452edb55136e1c13da24a9bf865b16\";slim.flash|a:0:{}',1592916395,'2020-06-23 14:22:35',0,0,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('h747c614o8evk7dc5qhehh9o6t','init|s:1:\"1\";slim.flash|a:0:{}',1592916388,'2020-06-23 14:22:28',0,0,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('hdpngkd9rcheieb7tlbtvtqv6c','init|s:1:\"1\";csrfToken|s:40:\"46c753b3deae87d8439cdcd2a75c7250e9232545\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592901599,'2020-06-23 10:15:59',0,1,'','172.18.0.1'),('hhhleij28gip5q21aubt0h7os0','init|s:1:\"1\";csrfToken|s:40:\"69263c861f4dd7411342612c3624d6758605fe8a\";slim.flash|a:0:{}',1592864381,'2020-06-22 23:55:41',0,1,'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36','172.18.0.1'),('ikf0870dqjknued8j7relm0tos','init|s:1:\"1\";csrfToken|s:40:\"a93a02bd05c067a75d5225e3594fd8ab317add06\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592892216,'2020-06-23 07:39:36',0,1,'libwww-perl/6.43','172.18.0.1'),('ilae67gspv1vmpoj32q5sogr49','init|s:1:\"1\";slim.flash|a:0:{}',1592909791,'2020-06-23 12:32:31',0,0,'Mozilla/5.0 (Windows NT 5.1; rv:9.0.1) Gecko/20100101 Firefox/9.0.1','172.18.0.1'),('ir7k0teee457kriv73amtr7atq','init|s:1:\"1\";csrfToken|s:40:\"442033998f54b65a8d09f36649e1fb176890d950\";slim.flash|a:0:{}',1592865645,'2020-06-23 00:16:45',0,1,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36','172.18.0.1'),('jptuq0vu2p6h17daki4l8fj93o','init|s:1:\"1\";csrfToken|s:40:\"9f0a3ac74400f64ee396c98ee4cd38e906c45b93\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592863098,'2020-06-22 23:34:18',0,1,'Mozilla/5.0 zgrab/0.x','172.18.0.1'),('lpep81f2p70l3girnak64hi013','init|s:1:\"1\";slim.flash|a:0:{}',1592860875,'2020-06-22 22:57:15',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('lpgvhvj50h3sb254iahp6a6hpu','init|s:1:\"1\";csrfToken|s:40:\"867208a1d229c3b78ce49c69c842068e25a6cbe9\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592905359,'2020-06-23 11:18:39',0,1,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36','172.18.0.1'),('m6214b1nte99vu30s3rbcoapot','init|s:1:\"1\";slim.flash|a:0:{}',1592860875,'2020-06-22 22:57:15',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('ml5ce9mi86ujbt10rbd52hbupe','init|s:1:\"1\";csrfToken|s:40:\"6b13fb7e7e225e01dd8243a406d392f4dd417be4\";slim.flash|a:0:{}',1592906300,'2020-06-23 11:34:20',0,0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36','172.18.0.1'),('mvhl6ld97n832s6s5ubr11tuun','init|s:1:\"1\";csrfToken|s:40:\"04a9d1fa0ba17d59ad1c9a71cc6b32fc39121ead\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592923496,'2020-06-23 16:20:56',0,0,'libwww-perl/6.43','172.18.0.1'),('n79l990bul5ghqt4oqdbb0emq1','init|s:1:\"1\";slim.flash|a:0:{}',1592880877,'2020-06-23 04:30:37',0,1,'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)','172.18.0.1'),('nkt3li56q16jvcmlapgbs71o8p','init|s:1:\"1\";csrfToken|s:40:\"5baf9386ae07c4a4e6752dbe388d2f85f0c55dad\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592922454,'2020-06-23 16:03:34',0,0,'python-requests/2.23.0','172.18.0.1'),('nmq8muhc1v9djgap2pk6s7bt5m','init|s:1:\"1\";csrfToken|s:40:\"55a6b03fcdefaee06ce53f16c460a857cc7a7dd2\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592864380,'2020-06-22 23:55:40',0,1,'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36','172.18.0.1'),('ns9habcnt6lr3bv9gmdv8s5gfc','init|s:1:\"1\";csrfToken|s:40:\"20417d08494eecb1c9348b765ce602cbc28b7479\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592889636,'2020-06-23 06:56:36',0,1,'Mozilla/5.0 zgrab/0.x','172.18.0.1'),('oidj2bdvpfpth9olpd4urivel2','init|s:1:\"1\";csrfToken|s:40:\"e2980cf0f29c65b58ddbed786baedf1637e11e70\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592873534,'2020-06-23 02:28:14',0,1,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36','172.18.0.1'),('ooca0i91pa1pksosdbokk4pfd2','init|s:1:\"1\";csrfToken|s:40:\"ddd21065cc868f0f32798ff958a127c716f6937d\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592916394,'2020-06-23 14:22:34',0,0,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('rfatkb2fn629nanuk2lvae653g','init|s:1:\"1\";csrfToken|s:40:\"2cf731098ded02b244d5d1812e7a672dcb30715a\";slim.flash|a:0:{}',1592860878,'2020-06-22 22:57:18',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('ros95bocn7enk1gh0j7efqddfd','init|s:1:\"1\";slim.flash|a:0:{}',1592860876,'2020-06-22 22:57:16',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('s0f4vt9rk7cbct4f62aqt6gaat','init|s:1:\"1\";slim.flash|a:0:{}',1592894748,'2020-06-23 08:21:48',0,1,'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:71.0) Gecko/20100101 Firefox/71.0','172.18.0.1'),('segf56bono30ac5chd5j59aqb6','init|s:1:\"1\";slim.flash|a:0:{}',1592860872,'2020-06-22 22:57:12',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('skhndaapmkf2gq7s9f8rbp4stb','init|s:1:\"1\";csrfToken|s:40:\"eb22d880d85444237c85d70287160687a36d22c4\";slim.flash|a:1:{s:10:\"priorRoute\";s:11:\"/index.php/\";}',1592860879,'2020-06-22 22:57:19',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('sl2dfd363jnd6r4n28sh63spgk','init|s:1:\"1\";csrfToken|s:40:\"134218080bdd03d350d13c77a31e3b4c44800621\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592892423,'2020-06-23 07:43:03',0,1,'Mozilla/5.0 zgrab/0.x','172.18.0.1'),('sm5l4mln6s07089amat06ja5n2','init|s:1:\"1\";slim.flash|a:0:{}',1592867753,'2020-06-23 00:51:53',0,1,'Hello, world','172.18.0.1'),('sufj1iuvg8pqhsvn67pkn2n0fc','init|s:1:\"1\";csrfToken|s:40:\"7fec42f3a7e0f9c2a3ebcb576009ab6e8b672a7d\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592863098,'2020-06-22 23:34:18',0,1,'','172.18.0.1'),('t7ib8co15577m5lcqh2q3d1ci3','init|s:1:\"1\";slim.flash|a:0:{}',1592860873,'2020-06-22 22:57:13',0,1,'Mozilla/5.0 (Windows; U; Windows NT 6.0;en-US; rv:1.9.2) Gecko/20100115 Firefox/3.6)','172.18.0.1'),('ta1sd6nhlunoame50ogbp9pru2','init|s:1:\"1\";csrfToken|s:40:\"67238691b3cacf1cba073de2c9f0a1be19a61f5e\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592927700,'2020-06-23 17:31:00',0,0,'','172.18.0.1'),('tep2mvagc81jruvk4i6ctnuu1l','init|s:1:\"1\";csrfToken|s:40:\"2b675e9e475529cf4648428c5e3e85a8e1e30434\";slim.flash|a:0:{}',1592909428,'2020-06-23 12:26:28',0,0,'libwww-perl/6.44','172.18.0.1'),('tlru92lpotiib7qmbdl0k743fk','init|s:1:\"1\";csrfToken|s:40:\"bdad2a79b78d5dbe678814ff025726b52f324212\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592931903,'2020-06-23 18:41:03',0,0,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36','172.18.0.1'),('topr79lcdf149sa2bgcs95cooj','init|s:1:\"1\";csrfToken|s:40:\"d0f3de61391ad999441da186d358424aa4200d6f\";slim.flash|a:1:{s:10:\"priorRoute\";s:1:\"/\";}',1592892624,'2020-06-23 07:46:24',0,1,'NetSystemsResearch studies the availability of various services across the internet. Our website is netsystemsresearch.com','172.18.0.1');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `settingId` int(11) NOT NULL AUTO_INCREMENT,
  `setting` varchar(50) NOT NULL,
  `value` varchar(1000) NOT NULL,
  `userSee` tinyint(4) NOT NULL DEFAULT '1',
  `userChange` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`settingId`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'MEDIA_DEFAULT','private',1,1),(2,'LAYOUT_DEFAULT','private',1,1),(3,'defaultUsertype','User',1,1),(7,'userModule','module_user_general.php',0,0),(11,'defaultTimezone','Europe/Paris',1,1),(18,'mail_to','robotechnancy@gmail.com',1,1),(19,'mail_from','xibo@polytech-nancy.fr',1,1),(30,'audit','emergency',1,1),(33,'LIBRARY_LOCATION','/var/www/cms/library/',0,0),(34,'SERVER_KEY','Stm9Sl90',1,1),(35,'HELP_BASE','http://www.xibo.org.uk/manual/en/',1,1),(36,'PHONE_HOME','1',1,1),(37,'PHONE_HOME_KEY','',0,0),(38,'PHONE_HOME_URL','http://www.xibo.org.uk/stats/track.php',0,0),(39,'PHONE_HOME_DATE','1592210653',0,0),(40,'SERVER_MODE','Production',1,1),(41,'MAINTENANCE_ENABLED','Protected',1,1),(42,'MAINTENANCE_EMAIL_ALERTS','1',1,1),(43,'MAINTENANCE_KEY','Kp7vMStthGekUUKF',1,1),(44,'MAINTENANCE_LOG_MAXAGE','30',1,1),(45,'MAINTENANCE_STAT_MAXAGE','30',1,1),(46,'MAINTENANCE_ALERT_TOUT','12',1,1),(47,'SHOW_DISPLAY_AS_VNCLINK','',1,1),(48,'SHOW_DISPLAY_AS_VNC_TGT','_top',1,1),(49,'MAINTENANCE_ALWAYS_ALERT','0',1,1),(50,'SCHEDULE_LOOKAHEAD','1',1,0),(51,'REQUIRED_FILES_LOOKAHEAD','172800',1,1),(52,'REGION_OPTIONS_COLOURING','Media Colouring',1,1),(53,'LAYOUT_COPY_MEDIA_CHECKB','0',1,1),(54,'MAX_LICENSED_DISPLAYS','0',0,0),(55,'LIBRARY_MEDIA_UPDATEINALL_CHECKB','1',1,1),(56,'USER_PASSWORD_POLICY','',1,1),(57,'USER_PASSWORD_ERROR','',1,1),(58,'MODULE_CONFIG_LOCKED_CHECKB','0',0,0),(59,'LIBRARY_SIZE_LIMIT_KB','0',1,0),(60,'MONTHLY_XMDS_TRANSFER_LIMIT_KB','0',1,0),(61,'DEFAULT_LANGUAGE','fr',1,1),(62,'TRANSITION_CONFIG_LOCKED_CHECKB','0',1,0),(63,'GLOBAL_THEME_NAME','default',1,1),(64,'DEFAULT_LAT','48.659850',1,1),(65,'DEFAULT_LONG','6.188293',1,1),(66,'SCHEDULE_WITH_VIEW_PERMISSION','0',1,1),(67,'SETTING_IMPORT_ENABLED','1',1,1),(68,'SETTING_LIBRARY_TIDY_ENABLED','1',1,1),(69,'SENDFILE_MODE','Apache',0,0),(70,'EMBEDDED_STATUS_WIDGET','',1,0),(71,'PROXY_HOST','',1,1),(72,'PROXY_PORT','0',1,1),(73,'PROXY_AUTH','',1,1),(74,'DATE_FORMAT','d-m-Y H:i',1,1),(75,'DETECT_LANGUAGE','1',1,1),(76,'DEFAULTS_IMPORTED','1',0,0),(77,'FORCE_HTTPS','0',1,1),(78,'ISSUE_STS','0',1,1),(79,'STS_TTL','600',1,1),(81,'CALENDAR_TYPE','Gregorian',1,1),(82,'DASHBOARD_LATEST_NEWS_ENABLED','1',1,1),(83,'LIBRARY_MEDIA_DELETEOLDVER_CHECKB','1',1,1),(84,'PROXY_EXCEPTIONS','',1,1),(85,'INSTANCE_SUSPENDED','0',0,0),(86,'INHERIT_PARENT_PERMISSIONS','1',1,1),(87,'XMR_ADDRESS','tcp://cms-xmr:50001',0,0),(88,'XMR_PUB_ADDRESS','tcp://cms.example.org:9505',1,1),(89,'CDN_URL','',0,0),(90,'ELEVATE_LOG_UNTIL','1585146999',1,1),(91,'RESTING_LOG_LEVEL','emergency',1,1),(92,'TASK_CONFIG_LOCKED_CHECKB','0',0,0),(93,'WHITELIST_LOAD_BALANCERS','',1,1),(94,'DEFAULT_LAYOUT','7',1,1),(95,'DISPLAY_PROFILE_STATS_DEFAULT','0',1,1),(96,'DISPLAY_PROFILE_CURRENT_LAYOUT_STATUS_ENABLED','1',1,1),(97,'DISPLAY_PROFILE_SCREENSHOT_INTERVAL_ENABLED','1',1,1),(98,'DISPLAY_PROFILE_SCREENSHOT_SIZE_DEFAULT','200',1,1),(99,'LATEST_NEWS_URL','http://xibo.org.uk/feed',0,0),(100,'DISPLAY_LOCK_NAME_TO_DEVICENAME','0',1,1),(101,'mail_from_name','Xibo - Polytech Nancy',1,1),(102,'SCHEDULE_SHOW_LAYOUT_NAME','0',1,1),(103,'DEFAULT_USERGROUP','1',1,1),(104,'PASSWORD_REMINDER_ENABLED','Off',1,1),(105,'DISPLAY_AUTO_AUTH','0',0,0),(106,'EVENT_SYNC','0',0,0),(107,'DEFAULT_TRANSITION_DURATION','1000',1,1),(108,'LAYOUT_STATS_ENABLED_DEFAULT','0',1,1),(109,'DISPLAY_PROFILE_AGGREGATION_LEVEL_DEFAULT','Individual',1,1),(110,'MEDIA_STATS_ENABLED_DEFAULT','Inherit',1,1),(111,'WIDGET_STATS_ENABLED_DEFAULT','Inherit',1,1),(112,'NAVIGATION_MENU_POSITION','vertical',1,1),(113,'TWOFACTOR_ISSUER','',1,1),(114,'PLAYLIST_STATS_ENABLED_DEFAULT','Inherit',1,1),(115,'DEFAULT_RESIZE_LIMIT','6000',1,1),(116,'DEFAULT_RESIZE_THRESHOLD','1920',1,1),(117,'DEFAULT_CASCADE_PERMISSION_CHECKB','1',1,1),(118,'DEFAULT_TRANSITION_IN','fadeIn',1,1),(119,'DEFAULT_TRANSITION_OUT','fadeOut',1,1),(120,'DEFAULT_LAYOUT_AUTO_PUBLISH_CHECKB','0',1,1),(121,'QUICK_CHART_URL','http://cms-quickchart:3400',0,1),(122,'DEFAULT_TRANSITION_AUTO_APPLY','1',1,1);
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stat`
--

DROP TABLE IF EXISTS `stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stat` (
  `statId` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `statDate` int(11) NOT NULL,
  `scheduleId` int(11) NOT NULL,
  `displayId` int(11) NOT NULL,
  `campaignId` int(11) DEFAULT NULL,
  `layoutId` int(11) DEFAULT NULL,
  `mediaId` int(11) DEFAULT NULL,
  `widgetId` int(11) DEFAULT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `tag` varchar(254) DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `engagements` text,
  PRIMARY KEY (`statId`),
  KEY `statDate` (`statDate`),
  KEY `displayId` (`displayId`,`end`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stat`
--

LOCK TABLES `stat` WRITE;
/*!40000 ALTER TABLE `stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(254) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,'Published'),(2,'Draft'),(3,'Pending Approval');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `tagId` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(50) NOT NULL,
  `isSystem` int(11) NOT NULL DEFAULT '0',
  `options` text,
  `isRequired` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tagId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'template',1,NULL,0),(2,'background',1,NULL,0),(3,'thumbnail',1,NULL,0),(4,'default',0,NULL,0),(5,'imported',0,NULL,0),(6,'60 ans',0,NULL,0),(7,'gala',0,NULL,0),(8,'polytech',0,NULL,0),(9,'logo',0,NULL,0);
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task` (
  `taskId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(254) NOT NULL,
  `class` varchar(254) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `pid` int(11) DEFAULT NULL,
  `options` text,
  `schedule` varchar(254) NOT NULL,
  `lastRunDt` int(11) NOT NULL DEFAULT '0',
  `lastRunStartDt` int(11) DEFAULT NULL,
  `lastRunMessage` varchar(255) DEFAULT NULL,
  `lastRunStatus` tinyint(4) NOT NULL DEFAULT '0',
  `lastRunDuration` smallint(6) NOT NULL DEFAULT '0',
  `lastRunExitCode` smallint(6) NOT NULL DEFAULT '0',
  `isActive` tinyint(4) NOT NULL,
  `runNow` tinyint(4) NOT NULL DEFAULT '0',
  `configFile` varchar(254) NOT NULL,
  PRIMARY KEY (`taskId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
INSERT INTO `task` VALUES (1,'Daily Maintenance','\\Xibo\\XTR\\MaintenanceDailyTask',2,0,'[]','0 0 * * * *',1592870402,1592870401,'# Maintenance quotidienne\n\n## Importer une Mise en page\n - Non requis\n\n## Messages du journal des événements formatés\n - Terminé.\n\n## Nettoyage du cache\n - Terminé.\n\n## Supprimer les jetons API expirés\n - Terminé.\n\n',4,1,0,1,0,'/tasks/maintenance-daily.task'),(2,'Regular Maintenance','\\Xibo\\XTR\\MaintenanceRegularTask',2,0,'[]','*/5 * * * * *',1592932200,1592932200,'# Réveil à distance\n - Done\n\n## Playlist Duration Updates\n - Done\n\n## Contruire une Mise en page\n - Done\n\n## Optimiser la Médiathèque\n - Done\n\n## Publishing layouts with set publish dates\n - Done\n\n',4,0,0,1,0,'/tasks/maintenance-regular.task'),(3,'Email Notifications','\\Xibo\\XTR\\EmailNotificationsTask',2,0,'[]','*/5 * * * * *',1592932200,1592932200,'# Notifications par email\n\n## Notifications par email\n - Done\n',4,0,0,1,0,'/tasks/email-notifications.task'),(4,'Stats Archive','\\Xibo\\XTR\\StatsArchiveTask',2,0,'{\"periodSizeInDays\":\"7\",\"maxPeriods\":\"4\",\"archiveStats\":\"On\"}','0 0 * * Mon',1592784000,1592784000,'# Archives des statistiques\n\n - Effectué\n\n## Statistiques formatées\n',4,0,0,1,0,'/tasks/stats-archiver.task'),(5,'Remove old Notifications','\\Xibo\\XTR\\NotificationTidyTask',2,0,'{\"maxAgeDays\":\"7\",\"systemOnly\":\"1\",\"readOnly\":\"0\"}','15 0 * * *',1592871301,1592871301,'# Nettoyage des notifications\n\nEffectué\n\n',4,0,0,1,0,'/tasks/notification-tidy.task'),(6,'Fetch Remote DataSets','\\Xibo\\XTR\\RemoteDataSetFetchTask',2,0,'[]','30 * * * * *',1592929800,1592929800,'# Fetching Remote-DataSets\n\nEffectué\n',4,0,0,1,0,'/tasks/remote-dataset.task'),(7,'Drop Player Cache','\\Xibo\\XTR\\DropPlayerCacheTask',2,NULL,'[]','0 0 1 1 *',0,NULL,NULL,0,0,0,0,0,'/tasks/drop-player-cache.task'),(8,'Sync Dynamic Playlists','\\Xibo\\XTR\\DynamicPlaylistSyncTask',2,0,'[]','* * * * * *',1592932440,1592932440,'No library media/playlist updates since we last ran\n',4,0,0,1,0,'/tasks/dynamic-playlist-sync.task'),(9,'Widget Sync','\\Xibo\\XTR\\WidgetSyncTask',2,0,'[]','*/3 * * * *',1592932320,1592932320,'Synced 0 widgets across 0 layouts.\n',4,0,0,1,0,'/tasks/widget-sync.task'),(10,'Report Schedule','\\Xibo\\XTR\\ReportScheduleTask',2,0,'[]','*/5 * * * * *',1592932200,1592932200,'# Report schedule\n\n',4,0,0,1,0,'/tasks/report-schedule.task'),(11,'Statistics Migration','\\Xibo\\XTR\\StatsMigrationTask',2,0,'{\"killSwitch\":\"0\",\"numberOfRecords\":\"5000\",\"numberOfLoops\":\"10\",\"pauseBetweenLoops\":\"1\",\"optimiseOnComplete\":\"1\"}','*/10 * * * * *',1585142042,1585142042,'## Moving from stat_archive to stat (MySQL)\nDisabling Stats Archive Task.\n- Initial watermark is 1\n\n# End of records.\n- Dropping stat_archive.\nDone.\n\n# Disabling task.\nDone.\n\nEnabling Stats Archive Task.\n',4,0,0,0,0,'/tasks/stats-migration.task'),(12,'Schedule Reminder','\\Xibo\\XTR\\ScheduleReminderTask',2,0,'[]','*/5 * * * * *',1592932200,1592932200,'# Schedule reminder\n\n',4,0,0,1,0,'/tasks/schedule-reminder.task'),(13,'Image Processing','\\Xibo\\XTR\\ImageProcessingTask',2,0,'[]','*/5 * * * * *',1592932200,1592932200,'# Image Processing\n\nReleased and modified image count. 0\n',4,0,0,1,0,'/tasks/image-processing.task');
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transition`
--

DROP TABLE IF EXISTS `transition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transition` (
  `transitionId` int(11) NOT NULL AUTO_INCREMENT,
  `transition` varchar(254) NOT NULL,
  `code` varchar(254) NOT NULL,
  `hasDuration` tinyint(4) NOT NULL,
  `hasDirection` tinyint(4) NOT NULL,
  `availableAsIn` tinyint(4) NOT NULL,
  `availableAsOut` tinyint(4) NOT NULL,
  PRIMARY KEY (`transitionId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transition`
--

LOCK TABLES `transition` WRITE;
/*!40000 ALTER TABLE `transition` DISABLE KEYS */;
INSERT INTO `transition` VALUES (1,'Fade In','fadeIn',1,0,1,0),(2,'Fade Out','fadeOut',1,0,0,1),(3,'Fly','fly',1,1,1,1);
/*!40000 ALTER TABLE `transition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userTypeId` int(11) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `lastAccessed` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `homePageId` tinyint(4) NOT NULL DEFAULT '1',
  `retired` tinyint(4) NOT NULL DEFAULT '0',
  `csprng` tinyint(4) NOT NULL DEFAULT '0',
  `newUserWizard` tinyint(4) NOT NULL DEFAULT '0',
  `firstName` varchar(254) DEFAULT NULL,
  `lastName` varchar(254) DEFAULT NULL,
  `phone` varchar(254) DEFAULT NULL,
  `ref1` varchar(254) DEFAULT NULL,
  `ref2` varchar(254) DEFAULT NULL,
  `ref3` varchar(254) DEFAULT NULL,
  `ref4` varchar(254) DEFAULT NULL,
  `ref5` varchar(254) DEFAULT NULL,
  `isPasswordChangeRequired` tinyint(4) NOT NULL DEFAULT '0',
  `twoFactorTypeId` int(11) NOT NULL DEFAULT '0',
  `twoFactorSecret` text,
  `twoFactorRecoveryCodes` text,
  `showContentFrom` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`userId`),
  KEY `userTypeId` (`userTypeId`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`userTypeId`) REFERENCES `usertype` (`userTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1,'robotech','$2y$10$yDjEFOAQhJo1QIASZNbSYugEBPmHvhYiBlReIst9ol8xKPB7qf3ua','2020-06-21 11:37:03','robotechnancy@gmail.com',29,0,2,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useroption`
--

DROP TABLE IF EXISTS `useroption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useroption` (
  `userId` int(11) NOT NULL,
  `option` varchar(50) NOT NULL,
  `value` text,
  PRIMARY KEY (`userId`,`option`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useroption`
--

LOCK TABLES `useroption` WRITE;
/*!40000 ALTER TABLE `useroption` DISABLE KEYS */;
INSERT INTO `useroption` VALUES (1,'auditlogGrid','{\"time\":1585750486708,\"start\":0,\"length\":10,\"order\":[[0,\"desc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'campaignGrid','{\"time\":1592729262543,\"start\":0,\"length\":10,\"order\":[[0,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'campaignLayoutAssignGrid','{\"time\":1585751011375,\"start\":5,\"length\":5,\"order\":[[0,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'commandGrid','{\"time\":1585750551242,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'dataSetGrid','{\"time\":1585676547520,\"start\":0,\"length\":10,\"order\":[[0,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'daypartGrid','{\"time\":1585751156174,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'displayGrid','{\"time\":1592574999081,\"start\":0,\"length\":10,\"order\":[[3,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'displayGroupGrid','{\"time\":1592341364407,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'displaysGrid','{\"time\":1592729331161,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'layoutGrid','{\"time\":1592729339298,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'libraryGrid','{\"time\":1592572197551,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'moduleGrid','{\"time\":1585644837023,\"start\":0,\"length\":50,\"order\":[[0,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'playerSoftwareGrid','{\"time\":1585750534434,\"start\":0,\"length\":10,\"order\":[[2,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'playlistGrid','{\"time\":1585904428246,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'statusDashboardDisplays','{\"time\":1592729331123,\"start\":0,\"length\":10,\"order\":[[0,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'templateGrid','{\"time\":1592570433810,\"start\":0,\"length\":10,\"order\":[[1,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'toolbar','{\"libraryContent\":[{\"name\":\"Library Search 0\",\"filters\":{\"name\":{\"name\":\"Nom\",\"value\":\"\"},\"tag\":{\"name\":\"Mot-clé\",\"value\":\"\"},\"type\":{\"name\":\"Type\",\"values\":[{\"type\":\"audio\",\"name\":\"Audio\"},{\"type\":\"flash\",\"name\":\"Animation Flash\"},{\"type\":\"htmlpackage\",\"name\":\"HTML Package\"},{\"type\":\"image\",\"name\":\"Image\"},{\"type\":\"pdf\",\"name\":\"PDF\"},{\"type\":\"powerpoint\",\"name\":\"PowerPoint\"},{\"type\":\"video\",\"name\":\"Vidéo\"}]},\"owner\":{\"name\":\"Propriétaire\",\"values\":[{\"userId\":\"1\",\"name\":\"robotech\"}]}},\"hideElement\":false}],\"openedMenu\":2,\"displayTooltips\":1,\"favouriteModules\":[\"image\",\"text\",\"pdf\",\"webpage\"]}'),(1,'userGrid','{\"time\":1592505618117,\"start\":0,\"length\":10,\"order\":[[0,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":false,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}'),(1,'userGroupGrid','{\"time\":1592505581836,\"start\":0,\"length\":10,\"order\":[[0,\"asc\"]],\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true},\"columns\":[{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}},{\"visible\":true,\"search\":{\"search\":\"\",\"smart\":true,\"regex\":false,\"caseInsensitive\":true}}]}');
/*!40000 ALTER TABLE `useroption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertype`
--

DROP TABLE IF EXISTS `usertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usertype` (
  `userTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `userType` varchar(16) NOT NULL,
  PRIMARY KEY (`userTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertype`
--

LOCK TABLES `usertype` WRITE;
/*!40000 ALTER TABLE `usertype` DISABLE KEYS */;
INSERT INTO `usertype` VALUES (1,'Super Admin'),(2,'Group Admin'),(3,'User'),(4,'DOOH');
/*!40000 ALTER TABLE `usertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget`
--

DROP TABLE IF EXISTS `widget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget` (
  `widgetId` int(11) NOT NULL AUTO_INCREMENT,
  `playlistId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `duration` int(11) NOT NULL,
  `displayOrder` int(11) NOT NULL,
  `calculatedDuration` int(11) NOT NULL,
  `useDuration` tinyint(4) NOT NULL DEFAULT '1',
  `fromDt` int(11) NOT NULL,
  `toDt` int(11) NOT NULL,
  `createdDt` int(11) NOT NULL DEFAULT '0',
  `modifiedDt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`widgetId`),
  KEY `playlistId` (`playlistId`),
  KEY `ownerId` (`ownerId`),
  CONSTRAINT `widget_ibfk_1` FOREIGN KEY (`playlistId`) REFERENCES `playlist` (`playlistId`),
  CONSTRAINT `widget_ibfk_2` FOREIGN KEY (`ownerId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget`
--

LOCK TABLES `widget` WRITE;
/*!40000 ALTER TABLE `widget` DISABLE KEYS */;
INSERT INTO `widget` VALUES (7,7,1,'image',30,1,30,1,0,2147483647,1585143177,1585143177),(8,8,1,'text',28,1,28,1,0,2147483647,1585143177,1585143177),(9,9,1,'image',30,1,30,1,0,2147483647,1585143179,1585143179),(10,10,1,'clock',1,1,5,0,0,2147483647,1585143179,1585143179),(11,11,1,'image',1,1,10,0,0,2147483647,1585143179,1585143179),(12,12,1,'image',1,1,10,0,0,2147483647,1585143179,1585143179),(13,14,1,'video',7,1,7,0,0,2147483647,1585143182,1585143182),(14,15,1,'clock',1,1,5,0,0,2147483647,1585143182,1585143182),(15,16,1,'image',1,1,10,0,0,2147483647,1585143182,1585143182),(16,17,1,'image',1,1,10,0,0,2147483647,1585143182,1585143182),(17,18,1,'video',33,1,33,0,0,2147483647,1585143196,1585143196),(18,19,1,'video',33,1,33,0,0,2147483647,1585143196,1585143229),(23,24,1,'twitter',30,1,30,1,0,2147483647,1585144689,1585147083),(24,25,1,'image',30,1,30,1,0,2147483647,1585143166,1585151896),(25,26,1,'clock',1,1,5,0,0,2147483647,1585143166,1585151896),(26,27,1,'image',1,1,10,0,0,2147483647,1585143166,1585151896),(27,28,1,'image',1,1,10,0,0,2147483647,1585143166,1585151896),(37,37,1,'forecastio',30,1,30,1,0,2147483647,1585152332,1585153785),(38,38,1,'clock',1,1,5,0,0,2147483647,1585143166,1585153840),(39,39,1,'image',1,1,10,0,0,2147483647,1585143166,1585153848),(40,40,1,'image',1,1,10,0,0,2147483647,1585143166,1585153858),(45,45,1,'forecastio',30,1,30,1,0,2147483647,1585152332,1585154224),(61,62,1,'image',10,1,10,0,0,2147483647,1585157545,1585158740),(62,63,1,'text',5,1,5,0,0,2147483647,1585157575,1585158740),(63,64,1,'text',5,1,5,0,0,2147483647,1585157684,1585158740),(64,65,1,'countdown',60,1,60,0,0,2147483647,1585156616,1585158822),(65,66,1,'text',5,1,5,0,0,2147483647,1585157855,1585158762),(66,68,1,'webpage',30,1,30,1,0,2147483647,1585503326,1585503347),(67,70,1,'webpage',30,1,30,1,0,2147483647,1585503326,1585644590),(68,74,1,'image',10,1,10,0,0,2147483647,1585157545,1592729338),(69,75,1,'text',5,1,5,0,0,2147483647,1585157575,1592729338),(70,76,1,'text',5,1,5,0,0,2147483647,1585157684,1592729338),(71,77,1,'countdown',60,1,60,0,0,2147483647,1585156616,1592729338),(72,78,1,'text',5,1,5,0,0,2147483647,1585157855,1592729338);
/*!40000 ALTER TABLE `widget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgethistory`
--

DROP TABLE IF EXISTS `widgethistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgethistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutHistoryId` int(11) NOT NULL,
  `widgetId` int(11) NOT NULL,
  `mediaId` int(11) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `layoutHistoryId` (`layoutHistoryId`),
  CONSTRAINT `widgethistory_ibfk_1` FOREIGN KEY (`layoutHistoryId`) REFERENCES `layouthistory` (`layoutHistoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgethistory`
--

LOCK TABLES `widgethistory` WRITE;
/*!40000 ALTER TABLE `widgethistory` DISABLE KEYS */;
INSERT INTO `widgethistory` VALUES (5,11,31,23,'image',NULL),(6,11,30,22,'image',NULL),(7,11,29,NULL,'clock',NULL),(8,11,28,21,'image',NULL),(9,12,35,23,'image',NULL),(10,12,34,22,'image',NULL),(11,12,33,NULL,'clock',NULL),(12,12,36,NULL,'forecastio','Météo'),(13,14,44,23,'image',NULL),(14,14,43,22,'image',NULL),(15,14,42,NULL,'clock',NULL),(16,14,41,NULL,'forecastio','Météo'),(17,18,55,NULL,'text',NULL),(18,18,50,NULL,'countdown',NULL),(19,18,54,NULL,'text',NULL),(20,18,53,NULL,'text',NULL),(21,18,52,63,'image',NULL),(22,19,60,NULL,'text',NULL),(23,19,59,NULL,'countdown',NULL),(24,19,58,NULL,'text',NULL),(25,19,57,NULL,'text',NULL),(26,19,56,63,'image',NULL),(27,24,68,64,'pdf',NULL);
/*!40000 ALTER TABLE `widgethistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgetoption`
--

DROP TABLE IF EXISTS `widgetoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgetoption` (
  `widgetId` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `option` varchar(254) NOT NULL,
  `value` text,
  PRIMARY KEY (`widgetId`,`type`,`option`),
  CONSTRAINT `widgetoption_ibfk_1` FOREIGN KEY (`widgetId`) REFERENCES `widget` (`widgetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgetoption`
--

LOCK TABLES `widgetoption` WRITE;
/*!40000 ALTER TABLE `widgetoption` DISABLE KEYS */;
INSERT INTO `widgetoption` VALUES (7,'attrib','align','center'),(7,'attrib','enableStat','Inherit'),(7,'attrib','scaleType','center'),(7,'attrib','transIn','fadeIn'),(7,'attrib','transInDirection','N'),(7,'attrib','transInDuration','2000'),(7,'attrib','transOut','fly'),(7,'attrib','transOutDirection','N'),(7,'attrib','transOutDuration','2000'),(7,'attrib','uri','25.jpg'),(7,'attrib','valign','middle'),(8,'attrib','effect','marqueeLeft'),(8,'attrib','enableStat','Inherit'),(8,'attrib','lowerLimit','0'),(8,'attrib','speed','6'),(8,'attrib','ta_text_advanced','1'),(8,'attrib','transIn','fadeIn'),(8,'attrib','transInDirection','N'),(8,'attrib','transInDuration','1000'),(8,'attrib','transOut','fadeOut'),(8,'attrib','transOutDirection','N'),(8,'attrib','transOutDuration','2000'),(8,'attrib','upperLimit','0'),(8,'attrib','xmds','1'),(8,'cdata','text','<p style=\"text-align: center;\"><span style=\"font-family:trebuchet ms,helvetica,sans-serif;\"><span style=\"font-size:96px;\"><span style=\"color: #ffffff;\">Salles </span><span style=\"color:#33cccc;\"><strong>C214</strong></span><span style=\"color: #ffffff;\"> et </span><span style=\"color:#33cccc;\"><strong>C216 </strong></span><span style=\"color: #ffffff;\">- Passez nous voir!</span></span></span></p>\n'),(9,'attrib','align','center'),(9,'attrib','enableStat','Inherit'),(9,'attrib','scaleType','center'),(9,'attrib','uri','26.jpg'),(9,'attrib','valign','middle'),(10,'attrib','clockFace','TwentyFourHourClock'),(10,'attrib','clockTypeId','3'),(10,'attrib','enableStat','Inherit'),(10,'attrib','lowerLimit','0'),(10,'attrib','offset','0'),(10,'attrib','showSeconds','1'),(10,'attrib','ta_text_advanced','0'),(10,'attrib','theme','1'),(10,'attrib','upperLimit','0'),(10,'cdata','format','<span style=\"font-size: 48px; color:#ffffff;\">[HH:mm]</span>'),(11,'attrib','enableStat','Inherit'),(11,'attrib','scaleType','center'),(11,'attrib','uri','22.png'),(12,'attrib','enableStat','Inherit'),(12,'attrib','scaleType','center'),(12,'attrib','uri','23.png'),(13,'attrib','enableStat','Inherit'),(13,'attrib','mute','0'),(13,'attrib','uri','27.mp4'),(14,'attrib','clockFace','TwentyFourHourClock'),(14,'attrib','clockTypeId','3'),(14,'attrib','enableStat','Inherit'),(14,'attrib','lowerLimit','0'),(14,'attrib','offset','0'),(14,'attrib','showSeconds','1'),(14,'attrib','ta_text_advanced','0'),(14,'attrib','theme','1'),(14,'attrib','upperLimit','0'),(14,'cdata','format','<span style=\"font-size: 48px; color:#ffffff;\">[HH:mm]</span>'),(15,'attrib','enableStat','Inherit'),(15,'attrib','scaleType','center'),(15,'attrib','uri','22.png'),(16,'attrib','enableStat','Inherit'),(16,'attrib','scaleType','center'),(16,'attrib','uri','23.png'),(17,'attrib','enableStat','Inherit'),(17,'attrib','mute','0'),(17,'attrib','uri','28.mp4'),(18,'attrib','enableStat','Inherit'),(18,'attrib','mute','0'),(18,'attrib','uri','28.mp4'),(23,'attrib','backgroundColor','rgba(255,255,255,0)'),(23,'attrib','dateFormat','D d M Y'),(23,'attrib','durationIsPerItem','0'),(23,'attrib','effect','scrollHorz'),(23,'attrib','enableStat','Inherit'),(23,'attrib','itemsPerPage','1'),(23,'attrib','language',NULL),(23,'attrib','lowerLimit','0'),(23,'attrib','name','Twitter'),(23,'attrib','noTweetsMessage',NULL),(23,'attrib','overrideTemplate','1'),(23,'attrib','removeHashtags','0'),(23,'attrib','removeMentions','0'),(23,'attrib','removeUrls','0'),(23,'attrib','resultContent','0'),(23,'attrib','resultType','1'),(23,'attrib','searchTerm','polytech nancy'),(23,'attrib','speed','1000'),(23,'attrib','ta_text_advanced','0'),(23,'attrib','templateId','tweet-4'),(23,'attrib','transIn','fly'),(23,'attrib','transInDirection','W'),(23,'attrib','transInDuration','1000'),(23,'attrib','tweetCount','5'),(23,'attrib','tweetDistance','0'),(23,'attrib','updateInterval','30'),(23,'attrib','upperLimit','0'),(23,'attrib','widgetOriginalHeight','200'),(23,'attrib','widgetOriginalPadding','0'),(23,'attrib','widgetOriginalWidth','370'),(23,'cdata','javaScript',''),(23,'cdata','styleSheet','.item {\r\n    float: left;\r\n}\r\n\r\n.emojione {\r\n    width: 30px;\r\n    height: 30px\r\n}\r\n\r\nbody {\r\n    font-family: \"Helvetica\", \"Arial\", sans-serif;\r\n    line-height: 1;\r\n    background-image: url(\'../clouds.jpg\');\r\n    background-repeat: no-repeat;\r\n    background-size: cover;\r\n    background-position: center;\r\n}\r\n\r\n.img-container img {\r\n    width: 50px;\r\n    height: 50px;\r\n    border: 3px solid #fff;\r\n}\r\n\r\n.twitter-container {\r\n    padding: 10px;\r\n    width: 340px !important;\r\n    height: 200px !important;\r\n    background-color: rgba(255, 255, 255, 0.6);\r\n    background: rgba(255, 255, 255, 0.6);\r\n    color: rgba(255, 255, 255, 0.6);\r\n}\r\n\r\n.main-tweet {\r\n    font-size: 14px;\r\n    padding: 20px 0px;\r\n    line-height: 120%;\r\n    color: #434343;\r\n}\r\n\r\n.mini-widget {\r\n    height: 180px;\r\n    padding-top: 20px;\r\n    border: 1px solid #eee;\r\n    background-color: #fff;\r\n}\r\n\r\n.twitter-date, .twitter-location {\r\n    margin-top: 30px;\r\n    font-size: 17px;\r\n    color: #434343;\r\n    font-weight: bold;\r\n}\r\n\r\n.name {\r\n    font-size: 20px;\r\n    font-weight: bold;\r\n    color: #434343;\r\n    margin-top: 5px;\r\n}\r\n\r\n.username {\r\n    margin-top: 2px;\r\n    color: #434343;\r\n}\r\n\r\n.avatar {\r\n    border: 3px solid #fff;\r\n}'),(23,'cdata','template','<div class=\"twitter-container\">\r\n<div class=\"col-xs-12 mini-widget\">\r\n<div class=\"col-xs-2 img-container\">[ProfileImage|bigger]</div>\r\n\r\n<div class=\"col-xs-10\">\r\n<div class=\"name\">[User]</div>\r\n\r\n<div class=\"username\">[ScreenName]</div>\r\n</div>\r\n\r\n<div class=\"col-xs-12\">\r\n<div class=\"main-tweet\">[Tweet]</div>\r\n</div>\r\n</div>\r\n</div>\r\n'),(24,'attrib','align','center'),(24,'attrib','enableStat','Inherit'),(24,'attrib','scaleType','center'),(24,'attrib','uri','21.jpg'),(24,'attrib','valign','middle'),(25,'attrib','clockFace','TwentyFourHourClock'),(25,'attrib','clockTypeId','3'),(25,'attrib','enableStat','Inherit'),(25,'attrib','lowerLimit','0'),(25,'attrib','offset','0'),(25,'attrib','showSeconds','1'),(25,'attrib','ta_text_advanced','0'),(25,'attrib','theme','1'),(25,'attrib','upperLimit','0'),(25,'cdata','format','<span style=\"font-size: 48px; color:#ffffff;\">[HH:mm]</span>'),(26,'attrib','enableStat','Inherit'),(26,'attrib','scaleType','center'),(26,'attrib','uri','22.png'),(27,'attrib','enableStat','Inherit'),(27,'attrib','scaleType','center'),(27,'attrib','uri','23.png'),(37,'attrib','currentTemplate_advanced','0'),(37,'attrib','dailyTemplate_advanced','0'),(37,'attrib','dayConditionsOnly','0'),(37,'attrib','enableStat','Inherit'),(37,'attrib','lang','fr'),(37,'attrib','latitude',NULL),(37,'attrib','longitude',NULL),(37,'attrib','lowerLimit','0'),(37,'attrib','name','Météo'),(37,'attrib','overrideTemplate','1'),(37,'attrib','templateId','weather-module1l'),(37,'attrib','transIn','fadeIn'),(37,'attrib','transInDirection','N'),(37,'attrib','transInDuration','1000'),(37,'attrib','units','auto'),(37,'attrib','updateInterval','60'),(37,'attrib','upperLimit','0'),(37,'attrib','useDisplayLocation','1'),(37,'attrib','widgetOriginalHeight','1080'),(37,'attrib','widgetOriginalWidth','1920'),(37,'cdata','currentTemplate','<div class=\"bg-div bg-[icon] container-fluid\">\r\n<div class=\"row\">\r\n<div class=\"col-xs-6\">\r\n<h1 class=\"city\">Vandœuvre-lès-Nancy</h1>\r\n<h1 class=\"date shadowed\">[time|D]<br />\r\n[time|d]/[time|m]</h1>\r\n</div>\r\n\r\n<div class=\"col-xs-5\">\r\n<div class=\"row text-right temp shadowed\">[temperatureRound]&ordm;[temperatureUnit]</div>\r\n\r\n<div class=\"row pull-right animated rotateInUpRight main-icon shadowed\">&nbsp;</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"bg-footer row bottom-bar\">\r\n<div class=\"col-xs-4 text-center\">\r\n<div class=\"row forecast-current\">[summary]</div>\r\n\r\n<div class=\"row forecast-second\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]</div>\r\n\r\n<div class=\"row forecast-second\">||Humidité||: [humidityPercent]%</div>\r\n</div>\r\n\r\n<div class=\"upcoming\">[dailyForecast|4|1]</div>\r\n</div>\r\n</div>\r\n'),(37,'cdata','dailyTemplate','<div class=\"day col-xs-2\">\r\n    <div class=\"row text-center day-details\">[time|D]</div>\r\n    <div class=\"row animated Bounce second-icon\"><i class=\"wi [wicon]\"></i></div>\r\n    <div class=\"row text-center temp-details\">[temperatureMaxRound] º [temperatureUnit] </div>\r\n</div>'),(37,'cdata','javaScript',''),(37,'cdata','styleSheet','#content { \r\n  height: inherit; \r\n}\r\n\r\n.shadowed {\r\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\r\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\r\n}\r\n\r\n.bg-div {\r\n    font-family: \'Roboto\', sans-serif;\r\n    background-repeat: no-repeat;\r\n    background-size: cover;\r\n    background-position: left;\r\n    width: 1920px !important;\r\n    height: 1080px !important;\r\n}\r\n\r\n.bg-cloudy {\r\n  background-image: url(\'[cloudy-image]\');\r\n}\r\n\r\n.bg-partly-cloudy-day {\r\n  background-image: url(\'[day-cloudy-image]\');\r\n}\r\n\r\n.bg-clear-day {\r\n  background-image: url(\'[day-sunny-image]\');\r\n}\r\n\r\n.bg-fog {\r\n  background-image: url(\'[fog-image]\');\r\n}\r\n\r\n.bg-sleet {\r\n  background-image: url(\'[hail-image]\');\r\n}\r\n\r\n.bg-clear-night {\r\n  background-image: url(\'[night-clear-image]\');\r\n}\r\n\r\n.bg-partly-cloudy-night {\r\n  background-image: url(\'[night-partly-cloudy-image]\');\r\n}\r\n\r\n.bg-rain {\r\n  background-image: url(\'[rain-image]\');\r\n}\r\n\r\n.bg-snow {\r\n  background-image: url(\'[snow-image]\');\r\n}\r\n\r\n.bg-wind {\r\n  background-image: url(\'[windy-image]\');\r\n}\r\n.bg-footer {\r\n    position: relative;\r\n    right: 0;\r\n    top: 106px;\r\n    left: 0;\r\n    text-align: center;\r\n    background-color: #000;\r\n    opacity: 0.8;\r\n    padding: 10px 0 0 0;\r\n}\r\n\r\n.date {\r\n    font-family: \'Roboto\', sans-serif;\r\n    font-size: 100px;\r\n    color: #fff;\r\n    font-weight: 900;\r\n    margin-left: 40px;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.temp {\r\n    font-family: \'Roboto\', sans-serif;\r\n    font-size: 300px;\r\n    color: #fff;\r\n    font-weight: 900;\r\n}\r\n\r\n.city {\r\n    font-family: \'Roboto\', sans-serif;\r\n    font-size: 40px;\r\n    color: #fff;\r\n    margin-left: 40px;\r\n}\r\n\r\n.day-details {\r\n    font-size: 40px;\r\n    font-weight: 200;\r\n    color: #fff;\r\n    font-style: italic;\r\n}\r\n\r\n.temp-details {\r\n    font-size: 35px;\r\n    color: #fff;\r\n    padding-bottom: 10px;\r\n}\r\n\r\n.forecast-current {\r\n    font-weight: 900;\r\n    color: #fff;\r\n    font-size: 60px;\r\n}\r\n\r\n.forecast-second {\r\n    margin-top: 10px;\r\n    font-weight: 200;\r\n    color: #fff;\r\n    font-size: 40px;\r\n}\r\n\r\n.main-icon {\r\n    color: #fff;\r\n    font-size: 180px;\r\n}\r\n\r\n.second-icon {\r\n    color: #fff;\r\n    font-size: 60px;\r\n    padding: 25px 0px;\r\n}\r\n\r\n.powered {\r\n    padding: 0px 0;\r\n    color: #000;\r\n    font-size: 24px;\r\n    background-color: white;\r\n}'),(38,'attrib','clockFace','TwentyFourHourClock'),(38,'attrib','clockTypeId','3'),(38,'attrib','enableStat','Inherit'),(38,'attrib','lowerLimit','0'),(38,'attrib','offset','0'),(38,'attrib','showSeconds','1'),(38,'attrib','ta_text_advanced','0'),(38,'attrib','theme','1'),(38,'attrib','transIn','fadeIn'),(38,'attrib','transInDirection','N'),(38,'attrib','transInDuration','1000'),(38,'attrib','upperLimit','0'),(38,'cdata','format','<span style=\"font-size: 48px; color:#ffffff;\">[HH:mm]</span>'),(39,'attrib','enableStat','Inherit'),(39,'attrib','scaleType','center'),(39,'attrib','transIn','fadeIn'),(39,'attrib','transInDirection','N'),(39,'attrib','transInDuration','1000'),(39,'attrib','uri','22.png'),(40,'attrib','enableStat','Inherit'),(40,'attrib','scaleType','center'),(40,'attrib','transIn','fadeIn'),(40,'attrib','transInDirection','N'),(40,'attrib','transInDuration','1000'),(40,'attrib','uri','23.png'),(45,'attrib','currentTemplate_advanced','0'),(45,'attrib','dailyTemplate_advanced','0'),(45,'attrib','dayConditionsOnly','0'),(45,'attrib','enableStat','Inherit'),(45,'attrib','lang','fr'),(45,'attrib','latitude',NULL),(45,'attrib','longitude',NULL),(45,'attrib','lowerLimit','0'),(45,'attrib','name','Météo'),(45,'attrib','overrideTemplate','1'),(45,'attrib','templateId','weather-module1l'),(45,'attrib','transIn','fadeIn'),(45,'attrib','transInDirection','N'),(45,'attrib','transInDuration','2000'),(45,'attrib','units','auto'),(45,'attrib','updateInterval','60'),(45,'attrib','upperLimit','0'),(45,'attrib','useDisplayLocation','1'),(45,'attrib','widgetOriginalHeight','1080'),(45,'attrib','widgetOriginalWidth','1920'),(45,'cdata','currentTemplate','<div class=\"bg-div bg-[icon] container-fluid\">\r\n<div class=\"row\">\r\n<div class=\"col-xs-6\">\r\n<h1 class=\"city\">Vandœuvre-lès-Nancy</h1>\r\n<h1 class=\"date shadowed\">[time|D]<br />\r\n[time|d]/[time|m]</h1>\r\n</div>\r\n\r\n<div class=\"col-xs-5\">\r\n<div class=\"row text-right temp shadowed\">[temperatureRound]&ordm;[temperatureUnit]</div>\r\n\r\n<div class=\"row pull-right animated rotateInUpRight main-icon shadowed\">&nbsp;</div>\r\n</div>\r\n</div>\r\n\r\n<div class=\"bg-footer row bottom-bar\">\r\n<div class=\"col-xs-4 text-center\">\r\n<div class=\"row forecast-current\">[summary]</div>\r\n\r\n<div class=\"row forecast-second\">||Vent||: [windDirection] [windSpeed] [windSpeedUnit]</div>\r\n\r\n<div class=\"row forecast-second\">||Humidité||: [humidityPercent]%</div>\r\n</div>\r\n\r\n<div class=\"upcoming\">[dailyForecast|4|1]</div>\r\n</div>\r\n</div>\r\n'),(45,'cdata','dailyTemplate','<div class=\"day col-xs-2\">\r\n    <div class=\"row text-center day-details\">[time|D]</div>\r\n    <div class=\"row animated Bounce second-icon\"><i class=\"wi [wicon]\"></i></div>\r\n    <div class=\"row text-center temp-details\">[temperatureMaxRound] º [temperatureUnit] </div>\r\n</div>'),(45,'cdata','javaScript',''),(45,'cdata','styleSheet','#content { \r\n  height: inherit; \r\n}\r\n\r\n.shadowed {\r\ntext-shadow: 0px 0px 2px rgba(0, 0, 0, 0.4);\r\n    filter: dropshadow(color=rgba(0, 0, 0, 0.4), offx=2, offy=2);\r\n}\r\n\r\n.bg-div {\r\n    font-family: \'Roboto\', sans-serif;\r\n    background-repeat: no-repeat;\r\n    background-size: cover;\r\n    background-position: left;\r\n    width: 1920px !important;\r\n    height: 1080px !important;\r\n}\r\n\r\n.bg-cloudy {\r\n  background-image: url(\'[cloudy-image]\');\r\n}\r\n\r\n.bg-partly-cloudy-day {\r\n  background-image: url(\'[day-cloudy-image]\');\r\n}\r\n\r\n.bg-clear-day {\r\n  background-image: url(\'[day-sunny-image]\');\r\n}\r\n\r\n.bg-fog {\r\n  background-image: url(\'[fog-image]\');\r\n}\r\n\r\n.bg-sleet {\r\n  background-image: url(\'[hail-image]\');\r\n}\r\n\r\n.bg-clear-night {\r\n  background-image: url(\'[night-clear-image]\');\r\n}\r\n\r\n.bg-partly-cloudy-night {\r\n  background-image: url(\'[night-partly-cloudy-image]\');\r\n}\r\n\r\n.bg-rain {\r\n  background-image: url(\'[rain-image]\');\r\n}\r\n\r\n.bg-snow {\r\n  background-image: url(\'[snow-image]\');\r\n}\r\n\r\n.bg-wind {\r\n  background-image: url(\'[windy-image]\');\r\n}\r\n.bg-footer {\r\n    position: relative;\r\n    right: 0;\r\n    top: 106px;\r\n    left: 0;\r\n    text-align: center;\r\n    background-color: #000;\r\n    opacity: 0.8;\r\n    padding: 10px 0 0 0;\r\n}\r\n\r\n.date {\r\n    font-family: \'Roboto\', sans-serif;\r\n    font-size: 100px;\r\n    color: #fff;\r\n    font-weight: 900;\r\n    margin-left: 40px;\r\n    text-transform: uppercase;\r\n}\r\n\r\n.temp {\r\n    font-family: \'Roboto\', sans-serif;\r\n    font-size: 300px;\r\n    color: #fff;\r\n    font-weight: 900;\r\n}\r\n\r\n.city {\r\n    font-family: \'Roboto\', sans-serif;\r\n    font-size: 40px;\r\n    color: #fff;\r\n    margin-left: 40px;\r\n}\r\n\r\n.day-details {\r\n    font-size: 40px;\r\n    font-weight: 200;\r\n    color: #fff;\r\n    font-style: italic;\r\n}\r\n\r\n.temp-details {\r\n    font-size: 35px;\r\n    color: #fff;\r\n    padding-bottom: 10px;\r\n}\r\n\r\n.forecast-current {\r\n    font-weight: 900;\r\n    color: #fff;\r\n    font-size: 60px;\r\n}\r\n\r\n.forecast-second {\r\n    margin-top: 10px;\r\n    font-weight: 200;\r\n    color: #fff;\r\n    font-size: 40px;\r\n}\r\n\r\n.main-icon {\r\n    color: #fff;\r\n    font-size: 180px;\r\n}\r\n\r\n.second-icon {\r\n    color: #fff;\r\n    font-size: 60px;\r\n    padding: 25px 0px;\r\n}\r\n\r\n.powered {\r\n    padding: 0px 0;\r\n    color: #000;\r\n    font-size: 24px;\r\n    background-color: white;\r\n}'),(61,'attrib','enableStat','Inherit'),(61,'attrib','scaleType','center'),(62,'attrib','backgroundColor',NULL),(62,'attrib','effect','none'),(62,'attrib','enableStat','Inherit'),(62,'attrib','lowerLimit','0'),(62,'attrib','marqueeInlineSelector',NULL),(62,'attrib','name',NULL),(62,'attrib','speed',NULL),(62,'attrib','ta_text_advanced','1'),(62,'attrib','upperLimit','0'),(62,'attrib','xmds','1'),(62,'cdata','javaScript',''),(62,'cdata','text','<p style=\"text-align: center;\"><span style=\"color:#ffffff;\"><span style=\"font-size:155px;\"><span style=\"font-family:trebuchet ms,helvetica,sans-serif;\"><strong>GALA 2020</strong></span></span></span></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n'),(63,'attrib','backgroundColor',NULL),(63,'attrib','effect','none'),(63,'attrib','enableStat','Inherit'),(63,'attrib','lowerLimit','0'),(63,'attrib','marqueeInlineSelector',NULL),(63,'attrib','name',NULL),(63,'attrib','speed',NULL),(63,'attrib','ta_text_advanced','1'),(63,'attrib','upperLimit','0'),(63,'attrib','xmds','1'),(63,'cdata','javaScript',''),(63,'cdata','text','<p style=\"text-align: center;\"><span style=\"color:#FFFFFF;\"><span style=\"font-size:96px;\"><span style=\"font-family:trebuchet ms,helvetica,sans-serif;\">SAVE THE DATE !</span></span></span></p>\r\n'),(64,'attrib','countdownDate','2020-10-10 15:00:00'),(64,'attrib','countdownDuration','0'),(64,'attrib','countdownType','3'),(64,'attrib','countdownWarningDate','2020-10-01 00:00:00'),(64,'attrib','countdownWarningDuration','0'),(64,'attrib','enableStat','Inherit'),(64,'attrib','lowerLimit','0'),(64,'attrib','mainTemplate_advanced','0'),(64,'attrib','name',NULL),(64,'attrib','overrideTemplate','1'),(64,'attrib','templateId','countdown4'),(64,'attrib','upperLimit','0'),(64,'attrib','widgetOriginalHeight','200'),(64,'attrib','widgetOriginalWidth','600'),(64,'cdata','mainTemplate','<div id=\"clockdiv\">\r\n    <div>[DD]\r\n        <div class=\"smalltext\">||Days||</div>\r\n    </div>\r\n\r\n    <div>[hh]\r\n        <div class=\"smalltext\">||Hours||</div>\r\n    </div>\r\n    <div>[mm]\r\n        <div class=\"smalltext\">||Minutes||</div>\r\n    </div>\r\n\r\n    <div>[ss]\r\n        <div class=\"smalltext\">||Seconds||</div>\r\n    </div>\r\n</div>'),(64,'cdata','styleSheet','#clockdiv {\r\n    background-color: #2b8fa6;\r\n    font-family: sans-serif;\r\n    color: #FFF;\r\n    display: inline-block;\r\n    text-align: center;\r\n    font-size: 0;\r\n}\r\n#clockdiv > div {\r\n    padding: 12px 8px;\r\n    display: inline-block;\r\n    width: 150px;\r\n    font-size: 70px;\r\n}\r\n#clockdiv div > span {\r\n    text-align: center;\r\n    padding: 10px 0px;\r\n    width: 100%;\r\n    border-radius: 20px;\r\n    font-weight: bold;\r\n    display: inline-block;\r\n    color: #FFF;\r\n    border: 2px solid #FFF;\r\n}\r\n.smalltext {\r\n    padding-top: 10px;\r\n    font-size: 30px;\r\n}\r\n.warning > #clockdiv > div > span {\r\n    border-color: #EBDF2A;\r\n    color: #EBDF2A;\r\n}\r\n.finished > #clockdiv > div > span {\r\n    border-color: darkred;\r\n    color: darkred;\r\n}'),(65,'attrib','backgroundColor',NULL),(65,'attrib','effect','none'),(65,'attrib','enableStat','Inherit'),(65,'attrib','lowerLimit','0'),(65,'attrib','marqueeInlineSelector',NULL),(65,'attrib','name',NULL),(65,'attrib','speed',NULL),(65,'attrib','ta_text_advanced','1'),(65,'attrib','upperLimit','0'),(65,'attrib','xmds','1'),(65,'cdata','javaScript',''),(65,'cdata','text','<p style=\"text-align: center;\"><span style=\"color:#FFFFFF;\"><strong><span style=\"font-size:88px;\"><span style=\"font-family:trebuchet ms,helvetica,sans-serif;\">SAMEDI 10 OCTOBRE</span></span></strong></span></p>\r\n'),(66,'attrib','enableStat','Inherit'),(66,'attrib','lowerLimit','0'),(66,'attrib','modeid','1'),(66,'attrib','name',NULL),(66,'attrib','offsetLeft',NULL),(66,'attrib','offsetTop',NULL),(66,'attrib','pageHeight',NULL),(66,'attrib','pageWidth',NULL),(66,'attrib','scaling',NULL),(66,'attrib','transparency','0'),(66,'attrib','upperLimit','0'),(66,'attrib','uri','https%3A%2F%2Fcontent.seenspire.com%2F5Cwu-M7Up-c9qN'),(66,'attrib','xmds','1'),(67,'attrib','enableStat','Inherit'),(67,'attrib','lowerLimit','0'),(67,'attrib','modeid','3'),(67,'attrib','name',NULL),(67,'attrib','offsetLeft',NULL),(67,'attrib','offsetTop',NULL),(67,'attrib','pageHeight',NULL),(67,'attrib','pageWidth',NULL),(67,'attrib','scaling',NULL),(67,'attrib','transparency','0'),(67,'attrib','upperLimit','0'),(67,'attrib','uri','http%3A%2F%2Fcontent.seenspire.com%2F5Cwu-M7Up-c9qN'),(67,'attrib','xmds','1'),(68,'attrib','enableStat','Inherit'),(68,'attrib','scaleType','center'),(69,'attrib','backgroundColor',NULL),(69,'attrib','effect','none'),(69,'attrib','enableStat','Inherit'),(69,'attrib','lowerLimit','0'),(69,'attrib','marqueeInlineSelector',NULL),(69,'attrib','name',NULL),(69,'attrib','speed',NULL),(69,'attrib','ta_text_advanced','1'),(69,'attrib','upperLimit','0'),(69,'attrib','xmds','1'),(69,'cdata','javaScript',''),(69,'cdata','text','<p style=\"text-align: center;\"><span style=\"color:#ffffff;\"><span style=\"font-size:155px;\"><span style=\"font-family:trebuchet ms,helvetica,sans-serif;\"><strong>GALA 2020</strong></span></span></span></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n'),(70,'attrib','backgroundColor',NULL),(70,'attrib','effect','none'),(70,'attrib','enableStat','Inherit'),(70,'attrib','lowerLimit','0'),(70,'attrib','marqueeInlineSelector',NULL),(70,'attrib','name',NULL),(70,'attrib','speed',NULL),(70,'attrib','ta_text_advanced','1'),(70,'attrib','upperLimit','0'),(70,'attrib','xmds','1'),(70,'cdata','javaScript',''),(70,'cdata','text','<p style=\"text-align: center;\"><span style=\"color:#FFFFFF;\"><span style=\"font-size:96px;\"><span style=\"font-family:trebuchet ms,helvetica,sans-serif;\">SAVE THE DATE !</span></span></span></p>\r\n'),(71,'attrib','countdownDate','2020-10-10 15:00:00'),(71,'attrib','countdownDuration','0'),(71,'attrib','countdownType','3'),(71,'attrib','countdownWarningDate','2020-10-01 00:00:00'),(71,'attrib','countdownWarningDuration','0'),(71,'attrib','enableStat','Inherit'),(71,'attrib','lowerLimit','0'),(71,'attrib','mainTemplate_advanced','0'),(71,'attrib','name',NULL),(71,'attrib','overrideTemplate','1'),(71,'attrib','templateId','countdown4'),(71,'attrib','upperLimit','0'),(71,'attrib','widgetOriginalHeight','200'),(71,'attrib','widgetOriginalWidth','600'),(71,'cdata','mainTemplate','<div id=\"clockdiv\">\r\n    <div>[DD]\r\n        <div class=\"smalltext\">||Days||</div>\r\n    </div>\r\n\r\n    <div>[hh]\r\n        <div class=\"smalltext\">||Hours||</div>\r\n    </div>\r\n    <div>[mm]\r\n        <div class=\"smalltext\">||Minutes||</div>\r\n    </div>\r\n\r\n    <div>[ss]\r\n        <div class=\"smalltext\">||Seconds||</div>\r\n    </div>\r\n</div>'),(71,'cdata','styleSheet','#clockdiv {\r\n    background-color: #2b8fa6;\r\n    font-family: sans-serif;\r\n    color: #FFF;\r\n    display: inline-block;\r\n    text-align: center;\r\n    font-size: 0;\r\n}\r\n#clockdiv > div {\r\n    padding: 12px 8px;\r\n    display: inline-block;\r\n    width: 150px;\r\n    font-size: 70px;\r\n}\r\n#clockdiv div > span {\r\n    text-align: center;\r\n    padding: 10px 0px;\r\n    width: 100%;\r\n    border-radius: 20px;\r\n    font-weight: bold;\r\n    display: inline-block;\r\n    color: #FFF;\r\n    border: 2px solid #FFF;\r\n}\r\n.smalltext {\r\n    padding-top: 10px;\r\n    font-size: 30px;\r\n}\r\n.warning > #clockdiv > div > span {\r\n    border-color: #EBDF2A;\r\n    color: #EBDF2A;\r\n}\r\n.finished > #clockdiv > div > span {\r\n    border-color: darkred;\r\n    color: darkred;\r\n}'),(72,'attrib','backgroundColor',NULL),(72,'attrib','effect','none'),(72,'attrib','enableStat','Inherit'),(72,'attrib','lowerLimit','0'),(72,'attrib','marqueeInlineSelector',NULL),(72,'attrib','name',NULL),(72,'attrib','speed',NULL),(72,'attrib','ta_text_advanced','1'),(72,'attrib','upperLimit','0'),(72,'attrib','xmds','1'),(72,'cdata','javaScript',''),(72,'cdata','text','<p style=\"text-align: center;\"><span style=\"color:#FFFFFF;\"><strong><span style=\"font-size:88px;\"><span style=\"font-family:trebuchet ms,helvetica,sans-serif;\">SAMEDI 10 OCTOBRE</span></span></strong></span></p>\r\n');
/*!40000 ALTER TABLE `widgetoption` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-23 17:15:00
